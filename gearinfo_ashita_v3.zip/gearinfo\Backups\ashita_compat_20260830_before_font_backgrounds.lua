-- GearInfo Ashita v3 compatibility layer.
-- Bridges the Windower API used by GearInfo_core onto Ashita v3 (ashitav3):
--   * text objects   -> AshitaCore:GetFontManager() font objects
--   * primitives     -> ID3DXSprite textured quads drawn in the 'render' event
--                       (same technique as the stock v3 equipmon addon)
--   * windower.ffxi  -> AshitaCore:GetDataManager() (v3 naming)
--   * events         -> ashita.register_event (v3 names / signatures)
local compat = {};

-- v3 exposes bit / struct as globals; make require() find them too.
if (bit ~= nil and package.loaded['bit'] == nil) then package.loaded['bit'] = bit; end
if (struct ~= nil and package.loaded['struct'] == nil) then package.loaded['struct'] = struct; end
local bit = bit or require('bit');

local packetlib = require('packets');
local actionlib = require('ashita_action');
local resources = require('resources');
local debuglib = debug;
local unpack_values = unpack;

local callbacks = {};
local text_objects = {};
local primitive_objects = {};
local primitive_order = {};
local texture_cache = {};
local texture_load_failures = {};
local sprite = nil;
local initialized = false;
local started = false;
local sequence = 0;
local alias_counter = 0;

local function dm()
    return AshitaCore:GetDataManager();
end

local function safe(object, method, default, ...)
    if (object == nil or type(object[method]) ~= 'function') then return default; end
    local ok, value = pcall(object[method], object, ...);
    if (ok and value ~= nil) then return value; end
    return default;
end

local function invoke(name, ...)
    local list = callbacks[name];
    if (list == nil) then return false; end
    local arguments = { n=select('#', ...), ... };
    local blocked = false;
    for _, callback in ipairs(list) do
        local ok, result = xpcall(function ()
            return callback(unpack_values(arguments, 1, arguments.n));
        end, debuglib.traceback);
        if (not ok) then
            print(('[GearInfo] %s event failed: %s'):format(name, result));
        elseif (result == true) then
            blocked = true;
        end
    end
    return blocked;
end

local function register_callback(name, callback)
    callbacks[name] = callbacks[name] or {};
    table.insert(callbacks[name], callback);
    sequence = sequence + 1;
    return sequence;
end

local function argb(a, r, g, b)
    local value = bit.bor(
        bit.lshift(bit.band(tonumber(a) or 255, 0xFF), 24),
        bit.lshift(bit.band(tonumber(r) or 255, 0xFF), 16),
        bit.lshift(bit.band(tonumber(g) or 255, 0xFF), 8),
        bit.band(tonumber(b) or 255, 0xFF)
    );
    return value < 0 and (value + 0x100000000) or value;
end

local slot_names = {
    'main','sub','range','ammo','head','body','hands','legs','feet',
    'neck','waist','left_ear','right_ear','left_ring','right_ring','back',
};

local skill_names = {
    [1]='hand_to_hand',[2]='dagger',[3]='sword',[4]='great_sword',[5]='axe',
    [6]='great_axe',[7]='scythe',[8]='polearm',[9]='katana',[10]='great_katana',
    [11]='club',[12]='staff',[25]='archery',[26]='marksmanship',[27]='throwing',
    [28]='guarding',[29]='evasion',[30]='shield',[31]='parrying',
    [32]='divine_magic',[33]='healing_magic',[34]='enhancing_magic',
    [35]='enfeebling_magic',[36]='elemental_magic',[37]='dark_magic',
    [38]='summoning_magic',[39]='ninjutsu',[40]='singing',
    [41]='stringed_instrument',[42]='wind_instrument',[43]='blue_magic',
    [44]='geomancy',[45]='handbell',
};

----------------------------------------------------------------------------------------------------
-- Player / party / entity data (v3 IDataManager naming)
----------------------------------------------------------------------------------------------------
local function player_buffs(player)
    local result = {};
    local ok, buffs = pcall(function () return player:GetBuffs(); end);
    if (not ok or buffs == nil) then return result; end
    if (type(buffs) == 'table') then
        for _, value in pairs(buffs) do
            value = tonumber(value);
            if (value ~= nil and value > 0 and value < 1023 and value ~= 255) then
                table.insert(result, value);
            end
        end
    else
        for index = 0, 31 do
            local ok2, value = pcall(function () return buffs[index]; end);
            value = ok2 and tonumber(value) or nil;
            if (value ~= nil and value > 0 and value < 1023 and value ~= 255) then
                table.insert(result, value);
            end
        end
    end
    return result;
end

local function combat_skills(player)
    local result = {};
    for id, name in pairs(skill_names) do
        local value = 0;
        local ok, entry = pcall(function () return player:GetCombatSkill(id - 1); end);
        if (ok and entry ~= nil) then
            if (type(entry) == 'number') then
                value = bit.band(entry, 0x7FFF);
            elseif (type(entry.GetSkill) == 'function') then
                value = safe(entry, 'GetSkill', 0);
            elseif (tonumber(entry.Raw) ~= nil) then
                value = bit.band(tonumber(entry.Raw), 0x7FFF);
            elseif (tonumber(entry.Skill) ~= nil) then
                value = tonumber(entry.Skill);
            end
        end
        result[name] = tonumber(value) or 0;
    end
    return result;
end

local function job_points(player)
    local result = {};
    for id = 1, 22 do
        local job = resources.jobs[id];
        if (job ~= nil and job.ens ~= nil) then
            result[job.ens:lower()] = {
                jp = tonumber(safe(player, 'GetJobPoints', 0, id)) or 0,
                jp_spent = tonumber(safe(player, 'GetJobPointsSpent', 0, id)) or 0,
            };
        end
    end
    return result;
end

local function player_stats(player)
    local names = { 'STR', 'DEX', 'VIT', 'AGI', 'INT', 'MND', 'CHR' };
    local result = {};
    for index, name in ipairs(names) do
        result[name] = tonumber(safe(player, 'GetStat', 0, index - 1)) or 0;
    end
    result.Attack = tonumber(safe(player, 'GetAttack', 0)) or 0;
    result.Defense = tonumber(safe(player, 'GetDefense', 0)) or 0;
    result.attack = result.Attack;
    result.defense = result.Defense;
    return result;
end

local function current_player()
    local data = dm();
    local player = data and data:GetPlayer() or nil;
    local party = data and data:GetParty() or nil;
    local entity = data and data:GetEntity() or nil;
    local index = safe(party, 'GetMemberTargetIndex', 0, 0);
    local main_id = safe(player, 'GetMainJob', 0);
    local sub_id = safe(player, 'GetSubJob', 0);
    local main = resources.jobs[main_id];
    local sub = resources.jobs[sub_id];
    local name = safe(party, 'GetMemberName', '', 0);
    local server_id = safe(party, 'GetMemberServerId', 0, 0);
    local skills = combat_skills(player);
    return {
        id = server_id,
        index = index,
        name = name,
        main_job_id = main_id,
        sub_job_id = sub_id,
        main_job = main and main.ens or '',
        sub_job = sub and sub.ens or '',
        main_job_level = safe(player, 'GetMainJobLevel', 0),
        sub_job_level = safe(player, 'GetSubJobLevel', 0),
        status = safe(entity, 'GetStatus', 0, index),
        buffs = player_buffs(player),
        skills = skills,
        skill = skills,
        job_points = job_points(player),
        merits = { desperate_blows=0, ikishoten=0, store_tp_effect=0, aggressive_aim=0 },
        stats = player_stats(player),
        vitals = {
            hp=safe(party, 'GetMemberCurrentHP', 0, 0),
            mp=safe(party, 'GetMemberCurrentMP', 0, 0),
            tp=safe(party, 'GetMemberCurrentTP', 0, 0),
            hpp=safe(party, 'GetMemberCurrentHPP', 100, 0),
            mpp=safe(party, 'GetMemberCurrentMPP', 100, 0),
            max_hp=safe(player, 'GetHealthMax', 0),
            max_mp=safe(player, 'GetManaMax', 0),
        },
        equipment = {},
    };
end

local function mob_by_index(index)
    index = tonumber(index) or 0;
    local entity = dm() and dm():GetEntity() or nil;
    if (entity == nil or index <= 0) then return nil; end
    local id = safe(entity, 'GetServerId', 0, index);
    if (id == 0) then return nil; end
    local pet_index = safe(entity, 'GetPetTargetIndex', 0, index);
    return {
        id=id, index=index, name=safe(entity, 'GetName', '', index),
        x=safe(entity, 'GetLocalX', 0, index),
        y=safe(entity, 'GetLocalY', 0, index),
        z=safe(entity, 'GetLocalZ', 0, index),
        hpp=safe(entity, 'GetHealthPercent', 0, index),
        distance=safe(entity, 'GetDistance', 0, index),
        status=safe(entity, 'GetStatus', 0, index),
        claim_id=safe(entity, 'GetClaimServerId', 0, index),
        spawn_type=safe(entity, 'GetSpawnFlags', 0, index),
        pet_index=pet_index ~= 0 and pet_index or nil,
        charmed=false, valid_target=true,
    };
end

local function extra_string(extra)
    if (extra == nil) then return ''; end
    if (type(extra) == 'string') then return extra; end
    if (type(extra) == 'table') then
        local chars = {};
        for index = 1, #extra do chars[index] = string.char((tonumber(extra[index]) or 0) % 256); end
        return table.concat(chars);
    end
    local chars = {};
    local ok = pcall(function ()
        for index = 0, 23 do chars[index + 1] = string.char((tonumber(extra[index]) or 0) % 256); end
    end);
    return ok and table.concat(chars) or '';
end

local function item_at(container, index)
    container = tonumber(container) or 0;
    index = tonumber(index) or 0;
    local inventory = dm() and dm():GetInventory() or nil;
    local ok, item = pcall(function () return inventory:GetItem(container, index); end);
    if (not ok or item == nil) then
        return { id=0, count=0, status=0, slot=index, bag=container, bazaar=0, extdata='' };
    end
    return {
        id=tonumber(item.Id or item.ItemId) or 0,
        count=tonumber(item.Count or item.Quantity) or 0,
        status=tonumber(item.Flags or item.Status) or 0,
        slot=index,
        bag=container,
        bazaar=tonumber(item.Price) or 0,
        extdata=extra_string(item.Extra),
    };
end

local function inventory_items(container, index)
    if (container ~= nil and index ~= nil) then return item_at(container, index); end
    local inventory = dm() and dm():GetInventory() or nil;
    if (container ~= nil) then
        local result = {};
        local max = safe(inventory, 'GetContainerMax', 80, tonumber(container) or 0);
        for slot = 0, max do
            local item = item_at(container, slot);
            if (item.id ~= 0) then result[slot] = item; end
        end
        return result;
    end
    local result = { gil=0, equipment={} };
    for slot = 0, 15 do
        local ok, equipped = pcall(function () return inventory:GetEquippedItem(slot); end);
        local bag, item_index = 0, 0;
        if (ok and equipped ~= nil) then
            local encoded = tonumber(equipped.ItemIndex or equipped.Index) or 0;
            bag = math.floor(encoded / 256);
            item_index = encoded % 256;
        end
        local name = slot_names[slot + 1];
        result.equipment[name] = item_index;
        result.equipment[name .. '_bag'] = bag;
    end
    return result;
end

local function party_table()
    local result = {};
    local party = dm() and dm():GetParty() or nil;
    local keys = {
        'p0','p1','p2','p3','p4','p5',
        'a10','a11','a12','a13','a14','a15',
        'a20','a21','a22','a23','a24','a25',
    };
    for member = 0, 17 do
        local id = safe(party, 'GetMemberServerId', 0, member);
        local name = safe(party, 'GetMemberName', '', member);
        local index = safe(party, 'GetMemberTargetIndex', 0, member);
        if (id ~= 0 and name ~= '') then
            result[keys[member + 1]] = {
                id=id, name=name, mob=mob_by_index(index),
                hpp=safe(party, 'GetMemberCurrentHPP', 0, member),
                mpp=safe(party, 'GetMemberCurrentMPP', 0, member),
                tp=safe(party, 'GetMemberCurrentTP', 0, member),
            };
        end
    end
    return result;
end

local blu_offset = nil;
local function blu_spells()
    local result = {};
    local ok = pcall(function ()
        if (blu_offset == nil) then
            local address = ashita.memory.find('FFXiMain.dll', 0, 'C1E1032BC8B0018D????????????B9????????F3A55F5E5B', 10, 0);
            if (address == nil or address == 0) then blu_offset = false; return; end
            blu_offset = ashita.memory.read_uint32(address);
        end
        if (blu_offset == false) then return; end
        local pointer = ashita.memory.read_uint32(AshitaCore:GetPointerManager():GetPointer('inventory'));
        if (pointer == 0) then return; end
        pointer = ashita.memory.read_uint32(pointer);
        if (pointer == 0) then return; end
        local player = dm():GetPlayer();
        local offset = safe(player, 'GetMainJob', 0) == 16 and 0x04 or 0xA0;
        local values = ashita.memory.read_array(pointer + blu_offset + offset, 0x14);
        for _, value in ipairs(values) do
            if (value ~= 0) then table.insert(result, value + 512); end
        end
    end);
    return ok and result or {};
end

local function add_to_chat(_, value)
    print(('[GearInfo] %s'):format(tostring(value or '')));
end

local function queue_command(command)
    command = tostring(command or ''):gsub('^%s*input%s+', '');
    command = command:gsub('^%s*lua%s+r%s+gearinfo%s*;?%s*$', '/addon reload gearinfo');
    command = command:gsub('^%s*lua%s+u%s+gearinfo%s*;?%s*$', '/addon unload gearinfo');
    if (command:sub(1, 1) ~= '/') then command = '/' .. command; end
    -- v3: QueueCommand(command, type)
    AshitaCore:GetChatManager():QueueCommand(command, 1);
end

----------------------------------------------------------------------------------------------------
-- Text objects (v3 IFontObject)
----------------------------------------------------------------------------------------------------
local function next_alias(prefix)
    alias_counter = alias_counter + 1;
    return ('gi3_%s_%d'):format(prefix, alias_counter);
end

local function create_text(name)
    if (text_objects[name] ~= nil) then return; end
    local alias = next_alias('txt');
    local font = AshitaCore:GetFontManager():Create(alias);
    if (font == nil) then error('[GearInfo] FontManager:Create failed for ' .. tostring(name)); end
    pcall(function () font:SetAutoResize(true); end);
    pcall(function () font:SetLocked(true); end);
    font:SetFontFamily('Tahoma');
    font:SetFontHeight(10);
    font:SetColor(0xFFFFFFFF);
    font:SetPositionX(0);
    font:SetPositionY(0);
    font:SetText('');
    font:SetVisibility(false);
    pcall(function () font:GetBackground():SetVisibility(false); end);
    text_objects[name] = { font=font, alias=alias, text='', size=10, family='Tahoma' };
end

----------------------------------------------------------------------------------------------------
-- Primitives (textured quads rendered with ID3DXSprite)
----------------------------------------------------------------------------------------------------
local function png_size(path)
    local handle = io.open(path, 'rb');
    if (handle == nil) then return nil; end
    local header = handle:read(24);
    handle:close();
    if (header == nil or #header < 24 or header:sub(1, 8) ~= '\137PNG\r\n\26\n') then return nil; end
    local function be32(offset)
        local a, b, c, d = header:byte(offset, offset + 3);
        return ((a * 256 + b) * 256 + c) * 256 + d;
    end
    local width, height = be32(17), be32(21);
    if (width <= 0 or height <= 0) then return nil; end
    return width, height;
end

local function load_texture(path)
    local cached = texture_cache[path];
    if (cached ~= nil) then return cached; end
    if (texture_load_failures[path]) then return nil; end
    local width, height = png_size(path);
    local res, texture = ashita.d3dx.CreateTextureFromFileA(path);
    if (res ~= 0 or texture == nil) then
        texture_load_failures[path] = true;
        local _, err = ashita.d3dx.GetErrorStringA(res);
        print(('[GearInfo] Failed to load primitive texture: %s (%08X %s)'):format(path, res or 0, tostring(err)));
        return nil;
    end
    if (width == nil) then
        -- Non-PNG or unreadable header: ask D3D for the level description.
        local ok, desc = pcall(function () return texture:GetLevelDesc(0); end);
        if (ok and desc ~= nil and tonumber(desc.Width) and tonumber(desc.Height)) then
            width, height = desc.Width, desc.Height;
        else
            width, height = 1, 1;
        end
    end
    cached = { texture=texture, width=width, height=height, path=path };
    texture_cache[path] = cached;
    return cached;
end

-- Solid (untextured) backgrounds: build a texture at the exact pixel size so the
-- sprite draws it 1:1. Large sprite scale factors do not render on v3.
local solid_cache = {};
solid_test = false;
local solid_bytes = nil;
local function load_solid_texture(width, height)
    width = math.max(1, math.floor(width + 0.5));
    height = math.max(1, math.floor(height + 0.5));
    local key = width .. 'x' .. height;
    local cached = solid_cache[key];
    if (cached ~= nil) then return cached; end
    if (solid_bytes == nil) then
        local handle = io.open(addon.path .. 'images\\solid16.png', 'rb');
        if (handle == nil) then return nil; end
        local data = handle:read('*a');
        handle:close();
        solid_bytes = {};
        for index = 1, #data do solid_bytes[index] = data:byte(index); end
    end
    local size = #solid_bytes;
    local ptr = ashita.memory.alloc(size);
    if (ptr == nil or ptr == 0) then return nil; end
    ashita.memory.write_array(ptr, solid_bytes);
    local res, _, _, texture = ashita.d3dx.CreateTextureFromFileInMemoryEx(ptr, size, width, height, 1, 0, D3DFMT_A8R8G8B8, 1, 0xFFFFFFFF, 0xFFFFFFFF, 0);
    ashita.memory.dealloc(ptr);
    if (res ~= 0 or texture == nil) then
        if (not texture_load_failures['__solid']) then
            texture_load_failures['__solid'] = true;
            local _, err = ashita.d3dx.GetErrorStringA(res);
            print(('[GearInfo] Failed to build solid texture %s (%08X %s)'):format(key, res or 0, tostring(err)));
        end
        return nil;
    end
    cached = { texture=texture, width=width, height=height, path='solid:' .. key };
    solid_cache[key] = cached;
    return cached;
end

local function create_primitive(name)
    if (primitive_objects[name] ~= nil) then return; end
    local primitive = {
        name=name, visible=false, x=0, y=0, width=1, height=1,
        alpha=255, red=255, green=255, blue=255,
        is_solid=false, texture=nil, texture_path=nil,
    };
    primitive_objects[name] = primitive;
    table.insert(primitive_order, primitive);
end

local function remove_primitive(name)
    local primitive = primitive_objects[name];
    if (primitive == nil) then return; end
    primitive_objects[name] = nil;
    for index, value in ipairs(primitive_order) do
        if (value == primitive) then table.remove(primitive_order, index); break; end
    end
end

local function render_primitives()
    if (sprite == nil or #primitive_order == 0) then return; end
    local ok, hidden = pcall(function () return AshitaCore:GetFontManager():GetHideObjects(); end);
    if (ok and hidden) then return; end
    sprite:Begin();
    for _, primitive in ipairs(primitive_order) do
        local texture = primitive.texture;
        local scale = nil;
        if (primitive.is_solid and primitive.width > 0 and primitive.height > 0) then
            texture = load_solid_texture(primitive.width, primitive.height);
        end
        if (primitive.visible and texture ~= nil and primitive.alpha > 0 and primitive.width > 0 and primitive.height > 0) then
            local rect = RECT();
            rect.left = 0;
            rect.top = 0;
            rect.right = texture.width;
            rect.bottom = texture.height;
            if (not primitive.is_solid) then
                scale = D3DXVECTOR2(primitive.width / texture.width, primitive.height / texture.height);
            end
            local position = D3DXVECTOR2(primitive.x, primitive.y);
            local color = argb(primitive.alpha, primitive.red, primitive.green, primitive.blue);
            if (solid_test and primitive.is_solid) then color = 0xFFFFFFFF; end
            primitive.last_draw = sprite:Draw(texture.texture:Get(), rect, scale, nil, 0.0, position, color);
            primitive.last_tex = texture.path;
        end
    end
    sprite:End();
end

local function install_ui()
    windower.text = {};
    function windower.text.create(name) create_text(name); end
    function windower.text.delete(name)
        local value = text_objects[name];
        if (value ~= nil) then
            -- Hide and blank first: if Delete is unavailable the object must not linger on screen.
            pcall(function () value.font:SetVisibility(false); value.font:SetText(''); end);
            local ok, err = pcall(function () AshitaCore:GetFontManager():Delete(value.alias); end);
            if (not ok and not texture_load_failures['__fontdelete']) then
                texture_load_failures['__fontdelete'] = true;
                print('[GearInfo] FontManager:Delete failed: ' .. tostring(err));
            end
            text_objects[name] = nil;
        end
    end
    function windower.text.set_text(name, value)
        create_text(name);
        local object = text_objects[name];
        object.text = tostring(value or '');
        object.font:SetText(object.text);
    end
    function windower.text.set_visibility(name, value)
        create_text(name);
        text_objects[name].font:SetVisibility(value ~= nil and value ~= false);
    end
    function windower.text.set_bold(name, value)
        create_text(name);
        pcall(function () text_objects[name].font:SetBold(value == true); end);
    end
    function windower.text.set_font(name, value)
        create_text(name);
        local object = text_objects[name];
        object.family = tostring(value or 'Tahoma');
        object.font:SetFontFamily(object.family);
    end
    function windower.text.set_font_size(name, value)
        create_text(name);
        local object = text_objects[name];
        object.size = math.max(1, math.floor(tonumber(value) or 10));
        object.font:SetFontHeight(object.size);
    end
    function windower.text.set_location(name, x, y)
        create_text(name);
        local font = text_objects[name].font;
        font:SetPositionX(tonumber(x) or 0);
        font:SetPositionY(tonumber(y) or 0);
    end
    function windower.text.set_color(name, a, r, g, b)
        create_text(name);
        text_objects[name].font:SetColor(argb(a, r, g, b));
    end
    -- v3 font objects expose no outline colour/width; accepted and ignored.
    function windower.text.set_stroke_color(name, _, _, _, _) create_text(name); end
    function windower.text.set_stroke_width(name, _) create_text(name); end
    function windower.text.get_extents(name)
        create_text(name);
        local object = text_objects[name];
        -- GetWindowWidth/Height on v3 report the font's window (screen-wide), not
        -- the text, so try GetTextSize and fall back to a character estimate.
        local estimate_w = math.floor(#object.text * object.size * 0.6 + 0.5);
        local estimate_h = object.size + 2;
        local width, height;
        pcall(function ()
            local a, b = object.font:GetTextSize();
            if (type(a) == 'table' or type(a) == 'userdata') then
                width = tonumber(a.cx or a.x or a.width or a.Width);
                height = tonumber(a.cy or a.y or a.height or a.Height);
            else
                width, height = tonumber(a), tonumber(b);
            end
        end);
        local max_w = math.max(32, #object.text * object.size * 1.5);
        if (width == nil or width <= 0 or width > max_w) then width = estimate_w; end
        if (height == nil or height <= 0 or height > object.size * 3) then height = estimate_h; end
        return width, height;
    end

    windower.prim = {};
    function windower.prim.create(name) create_primitive(name); end
    function windower.prim.delete(name) remove_primitive(name); end
    function windower.prim.set_visibility(name, value)
        create_primitive(name);
        -- Windower treats any truthy value as visible (ImageBlock passes its
        -- 'visible' method here on creation); mirror that instead of == true.
        primitive_objects[name].visible = (value ~= nil and value ~= false);
    end
    function windower.prim.set_position(name, x, y)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.x = tonumber(x) or 0;
        primitive.y = tonumber(y) or 0;
    end
    function windower.prim.set_size(name, width, height)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.width = tonumber(width) or 1;
        primitive.height = tonumber(height) or 1;
    end
    function windower.prim.set_color(name, a, r, g, b)
        create_primitive(name);
        local primitive = primitive_objects[name];
        primitive.alpha = tonumber(a) or 255;
        primitive.red = tonumber(r) or 255;
        primitive.green = tonumber(g) or 255;
        primitive.blue = tonumber(b) or 255;
    end
    function windower.prim.set_texture(name, path)
        create_primitive(name);
        path = tostring(path or '');
        local primitive = primitive_objects[name];
        primitive.is_solid = path == '';
        if (path == '') then
            path = addon.path .. 'images\\solid16.png';
        end
        path = path:gsub('/', '\\');
        if (primitive.texture ~= nil and primitive.texture_path == path) then return; end
        primitive.texture = load_texture(path);
        primitive.texture_path = path;
    end
    function windower.prim.set_fit_to_texture(_, _) end
end

----------------------------------------------------------------------------------------------------
-- Events (v3 names and signatures; every handler must return a boolean)
----------------------------------------------------------------------------------------------------
local function install_events()
    -- Boxes are drawn in 'prerender': on v3 Ashita draws its font objects
    -- between prerender and render, so drawing here keeps the text on top.
    ashita.register_event('prerender', function ()
        if (started) then
            invoke('prerender');
            local ok, err = pcall(render_primitives);
            if (not ok and not texture_load_failures['__render']) then
                texture_load_failures['__render'] = true;
                print('[GearInfo] render failed: ' .. tostring(err));
            end
        end
    end);
    ashita.register_event('incoming_packet', function (id, size, data, modified, blocked)
        if (type(data) ~= 'string') then return false; end
        packetlib._remember(id, data);
        local result = invoke('incoming chunk', id, data, modified or data, false, blocked);
        if (id == 0x028) then invoke('action', actionlib.parse(data)); end
        return result == true;
    end);
    ashita.register_event('outgoing_packet', function (id, size, data, modified, blocked)
        if (type(data) ~= 'string') then return false; end
        local result = invoke('outgoing chunk', id, data, modified or data, false, blocked);
        return result == true;
    end);
    ashita.register_event('newchat', function (mode, message, modified, blocked)
        local result = invoke('incoming text', message, modified or message, mode);
        return result == true;
    end);
    ashita.register_event('command', function (command, ntype)
        command = tostring(command or '');
        local body = command:match('^%s*/+%s*[Gg][Ii]%s*(.*)$') or command:match('^%s*/+%s*[Gg][Ee][Aa][Rr][Ii][Nn][Ff][Oo]%s*(.*)$');
        if (body == nil) then return false; end
        local args = {};
        for value in body:gmatch('%S+') do table.insert(args, value); end
        if (args[1] == 'solidtest') then
            solid_test = not solid_test;
            print('[GearInfo] solid test (white opaque background): ' .. tostring(solid_test));
            return true;
        end
        if (args[1] == 'prims') then
            -- v3 diagnostics: dump primitive and font state to chat and data\prims_diag.txt.
            local lines = {};
            table.insert(lines, ('sprite=%s prims=%d fonts=%d'):format(tostring(sprite ~= nil), #primitive_order, (function () local n = 0; for _ in pairs(text_objects) do n = n + 1; end; return n; end)()));
            for index, primitive in ipairs(primitive_order) do
                local texture = primitive.texture;
                table.insert(lines, ('#%d vis=%s a=%d rgb=%d,%d,%d pos=%.0f,%.0f size=%.0fx%.0f tex=%s (%s) draw=%s last=%s'):format(
                    index, tostring(primitive.visible), primitive.alpha, primitive.red, primitive.green, primitive.blue,
                    primitive.x, primitive.y, primitive.width, primitive.height,
                    texture and (texture.width .. 'x' .. texture.height) or 'nil', (tostring(primitive.texture_path):gsub('^.*[\\/]', '')),
                    tostring(primitive.last_draw), tostring(primitive.last_tex)));
            end
            local limit = tonumber(args[2]) or 3;
            for index = 1, math.min(limit, #lines) do print('[GearInfo] ' .. lines[index]); end
            local handle = io.open(addon.path .. 'data\\prims_diag.txt', 'w');
            if (handle ~= nil) then handle:write(table.concat(lines, '\n')); handle:close(); print('[GearInfo] full dump: data\\prims_diag.txt'); end
            return true;
        end
        invoke('addon command', unpack_values(args));
        return true;
    end);
    ashita.register_event('mouse', function (id, x, y, delta, blocked)
        local kind = nil;
        if (id == 512) then kind = 0;
        elseif (id == 513) then kind = 1;
        elseif (id == 514) then kind = 2; end
        if (kind ~= nil and invoke('mouse', kind, x, y, delta or 0, blocked) == true) then
            return true;
        end
        return false;
    end);
    ashita.register_event('unload', function ()
        invoke('unload');
        compat.shutdown();
        return false;
    end);
end

function compat.initialize()
    if (initialized) then return; end
    initialized = true;
    package.path = addon.path .. '?.lua;' .. addon.path .. '?\\init.lua;' .. addon.path .. 'aug_gears\\?.lua;' .. package.path;
    _addon.commands = { 'gi', 'gearinfo' };

    chat = { controls = { reset='' } };
    pcall(function () chat.controls = require('chat.controls'); end);
    pcall(function () chat.chars = require('chat.chars'); end);
    windower = { ffxi={}, packets=packetlib };
    windower.addon_path = addon.path;
    windower.add_to_chat = add_to_chat;
    windower.send_command = queue_command;
    windower.ashita_install_path = function ()
        local path = '';
        pcall(function () path = tostring(AshitaCore:GetAshitaInstallPath() or ''); end);
        if (path == '') then pcall(function () path = tostring(AshitaCore:GetAshitaInstallPathA() or ''); end); end
        if (path == '') then path = addon.path:match('^(.-)[\\/]addons[\\/]') or addon.path; end
        return path;
    end
    windower.dir_exists = function (path)
        local ok, _, code = os.rename(path, path);
        return ok or code == 13;
    end
    windower.get_windower_settings = function ()
        local width, height = 1920, 1080;
        pcall(function ()
            local config = AshitaCore:GetConfigurationManager();
            width = tonumber(config:get_int32('boot_config', 'window_x', width)) or width;
            height = tonumber(config:get_int32('boot_config', 'window_y', height)) or height;
        end);
        return { x_res=width, y_res=height, ui_x_res=width, ui_y_res=height };
    end
    windower.register_event = register_callback;
    windower.raw_register_event = register_callback;

    windower.ffxi.get_player = current_player;
    windower.ffxi.get_info = function ()
        local party = dm() and dm():GetParty() or nil;
        local id = safe(party, 'GetMemberServerId', 0, 0);
        return { zone=safe(party, 'GetMemberZone', 0, 0), logged_in=id ~= 0 };
    end
    windower.ffxi.get_items = inventory_items;
    windower.ffxi.get_party = party_table;
    windower.ffxi.get_mob_by_index = mob_by_index;
    windower.ffxi.get_mob_by_id = function (id)
        local entity = dm() and dm():GetEntity() or nil;
        if (entity == nil) then return nil; end
        for index = 0, 2303 do
            if (safe(entity, 'GetServerId', 0, index) == id) then return mob_by_index(index); end
        end
        return nil;
    end
    windower.ffxi.get_mob_by_target = function (target)
        target = tostring(target or 't'):lower();
        if (target == 'me') then return mob_by_index(current_player().index); end
        if (target == 'pet') then
            local entity = dm() and dm():GetEntity() or nil;
            return mob_by_index(safe(entity, 'GetPetTargetIndex', 0, current_player().index));
        end
        local target_manager = dm() and dm():GetTarget() or nil;
        return mob_by_index(safe(target_manager, 'GetTargetIndex', 0));
    end
    windower.ffxi.get_mjob_data = function () return { spells=blu_spells() }; end

    local res, created = ashita.d3dx.CreateSprite();
    if (res == 0 and created ~= nil) then
        sprite = created;
    else
        print('[GearInfo] Failed to create sprite; box/flat backgrounds will not draw.');
    end

    install_ui();
    install_events();
end

function compat.start()
    if (started) then return; end
    started = true;
    -- Font objects survive an addon reload on v3; hide any left by a previous load.
    pcall(function ()
        local manager = AshitaCore:GetFontManager();
        for index = 1, 4000 do
            local ghost = manager:Get('gi3_txt_' .. index);
            if (ghost ~= nil) then
                pcall(function () ghost:SetVisibility(false); ghost:SetText(''); end);
                pcall(function () manager:Delete('gi3_txt_' .. index); end);
            end
        end
    end);
    invoke('load');
    print('[GearInfo] Ashita v3 port loaded. Use /gi help.');
end

function compat.shutdown()
    for name, value in pairs(text_objects) do
        pcall(function () value.font:SetVisibility(false); value.font:SetText(''); end);
        pcall(function () AshitaCore:GetFontManager():Delete(value.alias); end);
        text_objects[name] = nil;
    end
    primitive_objects = {};
    primitive_order = {};
    for path, entry in pairs(texture_cache) do
        pcall(function () entry.texture:Release(); end);
        texture_cache[path] = nil;
    end
    for key, entry in pairs(solid_cache) do
        pcall(function () entry.texture:Release(); end);
        solid_cache[key] = nil;
    end
    if (sprite ~= nil) then
        pcall(function () sprite:Release(); end);
        sprite = nil;
    end
    started = false;
end

return compat;
