return {
    code = 'BLU',
    extra2 = true,
    dd_melee = false,
    extra5 = false,
}
