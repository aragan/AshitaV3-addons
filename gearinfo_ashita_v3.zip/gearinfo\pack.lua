local struct = struct or require('struct');

local formats = {
    b = '<i1', B = '<I1', h = '<i2', H = '<I2',
    i = '<i4', I = '<I4', l = '<i4', L = '<I4',
    s = '<i2', S = '<I2', c = '<i1', C = '<I1',
    f = '<f', d = '<d',
};

function string.unpack(value, format, position)
    local fmt = formats[format] or ('<' .. tostring(format));
    local pos = math.max(1, tonumber(position) or 1);
    if (type(value) ~= 'string' or pos > #value) then return 0; end
    local ok, result = pcall(struct.unpack, fmt, value, pos);
    return ok and result or 0;
end

return struct;
