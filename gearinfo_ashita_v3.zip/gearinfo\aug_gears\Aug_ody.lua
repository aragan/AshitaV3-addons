-- aug_ody.lua
-- Combined augment reference for Odyssey:
--  1) Gaol Atonement rewards (Rank 30 augments) by item-id
--  2) Unity Rewards (+1) augmentable via Odyssey (Rank 15 augments) by item-id
--
-- Notes:
--   Gaol Atonement items here are written in the exact "one-line per piece" style you requested.
--  - Unity Rank 15 Odyssey list is from aug_ody_unity_rank15.lua (ID -> Aug1/Aug2/Aug3).
--  - Full Unity Rewards list (Unity Ranking max values) is provided below as unity_rewards_max (from res/Unity_Gear.lua).
--
-- Sources:
--   Lustreless Scale / Hide / Wing tables on BG-Wiki (Rank 15 augment lines shown on each page).
--    https://www.bg-wiki.com/ffxi/Lustreless_Scale
--    https://www.bg-wiki.com/ffxi/Lustreless_Hide
--    https://www.bg-wiki.com/ffxi/Lustreless_Wing

local aug_ody = {}

-- ============================================================
-- 1) Odyssey Gaol: Atonement 1 + Atonement 2 (Rank 30 augments)
-- ============================================================
aug_ody.gaol_rank30 = {
    -- Atonement 1 (T1)
    [21431] = {["Attack"]=15,["STR"]=10,["DEX"]=10}, -- Coiste Bodhar
    [21432] = {["Avatar: Acc"]=30,["Avatar: MAcc"]=30,["Avatar: All Attr"]=15,["Avatar: Enmity"]=10}, -- Epitaph
    [21430] = {["Pet: Attack"]=15,["Attack"]=15,["Pet: All Attr"]=10}, -- Hesperiidae
    [21433] = {["Automaton: Acc"]=30,["Automaton: MAcc"]=30,["Automaton: RAcc"]=30,["Automaton: HP"]=60,["Automaton: SpecialAtkDmg%"]=5}, -- Neo Animator

    -- Atonement 2 (T2)
    [21568] = {["DEF"]=30,["Waltz Potency%"]=10,["MDB"]=5}, -- Acrontica
    [26218] = {["WS Acc"]=15,["Attack"]=15,["SC Dmg%"]=5}, -- Beithir Ring
    [21926] = {["DEF"]=30,["Daken"]=10,["MEva"]=10}, -- Tsuru
    [26116] = {["Accuracy"]=15,["Attack"]=15,["Store TP"]=5}, -- Schere Earring
    [26362] = {["Ranged Accuracy"]=15,["Ranged Attack"]=15,["Enmity"]=-5}, -- Tellen Belt
    [26363] = {["Magic Accuracy"]=15,["Enfeebling Skill"]=15,["Enmity"]=-5}, -- Obstin. Sash
}

-- =====================================================================
-- 2) Unity Rewards (+1): Odyssey augments (Rank 15) by item-id
-- =====================================================================
-- Format:
--   [item_id] = {Aug1="...", Aug2="...", Aug3="..."}
-- (These are the 3 ranked augment lines shown on BG-Wiki tables.)

aug_ody.unity_rank15 = {
    [10769] = {Aug1="L118: VIT+15",Aug2="HP+100",Aug3=""}, -- Gelatinous Ring +1
    [10771] = {Aug1="DEX+10",Aug2="AGI+10",Aug3=""}, -- Cacoethic Ring +1
    [20508] = {Aug1="DEX+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10 / Pet: Acc. & Magic Accuracy+40"}, -- Comeuppances +1
    [20522] = {Aug1="DMG:+30",Aug2="Accuracy & Magic Accuracy+30",Aug3="L76: Critical Hit Rate+10%"}, -- Emeici +1
    [20528] = {Aug1="DMG:+14",Aug2="Accuracy & Magic Accuracy+40",Aug3="Regen+5"}, -- Fists of Fury +1
    [20581] = {Aug1="Ranged Attack+20",Aug2="Ranged Accuracy & Magic Accuracy+40",Aug3="Enmity-5"}, -- Kustawi +1
    [20604] = {Aug1="DMG:+17",Aug2="Accuracy & Magic Accuracy+40",Aug3="Weapon Skill Damage+5%"}, -- Ternion Dagger +1
    [20607] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Critical Hit Rate+10%"}, -- Anathema Harpe +1
    [20609] = {Aug1="DMG:+13",Aug2="Accuracy & Magic Accuracy+40",Aug3="Evasion+20"}, -- Jugo Kukri +1
    [20612] = {Aug1="DMG:+35",Aug2="Accuracy & Magic Accuracy+30",Aug3="Quadruple Attack+3%"}, -- Sangarius +1
    [20680] = {Aug1="DMG:+11",Aug2="Accuracy & Magic Accuracy+40",Aug3="Attack+40"}, -- Tanmogayi +1
    [20682] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Damage Taken-5%"}, -- Flyssa +1
    [20697] = {Aug1="DMG:+19",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10"}, -- Combuster +1
    [20709] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="DEX+10",Aug3="Sword Enhancement Spell Damage+50%"}, -- Demers. Degen +1
    [20800] = {Aug1="DMG:+24",Aug2="Accuracy & Magic Accuracy+40",Aug3="Pet: Acc. & Magic Accuracy+50"}, -- Mdomo Axe +1
    [20805] = {Aug1="Ranged Attack+45",Aug2="Accuracy & Magic Accuracy+40",Aug3="Pet: Acc. & Magic Accuracy+50"}, -- Perun +1
    [20807] = {Aug1="DMG:+30",Aug2="Pet: Acc. & Magic Accuracy+30",Aug3="L69: Accuracy & Magic Accuracy+35"}, -- Buramgh +1
    [20852] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Triple Attack+3%",Aug3="Quadruple Attack+3%"}, -- Aizkora +1
    [20854] = {Aug1="DMG:+53",Aug2="Accuracy & Magic Accuracy+40",Aug3="Haste+10%"}, -- Beheader +1
    [20899] = {Aug1="DMG:+56",Aug2="Accuracy & Magic Accuracy+40",Aug3="Critical Hit Rate+10%"}, -- Triska Scythe +1
    [20943] = {Aug1="DMG:+62",Aug2="Accuracy & Magic Accuracy+40",Aug3="Store TP+10"}, -- Gae Derg +1
    [20981] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Defense Bonus+5"}, -- Raicho +1
    [20988] = {Aug1="L71: DMG:+25",Aug2="Acc.",Aug3="R.Acc. & M.Acc.+20 / L73: Magic Atk. Bonus+20"}, -- Tancho +1
    [21030] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Skillchain Damage+20%"}, -- Norifusa +1
    [21035] = {Aug1="L78: TP Bonus+500",Aug2="Accuracy & Magic Accuracy+30",Aug3="STR+10"}, -- Kunimune +1
    [21076] = {Aug1="DMG:+10",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Atk. Bonus+30"}, -- Septoptic +1
    [21091] = {Aug1="DMG:+33",Aug2="Accuracy & Magic Accuracy+40",Aug3="Weapon Skill Damage+10%"}, -- Loxotic Mace +1
    [21100] = {Aug1="DMG:+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="Weapon Skill Damage+15%"}, -- Magesmasher +1
    [21160] = {Aug1="Magic Atk. Bonus+40",Aug2="Accuracy & Magic Accuracy+40",Aug3="INT/MND+10"}, -- Marin Staff +1
    [21163] = {Aug1="DMG:+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="Store TP+10"}, -- Pouwhenua +1
    [21220] = {Aug1="DMG:+9",Aug2="Ranged Accuracy+40",Aug3="Rapid Shot+15%"}, -- Paloma Bow +1
    [21223] = {Aug1="L86: Snapshot+15",Aug2="DMG:+10",Aug3="Ranged Accuracy+20"}, -- Mengado +1
    [21344] = {Aug1="Magic Damage+10",Aug2="INT+5",Aug3=""}, -- Ghastly Tathlum +1
    [21350] = {Aug1="L83: Accuracy+10",Aug2="Evasion+10",Aug3=""}, -- Wingcutter +1
    [21403] = {}, -- Damani Horn +1
    [21417] = {Aug1="L91: DEF+20",Aug2="Parrying Skill+10",Aug3=""}, -- Refined Grip +1
    [21419] = {Aug1="Attack+30",Aug2="STR+15",Aug3=""}, -- Rigorous Grip +1
    [21484] = {Aug1="Ranged Attack+45",Aug2="R.Acc. & M.Acc.+40",Aug3="DMG:+5"}, -- Malison +1
    [21689] = {Aug1="DMG:+20",Aug2="Accuracy & Magic Accuracy+40",Aug3="HP+100"}, -- Montante +1
    [21691] = {Aug1="DMG:+28",Aug2="Accuracy & Magic Accuracy+40",Aug3="Cure Potency Recieved+10%"}, -- Ushenzi +1
    [21696] = {Aug1="DMG:+33",Aug2="Accuracy & Magic Accuracy+40",Aug3="Dark Magic Skill+10"}, -- Nullis +1
    [21703] = {Aug1="DMG:+50",Aug2="Accuracy & Magic Accuracy+40",Aug3="Fast Cast+10%"}, -- Kladenets +1
    [21749] = {Aug1="DMG:+21",Aug2="Accuracy & Magic Accuracy+40",Aug3="STR/DEX/CHR+10 / Pet: Acc. & Magic Accuracy+40"}, -- Habilitator +1
    [21806] = {Aug1="DMG:+36",Aug2="Accuracy & Magic Accuracy+40",Aug3="Magic Atk. Bonus+50"}, -- Pixquizpan +1
    [22058] = {Aug1="Magic Accuracy+70",Aug2="Enfeebling Magic Skill+20",Aug3="MND+10"}, -- Contemplator +1
    [22121] = {Aug1="DMG:+17",Aug2="Ranged Accuracy+40",Aug3="Snapshot+10%"}, -- Imati +1
    [22255] = {Aug1="STR+10",Aug2="Haste+5%",Aug3=""}, -- Seeth. Bomblet +1
    [22267] = {Aug1="Magic Evasion+15",Aug2="Double Attack+3%",Aug3=""}, -- Antitail +1
    [25602] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Critical Hit Rate+10%",Aug3="STR/DEX+25"}, -- Blistering Sallet +1
    [25636] = {Aug1="Enmity+10",Aug2="Damage Taken-10%",Aug3="All Attr.+10"}, -- Loess Barbuta +1
    [25681] = {Aug1="Magic Accuracy +100",Aug2="Magic Attack Bonus +100",Aug3="All Base Stats +20"}, -- Cohort Cloak +1
    [25710] = {Aug1="Magic Evasion+60",Aug2="Enmity+5",Aug3="All Attr.+10"}, -- Obviat. Cuirass +1
    [25733] = {Aug1="Accuracy+30",Aug2="All Attr.+10",Aug3="Triple Attack+5%"}, -- Tatena. Harama. +1
    [25856] = {Aug1="Accuracy+75",Aug2="All Attr.+10",Aug3="Triple Attack+3%"}, -- Tatena. Haidate +1
    [25924] = {Aug1="Accuracy+60",Aug2="All Attr.+10",Aug3="Triple Attack+3%"}, -- Tatena. Sune. +1
    [26002] = {Aug1="DEF+45",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Loricate Torque +1
    [26022] = {Aug1="Accuracy+15",Aug2="Store TP+10",Aug3=""}, -- Vim Torque +1
    [26402] = {Aug1="Accuracy+15",Aug2="Magic Accuracy+15",Aug3="Enhancing Magic Skill+10"}, -- Forfend +1
    [26710] = {Aug1="L126: Accuracy+35",Aug2="Magic Evasion+100",Aug3="Critical Hit Rate+10%"}, -- Imp. Wing Hair. +1
    [26711] = {}, -- Perle Salade +1
    [26712] = {}, -- Aurore Beret +1
    [26713] = {}, -- Teal Chapeau +1
    [26715] = {Aug1="Accuracy & Magic Accuracy+45",Aug2="Attack+50",Aug3="All Base Stats+10"}, -- Adorned Helm +1
    [26732] = {Aug1="Accuracy & Magic Accuracy+30",Aug2="Physical Damage Limit+5%",Aug3="All Base Stats+10"}, -- Stinger Helm +1
    [26785] = {Aug1="Physical Damage Taken-10%",Aug2="Pet: Damage Taken-5%",Aug3="All Base Stats+10"}, -- Hike Khat +1
    [26787] = {Aug1="All Base Stats+30",Aug2="Evasion+50",Aug3="Acc. / R.Acc. / & M.Acc.+25"}, -- Alhazen Hat +1
    [26869] = {Aug1="Magic Accuracy+45",Aug2="Damage Taken-5%",Aug3="All Base Stats+10"}, -- Ros. Jaseran +1
    [26871] = {Aug1="Evasion+30",Aug2="Accuracy+40",Aug3="All Base Stats+10"}, -- Emet Harness +1
    [26873] = {Aug1="Accuracy+45",Aug2="Double Attack+5%",Aug3="All Base Stats+10"}, -- Hime Domaru +1
    [26888] = {Aug1="Avatar: TP Bonus+300",Aug2="Avatar: Accuracy & Magic Accuracy+30",Aug3="Avatar: All Base Stats+10"}, -- Shomonjijoe +1
    [26897] = {Aug1="L131: Magic Accuracy+60",Aug2="Spell Interruption Rate-20%",Aug3="L133: All Base Stats+20"}, -- Lugra Cloak +1
    [26943] = {Aug1="Attack+60",Aug2="Store TP+10",Aug3="All Base Stats+10"}, -- Agony Jerkin +1
    [27051] = {Aug1="Attack+45",Aug2="Accuracy & Magic Accuracy+30",Aug3="All Base Stats+10"}, -- Kachi. Kote +1
    [27107] = {Aug1="MP+45",Aug2="Avatar: Accuracy & Magic Accuracy+40",Aug3="Avatar: Magic Burst Bonus+10%"}, -- Asteria Mitts +1
    [27109] = {Aug1="Avatar: All Base Stats+30",Aug2="Avatar: Accuracy & Magic Accuracy+40",Aug3="Avatar Perpetuation Cost-5"}, -- Lamassu Mitts +1
    [27149] = {Aug1="Accuracy+40",Aug2="All Attr.+10",Aug3="Triple Attack+4%"}, -- Tatena. Gote +1
    [27151] = {Aug1="Accuracy+50",Aug2="Haste+10%",Aug3="All Base Stats+10"}, -- Gazu Bracelets +1
    [27231] = {Aug1="L149: Accuracy+30",Aug2="Critical Hit Rate+5%",Aug3="All Base Stats+10"}, -- Zoar Subligar +1
    [27408] = {Aug1="Cure Potency+15%",Aug2="Healing Magic Skill+10",Aug3="All Base Stats+10"}, -- Hygieia Clogs +1
    [27410] = {Aug1="Resist Bind+45",Aug2="Evasion+20",Aug3="All Base Stats+10"}, -- Hippo. Socks +1
    [27505] = {Aug1="Skillchain Damage+15%",Aug2="Magic Burst Bonus+10%",Aug3=""}, -- Warder's Charm +1
    [27509] = {Aug1="L110: DEF+30",Aug2="HP+200",Aug3=""}, -- Unmoving Collar +1
    [27518] = {Aug1="Evasion+15",Aug2="Counter+10",Aug3=""}, -- Bathy Choker +1
    [27533] = {Aug1="HP+45",Aug2="Shield Block Rate+3%",Aug3=""}, -- Zwazo Earring +1
    [27543] = {Aug1="Accuracy+10",Aug2="DEX+6",Aug3=""}, -- Domin. Earring +1
    [27549] = {Aug1="DEF+30",Aug2="Damage Taken-3%",Aug3=""}, -- Odnowa Earring +1
    [27559] = {Aug1="Conserve MP+10",Aug2="INT+5",Aug3=""}, -- Mephitas's Ring +1
    [27561] = {Aug1="DEF+20",Aug2="Magic Def. Bonus+5",Aug3=""}, -- Apeile Ring +1
    [27563] = {Aug1="L102: Magic Accuracy+10",Aug2="INT/MND/CHR+10",Aug3=""}, -- Metamor. Ring +1
    [27599] = {}, -- Dew Silk Cape +1
    [27602] = {Aug1="Accuracy+15",Aug2="DEX+10",Aug3=""}, -- Ground. Mantle +1
    [27610] = {Aug1="Fast Cast+10%",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Fi Follet Cape +1
    [27620] = {Aug1="Accuracy & Magic Accuracy+25",Aug2="INT/MND+25",Aug3=""}, -- Aurist's Cape +1
    [27634] = {}, -- Thorfinn Shield +1
    [27637] = {Aug1="HP+150",Aug2="Shield Skill+10",Aug3="Accuracy & Magic Accuracy+20"}, -- Evalach +1
    [27639] = {Aug1="Shield Block Rate+10%",Aug2="Enhancing Magic Received Duration+10%",Aug3=""}, -- Ajax +1
    [27641] = {Aug1="Accuracy & Magic Accuracy+30",Aug2="Shield Skill+10",Aug3=""}, -- Deliverance +1
    [27851] = {}, -- Perle Hauberk +1
    [27852] = {}, -- Aurore Doublet +1
    [27853] = {}, -- Teal Saio +1
    [27996] = {Aug1="Evasion+90",Aug2="Magic Evasion+80",Aug3="All Base Stats+10"}, -- Shigure Tekko +1
    [27997] = {}, -- Perle Moufles +1
    [27998] = {}, -- Aurore Gloves +1
    [27999] = {}, -- Teal Cuffs +1
    [28135] = {Aug1="L143: Avatar: Accuracy & Magic Accuracy+35",Aug2="L145: Avatar: All Base Stats+20",Aug3="MP+20"}, -- Assid. Pants +1
    [28137] = {Aug1="Attack+60",Aug2="Magic Atk. Bonus+30",Aug3="All Base Stats+10"}, -- Augury Cuisses +1
    [28138] = {}, -- Perle Brayettes +1
    [28139] = {}, -- Aurore Brais +1
    [28140] = {}, -- Teal Slops +1
    [28272] = {}, -- Adsilio Boots +1
    [28274] = {Aug1="L154: Healing Magic Skill+10",Aug2="Enhancing Magic Skill+10",Aug3="L156: All Base Stats+10"}, -- Regal Pumps +1
    [28276] = {Aug1="DEX/AGI+15",Aug2="Magic Evasion+30",Aug3="All Base Stats+10"}, -- Jute Boots +1
    [28277] = {}, -- Perle Sollerets +1
    [28278] = {}, -- Aurore Gaiters +1
    [28279] = {}, -- Teal Pigaches +1
    [28351] = {}, -- Cloud Hairpin +1
    [28353] = {Aug1="L115: Magic Accuracy+15",Aug2="CHR+10",Aug3=""}, -- Canto Necklace +1
    [28413] = {Aug1="STR+10",Aug2="DEX+10",Aug3=""}, -- Kentarch Belt +1
    [28424] = {Aug1="L107: Conserve MP+15",Aug2="Fast Cast+5%",Aug3=""}, -- Shinjutsu-no-Obi +1
    [28428] = {Aug1="L94: STR+15",Aug2="Double Attack+5%",Aug3=""}, -- Sailfi Belt +1
    [28430] = {Aug1="Magic Accuracy+15",Aug2="INT+10",Aug3=""}, -- Acuity Belt +1
    [28482] = {Aug1="L123: DEF+20",Aug2="STR/DEX/VIT/INT+8",Aug3=""}, -- Lugra Earring +1
    [28485] = {Aug1="Resist Silence+15",Aug2="Spell Interruption Rate-5%",Aug3=""}, -- Nourish. Earring +1
    [28487] = {Aug1="L99: Resist Sleep+15",Aug2="Resist Charm+15",Aug3=""}, -- Arete del Luna +1
    [28491] = {Aug1="Pet: Acc. & Magic Accuracy+15",Aug2="Accuracy+10",Aug3=""}, -- Handler's Earring +1
}


-- =====================================================================
-- 3) Unity Rewards: Unity Ranking (max) full list
-- =====================================================================
-- Source: res/Unity_Gear.lua (local)
-- BEGIN UNITY_REWARDS_MAX
aug_ody.unity_rewards_max = {
    ["Gelatinous Ring"] = {["HP"]=35},
    ["Gelatinous Ring +1"] = {["HP"]=35},
    ["Emeici"] = {["Accuracy"]=20},
    ["Emeici +1"] = {["Accuracy"]=20},
    ["Fists of Fury"] = {["VIT"]=15},
    ["Fists of Fury +1"] = {["VIT"]=15},
    ["Kustawi"] = {["Rapid Shot"]=7},
    ["Kustawi +1"] = {["Rapid Shot"]=7},
    ["Ternion Dagger"] = {["AGI"]=15},
    ["Ternion Dagger +1"] = {["AGI"]=15},
    ["Anathema Harpe"] = {["Store TP"]=5},
    ["Anathema Harpe +1"] = {["Store TP"]=5},
    ["Jugo Kukri"] = {["AGI"]=15},
    ["Jugo Kukri +1"] = {["AGI"]=15},
    ["Sangarius"] = {["STR"]=7},
    ["Sangarius +1"] = {["STR"]=7},
    ["Pukulatmuj"] = {["INT"]=15},
    ["Pukulatmuj +1"] = {["INT"]=15},
    ["Tanmogayi"] = {["Fast Cast"]=6},
    ["Tanmogayi +1"] = {["Fast Cast"]=6},
    ["Flyssa"] = {["Accuracy"]=15},
    ["Flyssa +1"] = {["Accuracy"]=15},
    ["Combuster"] = {["Accuracy"]=20},
    ["Combuster +1"] = {["Accuracy"]=20},
    ["Demersal Degen"] = {["Fast Cast"]=3},
    ["Demers. Degen +1"] = {["Fast Cast"]=3},
    ["Buramgh"] = {["CHR"]=10},
    ["Buramgh +1"] = {["CHR"]=10},
    ["Beheader"] = {["HP"]=120},
    ["Beheader +1"] = {["HP"]=120},
    ["Gae Derg"] = {["Critical hit rate"]=5},
    ["Gae Derg +1"] = {["Critical hit rate"]=5},
    ["Tancho"] = {["Subtle Blow"]=6},
    ["Tancho +1"] = {["Subtle Blow"]=6},
    ["Norifusa"] = {["STR"]=7},
    ["Norifusa +1"] = {["STR"]=7},
    ["Kunimune"] = {["STR"]=20},
    ["Kunimune +1"] = {["STR"]=20},
    ["Septoptic"] = {["Conserve MP"]=11},
    ["Septoptic +1"] = {["Conserve MP"]=11},
    ["Loxotic Mace"] = {["DEX"]=10},
    ["Loxotic Mace +1"] = {["DEX"]=10},
    ["Magesmasher"] = {["Attack"]=15},
    ["Magesmasher +1"] = {["Attack"]=15},
    ["Marin Staff"] = {["INT"]=15},
    ["Marin Staff +1"] = {["INT"]=15},
    ["Pouwhenua +1"] = {["Accuracy"]=20},
    ["Ababinili"] = {["Cure potency"]=10},
    ["Ghastly Tathlum"] = {["INT"]=6},
    ["Ghastly Tathlum +1"] = {["INT"]=6},
    ["Wingcutter"] = {["DEX"]=5},
    ["Wingcutter +1"] = {["DEX"]=5},
    ["Refined Grip"] = {["HP"]=35},
    ["Refined Grip +1"] = {["HP"]=35},
    ["Rigorous Grip"] = {["Attack"]=15},
    ["Rigorous Grip +1"] = {["Attack"]=15},
    ["Ushenzi"] = {["Cure potency"]=10},
    ["Ushenzi +1"] = {["Cure potency"]=10},
    ["Nullis"] = {["STR"]=20},
    ["Nullis +1"] = {["STR"]=20},
    ["Kladenets"] = {["INT"]=20},
    ["Kladenets +1"] = {["INT"]=20},
    ["Habilitator"] = {["Accuracy"]=30},
    ["Habilitator +1"] = {["Accuracy"]=30},
    ["Contemplator +1"] = {["Refresh"]=2},
    ["Blistering Sallet"] = {["HP"]=80},
    ["Blistering Sallet +1"] = {["HP"]=80},
    ["Tatena. Haramaki"] = {["Store TP"]=9},
    ["Tatena. Harama. +1"] = {["Store TP"]=9},
    ["Tatena. Haidate"] = {["Store TP"]=8},
    ["Tatena. Haidate +1"] = {["Store TP"]=8},
    ["Tatena. Sune."] = {["Store TP"]=8},
    ["Tatena. Sune. +1"] = {["Store TP"]=8},
    ["Loricate Torque"] = {["DEF"]=15},
    ["Loricate Torque +1"] = {["DEF"]=15},
    ["Vim Torque"] = {["Refresh"]=2},
    ["Vim Torque +1"] = {["Refresh"]=3},
    ["Forfend"] = {["Accuracy"]=20},
    ["Forfend +1"] = {["Accuracy"]=20},
    ["Imp. Wing Hairpin"] = {["DEX"]=7},
    ["Imp. Wing Hair. +1"] = {["DEX"]=7},
    ["Adorned Helm"] = {["Attack"]=15},
    ["Adorned Helm +1"] = {["Attack"]=15},
    ["Stinger Helm"] = {["STR"]=8},
    ["Stinger Helm +1"] = {["STR"]=8},
    ["Hike Khat"] = {["MP"]=50},
    ["Hike Khat +1"] = {["MP"]=50},
    ["Alhazen Hat"] = {["HP"]=80},
    ["Alhazen Hat +1"] = {["HP"]=80},
    ["Rosette Jaseran"] = {["Fast Cast"]=6},
    ["Ros. Jaseran +1"] = {["Fast Cast"]=6},
    ["Emet Harness"] = {["Accuracy"]=20},
    ["Emet Harness +1"] = {["Accuracy"]=20},
    ["Hime Domaru"] = {["Store TP"]=5},
    ["Hime Domaru +1"] = {["Store TP"]=5},
    ["Lugra Cloak"] = {["Fast Cast"]=6},
    ["Lugra Cloak +1"] = {["Fast Cast"]=6},
    ["Agony Jerkin"] = {["Accuracy"]=15},
    ["Agony Jerkin +1"] = {["Accuracy"]=15},
    ["Kachimusha Kote"] = {["Attack"]=15},
    ["Kachi. Kote +1"] = {["Attack"]=15},
    ["Asteria Mitts +1"] = {["Refresh"]=2},
    ["Lamassu Mitts"] = {["MP"]=50},
    ["Lamassu Mitts +1"] = {["MP"]=50},
    ["Tatena. Gote"] = {["Store TP"]=8},
    ["Tatena. Gote +1"] = {["Store TP"]=8},
    ["Gazu Bracelet"] = {["Accuracy"]=15},
    ["Gazu Bracelet +1"] = {["Accuracy"]=15},
    ["Hippomenes Socks"] = {["Evasion"]=20},
    ["Hippo. Socks +1"] = {["Evasion"]=20},
    ["Unmoving Collar"] = {["Accuracy"]=5},
    ["Unmoving Collar +1"] = {["Accuracy"]=5},
    ["Bathy Choker"] = {["Evasion"]=15},
    ["Bathy Choker +1"] = {["Evasion"]=15},
    ["Zwazo Earring"] = {["STR"]=5},
    ["Zwazo Earring +1"] = {["STR"]=5},
    ["Dominance Earring"] = {["Accuracy"]=5},
    ["Domin. Earring +1"] = {["Accuracy"]=5},
    ["Odnowa Earring"] = {["Accuracy"]=15},
    ["Odnowa Earring +1"] = {["Accuracy"]=15},
    ["Grounded Mantle"] = {["DEX"]=7},
    ["Ground. Mantle +1"] = {["DEX"]=7},
    ["Fi Follet Cape"] = {["MND"]=5},
    ["Fi Follet Cape +1"] = {["MND"]=5},
    ["Aurist's Cape"] = {["Conserve MP"]=5},
    ["Aurist's Cape +1"] = {["Conserve MP"]=5},
    ["Evalach"] = {["MP"]=50},
    ["Evalach +1"] = {["MP"]=50},
    ["Ajax"] = {["HP"]=120},
    ["Ajax +1"] = {["HP"]=120},
    ["Deliverance"] = {["Accuracy"]=15},
    ["Deliverance +1"] = {["Accuracy"]=15},
    ["Macabre Gaunt."] = {["HP"]=60},
    ["Macabre Gaunt. +1"] = {["HP"]=60},
    ["Shigure Tekko"] = {["Subtle Blow"]=7},
    ["Shigure Tekko +1"] = {["Subtle Blow"]=7},
    ["Assid. Pants +1"] = {["Refresh"]=2},
    ["Regal Pumps"] = {["Fast Cast"]=3},
    ["Regal Pumps +1"] = {["Fast Cast"]=3},
    ["Jute Boots"] = {["Evasion"]=10},
    ["Jute Boots +1"] = {["Evasion"]=10},
    ["Canto Necklace"] = {["CHR"]=12},
    ["Canto Necklace +1"] = {["CHR"]=12},
    ["Kentarch Belt"] = {["Store TP"]=5},
    ["Kentarch Belt +1"] = {["Store TP"]=5},
    ["Sailfi Belt"] = {["Attack"]=15},
    ["Sailfi Belt +1"] = {["Attack"]=15},
    ["Acuity Belt"] = {["INT"]=7},
    ["Acuity Belt +1"] = {["INT"]=7},
    ["Handler's Earring"] = {["VIT"]=5},
    ["Handler's Earring +1"] = {["VIT"]=5},
}
-- END UNITY_REWARDS_MAX

return aug_ody


