local packets = { _last = {}, _current_id = 0 };

function packets._remember(id, data)
    packets._current_id = id;
    packets._last[id] = data;
end

function packets.last_incoming(id)
    return packets._last[id];
end

function packets.parse(direction, data)
    if (direction ~= 'incoming' or type(data) ~= 'string') then return {}; end
    local id = packets._current_id;
    if (id == 0 and #data > 0) then id = data:byte(1); end
    if (id == 0x0DD) then
        local name = data:sub(0x27):match('^([^%z]*)') or '';
        return {
            ['ID'] = data:unpack('I', 0x05),
            ['HP'] = data:unpack('I', 0x09),
            ['MP'] = data:unpack('I', 0x0D),
            ['TP'] = data:unpack('I', 0x11),
            ['Index'] = data:unpack('H', 0x19),
            ['HP%'] = data:byte(0x1E) or 0,
            ['MP%'] = data:byte(0x1F) or 0,
            ['Zone'] = data:unpack('H', 0x21),
            ['Main job'] = data:byte(0x23) or 0,
            ['Main job level'] = data:byte(0x24) or 0,
            ['Sub job'] = data:byte(0x25) or 0,
            ['Sub job level'] = data:byte(0x26) or 0,
            ['Name'] = name,
        };
    end
    return {};
end

return packets;
