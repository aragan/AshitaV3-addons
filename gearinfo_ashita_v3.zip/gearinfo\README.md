# GearInfo for Ashita v3

Ashita v3 port of the Windower GearInfo addon (derived from the Ashita v4 port).

- Original addon: Sebyg666
- Ashita v3/v4 ports and Aragan data: Aragan
- Version: 3.0.0
- Discord: https://discord.gg/TskRzqGUMG
- Ashita v4 addons: https://github.com/aragan/AshitaV4-addons

## Installation

1. Copy the `gearinfo` folder to:
   `Ashita-v4\addons\gearinfo`
2. Start Ashita v3 and log in to FFXI.
3. Load the addon:
   `/addon load gearinfo`
4. Display the command list:
   `/gi help`

To load it automatically, add this line to the Ashita boot configuration:

```text
/addon load gearinfo
```

## Configuration

GearInfo reads the existing XML settings when present and creates an Ashita JSON
settings file beside it. Gear data, job files, augment databases, textures, and
images are bundled in this folder. Windower and GearSwap are not required.

The original GearInfo commands are available through `/gi` and `/gearinfo`.
Examples:

```text
/gi help
/gi show
/gi hide
/gi reset
```

## Notes

- The HUD can be moved using the same GearInfo mouse behavior.
- Equipment, augments, buffs, job data, action packets, party data, haste and
  dual-wield calculations are adapted to Ashita v3 interfaces.
- Rendering on v3: labels and values are Font Manager objects, and every box or
  panel is a text-less font object whose background primitive carries the colour
  or the box texture (v3 gives addons no primitive manager, and D3DX sprite draws
  never reach the screen from an addon).
- Text outlines (stroke) are not supported by v3 font objects and are ignored.
- `//gi prims` dumps box state to chat and to `data\prims_diag.txt` for support.
- Keep the entire folder structure. The `res`, `jobs`, `aug_gears`, `textures`,
  `images`, and bundled compatibility libraries are required.
