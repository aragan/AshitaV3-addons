local function gear_processing_job_key()
	if not player or not player.main_job then return nil end
	return player.main_job:lower()
end

local function gear_processing_jp_spent()
	local key = gear_processing_job_key()
	if not key or not player.job_points or not player.job_points[key] then return 0 end
	return player.job_points[key].jp_spent or 0
end

local function gear_processing_job_gifts()
	if not player or not player.main_job or not Gifts or not Gifts[player.main_job] then return {} end
	return Gifts[player.main_job].Gifts or {}
end
local ok_db, db_mod = pcall(require, 'aug_gears/Aug_DB')
if ok_db then
	Aug_DB = db_mod
else
	windower.add_to_chat(167, '[GearInfo] Failed to load aug_gears/Aug_DB.lua: '..tostring(db_mod))
	Aug_DB = nil
end
local function merge_static_augments(dst, src)
	if type(dst) ~= 'table' then
		dst = {}
	end
	if type(src) ~= 'table' then
		return dst, 0
	end
	local merged = 0
	for item_id, stats in pairs(src) do
		if type(item_id) == 'number' and type(stats) == 'table' then
			dst[item_id] = dst[item_id] or {}
			for stat, val in pairs(stats) do
				dst[item_id][stat] = val
			end
			merged = merged + 1
		end
	end
	return dst, merged
end
local ok_su5, su5_mod = pcall(require, 'aug_gears/Su5')
if ok_su5 then
	local merged_count
	Aug_DB, merged_count = merge_static_augments(Aug_DB, su5_mod)
	if not _static_aug_su5_notice then
		windower.add_to_chat(207, ('[GearInfo] SU5 Augments (Su5.lua) merged: %d items.'):format(merged_count))
		_static_aug_su5_notice = true
	end
else
	windower.add_to_chat(167, '[GearInfo] Failed to load aug_gears/Su5.lua: '..tostring(su5_mod))
end
if Aug_DB and not _static_aug_db_notice then
    windower.add_to_chat(207, '[GearInfo] Static Augments (Aug_DB.lua) loaded successfully.')
    _static_aug_db_notice = true
end
Aug_un = require('aug_gears/Aug_un')
Aug_back = require('aug_gears/Aug_back')
Aug_escha = require('aug_gears/Aug_escha')
Aug_SR = require('aug_gears/Aug_SR')
Aug_jse_necks = require('aug_gears/Aug_jse_necks')
local ok_ody, ody_mod = pcall(require, 'aug_gears/Aug_ody')
if ok_ody then
	Aug_ody = ody_mod
else
	windower.add_to_chat(167, '[GearInfo] Failed to load aug_gears/Aug_ody.lua: '..tostring(ody_mod))
	Aug_ody = nil
end
if Aug_ody and not _static_aug_ody_notice then
    windower.add_to_chat(207, '[GearInfo] Odyssey Augments (Aug_ody.lua) loaded successfully.')
    _static_aug_ody_notice = true
end

local _real_att_missing_notice = false
local _real_def_missing_notice = false

local function _gi_num(v)
	if type(v) == 'number' then
		return v
	end
	if type(v) == 'string' then
		return tonumber(v)
	end
	return nil
end

local function _gi_pick_num(tbl, keys)
	if type(tbl) ~= 'table' then
		return nil
	end
	for _, k in ipairs(keys) do
		local n = _gi_num(tbl[k])
		if n and n > 0 then
			return n
		end
	end
	return nil
end

local function ody_trim(str)
	return (str:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function ody_add_stat(stats, key, val)
	if not key or val == 0 then
		return
	end
	if stats[key] then
		stats[key] = stats[key] + val
	else
		stats[key] = val
	end
end

local normalize_ody_stat_name

local function add_aug_value(item, stat, val)
	if not stat or val == 0 then
		return
	end

	if type(stat) == 'string' then
		if stat == "All Base Stats" or stat == "All Attr." or stat == "All Attr" then
			for _, s in ipairs({"STR", "DEX", "VIT", "AGI", "INT", "MND", "CHR"}) do
				add_aug_value(item, s, val)
			end
			return
		end
		stat = normalize_ody_stat_name(stat)
	end

	if item[stat] then
		item[stat] = item[stat] + val
	else
		item[stat] = val
	end
	item._aug_only = item._aug_only or T{}
	if item._aug_only[stat] then
		item._aug_only[stat] = item._aug_only[stat] + val
	else
		item._aug_only[stat] = val
	end
end

normalize_ody_stat_name = function(name)
	name = ody_trim(name)
	name = name:gsub("%s+", " ")
	local lower = name:lower()

	if name == "Acc." or name == "Acc" then return "Accuracy" end
	if name == "R.Acc." or name == "R.Acc" then return "Ranged Accuracy" end
	if name == "M.Acc." or name == "M.Acc" then return "Magic Accuracy" end
	if name == "M.Dmg." or name == "M.Dmg" then return "Magic Damage" end
	if name == "M.Def.Bn." or name == "M.Def.Bn" then return "Magic Def. Bonus" end
	if name == "M.Eva." or name == "M.Eva" then return "Magic Evasion" end
	if name == "Rng. Acc." or name == "Rng. Acc" then return "Ranged Accuracy" end
	if name == "Rng. Atk." or name == "Rng. Atk" then return "Ranged Attack" end
	if name == "Atk." or name == "Atk" then return "Attack" end
	if name == "Magic Attack Bonus" or name == "Magic Attack" then return "Magic Atk. Bonus" end
	if name == "Magic Defense Bonus" then return "Magic Def. Bonus" end
	if name == "Critical Hit Rate" then return "Critical hit rate" end
	if name == "Magic Burst DMG" then return "Magic Burst Damage" end
	if name == "Magic Burst Acc" or name == "Magic Burst ACC" then return "Magic Burst Accuracy" end
	if name == "SC Dmg%" or name == "SC Dmg" then return "Skillchain Damage" end
	if name == "WS Acc" then return "Accuracy" end
	if name == "Weapon Skill Acc" or name == "Weapon Skill Acc." or name == "Weapon Skill Accuracy" then return "Accuracy" end
	if lower == "weapon skill acc" or lower == "weapon skill acc." or lower == "weapon skill accuracy" then return "Accuracy" end
	if lower == "ws acc" or lower == "ws acc." then return "Accuracy" end
	if name == "Dbl. Atk." or name == "Dbl. Atk" then return "Double Attack" end
	if name == "Dbl.Atk." or name == "Dbl.Atk" then return "Double Attack" end
	if name == "Trip. Atk." or name == "Trip. Atk" then return "Triple Attack" end
	if name == "Triple Atk." or name == "Triple Atk" then return "Triple Attack" end
	if name == "Crit Rate" then return "Critical hit rate" end
	if lower == "quad atk" or lower == "quad attack" then return "Quadruple Attack" end
	if lower == "triple atk" then return "Triple Attack" end
	if lower == "double atk" or lower == "dblatk" then return "Double Attack" end
	if lower == "eva" then return "Evasion" end
	if lower == "mag eva" or lower == "magic eva" then return "Magic Evasion" end
	if lower == "mag acc" or lower == "m acc" then return "Magic Accuracy" end
	if lower == "r acc" then return "Ranged Accuracy" end
	if lower == "mag dmg" then return "Magic Damage" end
	if lower == "crithit rate" then return "Critical hit rate" end
	if name == "Damage Taken" then return "DT" end
	if name == "Physical Damage Taken" then return "PDT" end
	if name == "Magic Damage Taken" then return "MDT" end
	if name == "Breath Damage Taken" then return "BDT" end
	if lower == "magic dmg. taken" or lower == "magic dmg taken" then return "MDT" end
	if lower == "breath dmg. taken" or lower == "breath dmg taken" then return "BDT" end
	if lower == "phys dmg taken" then return "PDT" end
	if name == "Physical Damage Limit" then return "PDL" end
	if name == "Spell Interruption Rate" then return "SIRD" end
	if lower == "damage taken" then return "DT" end
	if lower == "phys dmg taken" then return "PDT" end
	if lower == "magic attack bonus" or lower == "magic attack" then return "Magic Atk. Bonus" end
	if lower == "magic atk bonus" or lower == "magatkbns" or lower == "mag atk bonus" then return "Magic Atk. Bonus" end
	if lower == "magic burst bonus" then return "Magic Burst Bonus" end
	if lower == "magic burst damage" then return "Magic Burst Damage" end
	if lower == "magic burst dmg" then return "Magic Burst Damage" end
	if lower == "magic burst damage ii" then return "Magic Burst Damage II" end
	if lower == "skillchain bonus" then return "Skillchain Bonus" end
	if lower == "skillchain damage" then return "Skillchain Damage" end
	if lower == "physical damage limit" then return "PDL" end
	if lower == "spell interruption rate" or lower == "spell interruption rate down" then return "SIRD" end
	if lower == "occ. quickens spellcasting" or lower == "occassionally quickens spellcasting" then return "Quick Cast" end
	if lower == "blood pact delay" then return "Blood Pact Delay" end
	if lower == "blood pact delay ii" then return "Blood Pact Delay II" end
	if lower == "blood pact damage" or lower == "blood pact dmg" then return "Blood Pact Damage" end
	if lower == "blood pact ability delay" then return "Blood Pact Delay" end
	if lower == "blood pact ability delay ii" or lower == "blood pact ab del ii" or lower == "blood pact recast time ii" then return "Blood Pact Delay II" end
	if lower == "enhancing magic duration" then return "Enhancing magic effect duration" end
	if lower == "indicolure spell duration" or lower == "indi eff dur" then return "Indicolure effect duration" end
	if lower == "song duration" then return "Song effect duration" end
	if lower == "avatar perpetuation cost" then return "Avatar Perpetuation Cost" end
	if lower == "pet: magic atk. bonus" or lower == "pet: magic attack bonus" then return "Pet: Magic Atk. Bonus" end
	if lower == "pet: attack" or lower == "pet: atk." or lower == "pet: atk" then return "Pet: Attack" end
	if lower == "pet: double attack" or lower == "pet: dbl. atk." or lower == "pet: dbl. atk" then return "Pet: Double Attack" end
	if lower == "pet: accuracy" or lower == "pet: acc." or lower == "pet: acc" then return "Pet: Accuracy" end
	if lower == "pet: magic accuracy" or lower == "pet: mag. acc." or lower == "pet: mag. acc" then return "Pet: Magic Accuracy" end
	if lower == "pet: blood pact damage" then return "Pet: Blood Pact Damage" end
	if lower == "pet: magic damage" then return "Pet: Magic Damage" end
	if lower == "pet: physical damage taken" or lower == "pet: phys. dmg. taken" or lower == "pet: phys dmg taken" then return "Pet: Physical Damage Taken" end
	if lower == "pet: magic damage taken" or lower == "pet: mag. dmg. taken" or lower == "pet: mag dmg taken" then return "Pet: Magic Damage Taken" end
	if lower == "pet: haste" then return "Pet: Haste" end
	if lower == "summoning magic skill" then return "Summoning Magic skill" end
	if lower == "pet: regen" then return "Pet: Regen" end
	if lower == "pet: damage taken" then return "Pet: Damage Taken" end
	if lower == "all songs" then return "All songs" end
	if lower == "song effect duration" then return "Song effect duration" end
	if lower == "song duration" then return "Song effect duration" end
	if lower == "song spellcasting time" then return "Song spellcasting time" end
	if lower == "indicolure effect duration" then return "Indicolure effect duration" end
	if lower == "indicolure spell duration" or lower == "indi eff dur" then return "Indicolure effect duration" end
	if lower == "enhancing magic duration" then return "Enhancing magic effect duration" end
	if lower == "eva" then return "Evasion" end
	if lower == "mag eva" or lower == "magic eva" then return "Magic Evasion" end
	if lower == "mag acc" or lower == "m acc" then return "Magic Accuracy" end
	if lower == "r acc" then return "Ranged Accuracy" end
	if lower == "mag dmg" then return "Magic Damage" end
	if lower == "crithit rate" then return "Critical hit rate" end
	if lower == "cursna" then return "Cursna" end
	if lower == "potency of cure effects received" or lower == "cure potency received" then return "Cure potency received" end
	if lower == "enhancing magic effect duration" or lower == "enh mag eff dur" or lower == "enh mag eff dur." then return "Enhancing magic effect duration" end
	if lower == "elemental magic casting time" then return "Elemental magic casting time" end
	if lower == "cure spellcasting time" then return "Cure spellcasting time" end
	if lower == "quick cast" or lower == "quickcast" or lower == "occ. quickens spellcasting" then return "Quick Cast" end
	if lower == "inquartata" then return "Inquartata" end
	if name == "Cure Potency" then return "Cure potency" end
	if name == "Cure potency" then return "Cure potency" end
	if name == "Cure Pot." or name == "Cure Pot" then return "Cure potency" end
	if lower == "cure potency" or lower == "cure pot." or lower == "cure pot" then return "Cure potency" end
	if name == "Cure Potency II" or name == "Cure potency II" then return "Cure potency II" end
	if lower == "cure potency ii" or lower == "cure pot. ii" or lower == "cure pot ii" then return "Cure potency II" end
	if lower == "quick cast" or lower == "quickcast" or lower == "occ. quickens spellcasting" then return "Quick Cast" end
	if lower == "cure spellcasting time" then return "Cure spellcasting time" end
	if lower == "healing magic casting time" then return "Healing magic casting time" end
	if lower == "snapshot" then return "Snapshot" end
	if lower == "rapid shot" or lower == "rapidshot" then return "Rapid Shot" end
	if lower == "elemental magic casting time" then return "Elemental magic casting time" end
	if lower == "inquartata" then return "Inquartata" end
	if lower == "enhancing magic effect duration" or lower == "enh mag eff dur" or lower == "enh mag eff dur." then return "Enhancing magic effect duration" end
	if lower == "steal" then return "Steal" end
	if lower == "sneak attack" then return "Sneak Attack" end
	if lower == "trick attack" then return "Trick Attack" end
	if lower == "all songs" then return "All songs" end
	if lower == "song effect duration" then return "Song effect duration" end
	if lower == "song spellcasting time" then return "Song spellcasting time" end
	if lower == "pet: regen" then return "Pet: Regen" end
	if lower == "pet: damage taken" then return "Pet: Damage Taken" end
	if lower == "indicolure effect duration" then return "Indicolure effect duration" end
	if lower == "fast cast" or lower == "fastcast" or lower == "f.cast" or lower == "fcast" or lower == "fc" then return "Fast Cast" end
	if lower == "enemy critical hit rate" or lower == "enemy crit. hit rate" or lower == "enemy crit hit rate" or lower == "enemy crit rate" then return "Enemy critical hit rate" end
	if lower == "waltz" or lower == "waltz potency" then return "Waltz" end
	if lower == "block rate" or lower == "blk. rate" or lower == "blockrate" or lower == "chance of successful block" or lower == "shield block rate" then return "Block rate" end
	if lower == "zanshin" then return "Zanshin" end
	if lower == "tp bonus" or lower == "tp bonus+" or lower == "tpbonus" then return "TP Bonus" end
	if lower == "killer" or lower == "killer effects" or lower == "killer effect" then return "Killer" end
	if lower == "samba" or lower == "samba duration" then return "Samba" end
	if lower == "phalanx received" then return "Phalanx" end
	if name == "Cure Potency Recieved" or name == "Cure Potency Received" then return "Cure potency received" end
	if name == "Parrying Skill" then return "Parrying skill" end
	if name == "Shield Skill" then return "Shield skill" end
	if name == "Dark Magic Skill" then return "Dark Magic skill" end
	if name == "Enfeebling Magic Skill" then return "Enfeebling Magic skill" end
	if name == "Enhancing Magic Skill" then return "Enhancing Magic skill" end
	if name == "Healing Magic Skill" then return "Healing Magic skill" end
	if name == "DMG" then return "damage" end

	return name
end

local function parse_ody_aug_line(line, stats)
	line = ody_trim(line or "")
	if line == "" or line == "..." then
		return
	end

	local number_count = select(2, line:gsub("%d+", ""))
	if number_count > 1 and line:find(" / ", 1, true) then
		local pos = 1
		while true do
			local s, e = line:find(" / ", pos, true)
			if not s then
				parse_ody_aug_line(line:sub(pos), stats)
				break
			end
			parse_ody_aug_line(line:sub(pos, s - 1), stats)
			pos = e + 1
		end
		return
	end

	line = line:gsub("^L%d+:%s*", "")
	line = line:gsub("^&%s*", "")
	line = line:gsub("DMG:%s*", "DMG")
	line = line:gsub("\"Store TP\"", "Store TP")
	line = line:gsub("\"Dual Wield\"", "Dual Wield")
	line = line:gsub("\"Fast Cast\"", "Fast Cast")
	line = line:gsub("\"Dbl%.Atk%.\"", "Dbl.Atk.")
	line = line:gsub("Magic Attack Bonus", "Magic Atk. Bonus")
	line = line:gsub("Magic Attack", "Magic Atk. Bonus")
	line = line:gsub("Magic Defense Bonus", "Magic Def. Bonus")
	line = line:gsub("Critical Hit Rate", "Critical hit rate")
	line = line:gsub("Phys%. dmg%. taken", "Physical Damage Taken")
	line = line:gsub("Magic dmg%. taken", "Magic Damage Taken")
	line = line:gsub("Breath dmg%. taken", "Breath Damage Taken")
	line = line:gsub("Phys%. dmg%. limit", "Physical Damage Limit")

	if line:find("Avatar") or line:find("Wyvern") or line:find("Automaton") then
		return
	end

	local found = false
	for raw_stat_part, sign, value in line:gmatch("([^%+%-]+)([+-])(%d+)%s*%%?") do
		local stat_part = ody_trim(raw_stat_part)
		stat_part = stat_part:gsub("%s+", " ")
		if stat_part ~= "" then
			local signed_value = tonumber(value)
			if sign == "-" then
				signed_value = -signed_value
			end

			if stat_part == "All Base Stats" or stat_part == "All Attr." or stat_part == "All Attr" then
				for _, stat in ipairs({"STR", "DEX", "VIT", "AGI", "INT", "MND", "CHR"}) do
					ody_add_stat(stats, stat, signed_value)
				end
			elseif stat_part:find("/") or stat_part:find("&") then
				stat_part = stat_part:gsub("&", "/")
				for token in stat_part:gmatch("[^/]+") do
					token = ody_trim(token)
					if token ~= "" then
						local name = normalize_ody_stat_name(token)
						if name == "SIRD" then
							ody_add_stat(stats, name, math.abs(signed_value))
						else
							ody_add_stat(stats, name, signed_value)
						end
					end
				end
			else
				local name = normalize_ody_stat_name(stat_part)
				if name == "SIRD" then
					ody_add_stat(stats, name, math.abs(signed_value))
				else
					ody_add_stat(stats, name, signed_value)
				end
			end
			found = true
		end
	end

	if not found then
		return
	end
end

local function parse_ody_rank15_augments(aug_table)
	if type(aug_table) ~= "table" then
		return nil
	end

	local stats = T{}
	for _, key in ipairs({"Aug1", "Aug2", "Aug3", "Aug4", "Aug5"}) do
		if type(aug_table[key]) == "string" and aug_table[key] ~= "" then
			parse_ody_aug_line(aug_table[key], stats)
		end
	end

	if next(stats) == nil then
		return nil
	end
	return stats
end

-- Items that should never use Aug_escha (non-augmentable or static items)
local escha_block_ids = {
	[23732]=true, -- Malignance Chapeau
	[23733]=true, -- Malignance Tabard
	[23734]=true, -- Malignance Gloves
	[23735]=true, -- Malignance Tights
	[23736]=true, -- Malignance Boots
	[26088]=true, -- Malignance Earring
	[22298]=true, -- Aurgelmir Orb +1 (non-augmentable)
	[22297]=true, -- Aurgelmir Orb (non-augmentable)
}

local function escha_aug_allowed(edited_item)
	-- Aug_escha is meant for Escha/Reisenjima aug'd ARMOR (e.g. Valorous/Herculean/etc).
	-- Allowing it on weapons/ammo/accessories risks applying wrong augments by ID and
	-- makes "PDT/DT" go wrong on unrelated gear (e.g. grips/ammo).
	if not edited_item then
		return false
	end
	if edited_item.id and escha_block_ids[edited_item.id] then
		return false
	end
	if edited_item.category and edited_item.category ~= 'Armor' then
		return false
	end
	if type(edited_item.slots) ~= 'table' then
		return false
	end
	for _, slot_name in pairs(edited_item.slots) do
		if slot_name == 'Head' or slot_name == 'Body' or slot_name == 'Hands'
			or slot_name == 'Legs' or slot_name == 'Feet' then
			return true
		end
	end
	return false
end

-- Nyame path B items (to avoid double-counting when both extdata and static tables exist)
local nyame_ids = {
	[23761]=true,[23768]=true,[23775]=true,[23782]=true,[23789]=true
}

local debug_seen_ids = {}
local function debug_can_log(item_id)
	if not item_id then
		return false
	end
	if debug_seen_ids[item_id] then
		return false
	end
	debug_seen_ids[item_id] = true
	return true
end


function find_all_values(item)
	-- notice(item.id)
	local temp, augs = check_for_augments(item)
	if debug_mode and item and item.id and debug_can_log(item.id) then
		local name = (item.en or (res.items:with('id', item.id) and res.items:with('id', item.id).en)) or tostring(item.id)
		local aug_count = (type(augs) == 'table' and table.length(augs)) or 0
		log('[GI DEBUG] item '..tostring(name)..' id='..tostring(item.id)..' extdata_augments='..tostring(aug_count))
		if type(augs) == 'table' and aug_count > 0 then
			for _, aug in pairs(augs) do
				log('[GI DEBUG] aug: '..tostring(aug))
			end
		end
	end
	
	local item = res.items:with('id', item.id)
	
	if item and item.id then
	
		if res.item_descriptions[item.id] then
			item.discription = string.gsub(res.item_descriptions:with('id', item.id ).en, '\n', ' ') 
		else
			item.discription = 'none'
		end
		
		descript_table = T{}
		descript_table = desypher_description(item.discription, item)
		
		item.defined_job = T{}
		if type(item.jobs) == 'table' then
			for k, v in pairs(item.jobs) do
				item.defined_job[k] = res.jobs:with('id', k ).ens	
			end
		end
		
		item.defined_slots = T{}
		if type(item.slots) == 'table' then
			for k, v in pairs(item.slots) do
				item.defined_slots[k] = res.slots:with('id', k ).en	
			end
		end
	
		local edited_item = T{en=item.en, id=item.id, category=item.category , discription = item.discription, jobs = item.defined_job, slots = item.defined_slots}
		
			--item_level
		if item.item_level then
			edited_item.item_level = item.item_level
		end
		
		if augs then edited_item.augments = augs end
		
		for k, v in pairs(descript_table) do
			edited_item[k] = v
		end
		
		-- Check "Enhances \"Dual Wield\" effect" Gear for value
		for k, v in pairs(DW_Gear) do
			if item.id == k then
				if  edited_item['Dual Wield'] then
					edited_item['Dual Wield'] = edited_item['Dual Wield'] + v["Dual Wield"]
				else
					edited_item['Dual Wield'] = v["Dual Wield"]
				end
			end
		end
		
	local has_ext_aug = type(augs) == 'table' and table.length(augs) > 0

	-- Nyame pieces: description already includes the path stats; to avoid double counting,
	-- ignore extdata augments and skip Aug_DB for them.
	if nyame_ids[item.id] then
		temp = nil
		augs = nil
		has_ext_aug = false -- let Aug_DB supply the Path B stats, skip extdata to avoid bad reads
		if debug_mode then
			log('[GI DEBUG] Nyame: extdata ignored for id='..tostring(item.id))
		end
	end
		local has_parsed_ext_aug = false
		if type(temp) == 'table' then
			if next(temp) ~= nil then
				has_parsed_ext_aug = true
			end
			for stat, val in pairs(temp) do
				add_aug_value(edited_item, stat, val)
			end
			if has_parsed_ext_aug then
				edited_item['Extdata Augments Applied'] = true
			end
		end

		-- Check GearSwap back augments (fallback when no extdata augments).
		if not has_parsed_ext_aug and Aug_back and Aug_back[item.id]
			and not (Aug_un and Aug_un[item.id])
			and not (Aug_jse_necks and Aug_jse_necks[item.id])
			and not (Aug_SR and Aug_SR[item.id]) then
			local aug_entry = Aug_back[item.id]
			local stat_table = nil
			if type(aug_entry) == 'table' then
				if type(aug_entry.Aug1) == 'string' or type(aug_entry.Aug2) == 'string'
					or type(aug_entry.Aug3) == 'string' or type(aug_entry.Aug4) == 'string'
					or type(aug_entry.Aug5) == 'string' then
					stat_table = parse_ody_rank15_augments(aug_entry)
				else
					stat_table = aug_entry
				end
			end
			if type(stat_table) == 'table' then
				for stat, val in pairs(stat_table) do
					local key = stat
					local handled = false
					if type(key) == 'string' then
						if key:find("/") or key:find("&") then
							key = key:gsub("&", "/")
							for token in key:gmatch("[^/]+") do
								token = ody_trim(token)
								if token ~= "" then
									local name = normalize_ody_stat_name(token)
									local add_val = val
									if name == "SIRD" then
										add_val = math.abs(add_val)
									end
									add_aug_value(edited_item, name, add_val)
									edited_item['Unity Ranking Bonus Applied'] = name .. ' + ' ..tostring(add_val)
								end
							end
							handled = true
						else
							key = normalize_ody_stat_name(key)
						end
					end
					if not handled then
						local add_val = val
						if key == "SIRD" then
							add_val = math.abs(add_val)
						end
						add_aug_value(edited_item, key, add_val)
						edited_item['Unity Ranking Bonus Applied'] = key .. ' + ' ..tostring(add_val)
					end
				end
			end
		end

		-- Check GearSwap Escha/Reisenjima augments (fallback when no extdata augments).
		local allow_escha = escha_aug_allowed(edited_item)
		if allow_escha and not has_parsed_ext_aug and Aug_escha and Aug_escha[item.id]
			and not (Aug_un and Aug_un[item.id])
			and not (Aug_jse_necks and Aug_jse_necks[item.id])
			and not (Aug_back and Aug_back[item.id])
			and not (Aug_SR and Aug_SR[item.id]) then
			local aug_entry = Aug_escha[item.id]
			local stat_table = nil
			if type(aug_entry) == 'table' then
				if type(aug_entry.Aug1) == 'string' or type(aug_entry.Aug2) == 'string'
					or type(aug_entry.Aug3) == 'string' or type(aug_entry.Aug4) == 'string'
					or type(aug_entry.Aug5) == 'string' then
					stat_table = parse_ody_rank15_augments(aug_entry)
				else
					stat_table = aug_entry
				end
			end
			if type(stat_table) == 'table' then
				for stat, val in pairs(stat_table) do
					local key = stat
					local handled = false
					if type(key) == 'string' then
						if key:find("/") or key:find("&") then
							key = key:gsub("&", "/")
							for token in key:gmatch("[^/]+") do
								token = ody_trim(token)
								if token ~= "" then
									local name = normalize_ody_stat_name(token)
									local add_val = val
									if name == "SIRD" then
										add_val = math.abs(add_val)
									end
									add_aug_value(edited_item, name, add_val)
									edited_item['Unity Ranking Bonus Applied'] = name .. ' + ' ..tostring(add_val)
								end
							end
							handled = true
						else
							key = normalize_ody_stat_name(key)
						end
					end
					if not handled then
						local add_val = val
						if key == "SIRD" then
							add_val = math.abs(add_val)
						end
						add_aug_value(edited_item, key, add_val)
						edited_item['Unity Ranking Bonus Applied'] = key .. ' + ' ..tostring(add_val)
					end
				end
			end
		end

		-- Check Sinister Reign augments (fallback when no extdata augments).
		if not has_parsed_ext_aug and Aug_SR and Aug_SR[item.id]
			and not (Aug_un and Aug_un[item.id])
			and not (Aug_jse_necks and Aug_jse_necks[item.id])
			and not (Aug_back and Aug_back[item.id])
			and not (Aug_escha and Aug_escha[item.id]) then
			local aug_entry = Aug_SR[item.id]
			local stat_table = nil
			if type(aug_entry) == 'table' then
				if type(aug_entry.Aug1) == 'string' or type(aug_entry.Aug2) == 'string'
					or type(aug_entry.Aug3) == 'string' or type(aug_entry.Aug4) == 'string'
					or type(aug_entry.Aug5) == 'string' then
					stat_table = parse_ody_rank15_augments(aug_entry)
				else
					stat_table = aug_entry
				end
			end
			if type(stat_table) == 'table' then
				for stat, val in pairs(stat_table) do
					local key = stat
					local handled = false
					if type(key) == 'string' then
						if key:find("/") or key:find("&") then
							key = key:gsub("&", "/")
							for token in key:gmatch("[^/]+") do
								token = ody_trim(token)
								if token ~= "" then
									local name = normalize_ody_stat_name(token)
									local add_val = val
									if name == "SIRD" then
										add_val = math.abs(add_val)
									end
									add_aug_value(edited_item, name, add_val)
									edited_item['Unity Ranking Bonus Applied'] = name .. ' + ' ..tostring(add_val)
								end
							end
							handled = true
						else
							key = normalize_ody_stat_name(key)
						end
					end
					if not handled then
						local add_val = val
						if key == "SIRD" then
							add_val = math.abs(add_val)
						end
						add_aug_value(edited_item, key, add_val)
						edited_item['Unity Ranking Bonus Applied'] = key .. ' + ' ..tostring(add_val)
					end
				end
			end
			edited_item['Aug_SR_Source'] = true
		end

		-- Check Unity gear for stat and value.
		if Aug_jse_necks and Aug_jse_necks[item.id] then
			local aug_entry = Aug_jse_necks[item.id]
			local stat_table = nil
			if type(aug_entry) == 'table' then
				if type(aug_entry.Aug1) == 'string' or type(aug_entry.Aug2) == 'string' or type(aug_entry.Aug3) == 'string' then
					stat_table = parse_ody_rank15_augments(aug_entry)
				else
					stat_table = aug_entry
				end
			end
			if type(stat_table) == 'table' then
				for stat, val in pairs(stat_table) do
					local key = stat
					local handled = false
					if type(key) == 'string' then
						if key:find("/") or key:find("&") then
							key = key:gsub("&", "/")
							for token in key:gmatch("[^/]+") do
								token = ody_trim(token)
								if token ~= "" then
									local name = normalize_ody_stat_name(token)
									local add_val = val
									if name == "SIRD" then
										add_val = math.abs(add_val)
									end
									add_aug_value(edited_item, name, add_val)
									edited_item['Unity Ranking Bonus Applied'] = name .. ' + ' ..tostring(add_val)
								end
							end
							handled = true
						else
							key = normalize_ody_stat_name(key)
						end
					end
					if not handled then
						local add_val = val
						if key == "SIRD" then
							add_val = math.abs(add_val)
						end
						add_aug_value(edited_item, key, add_val)
						edited_item['Unity Ranking Bonus Applied'] = key .. ' + ' ..tostring(add_val)
					end
				end
			end
		end

		if Aug_un and Aug_un[item.id] then
			local aug_entry = Aug_un[item.id]
			local stat_table = nil
			if type(aug_entry) == 'table' then
				if type(aug_entry.Aug1) == 'string' or type(aug_entry.Aug2) == 'string' or type(aug_entry.Aug3) == 'string' then
					stat_table = parse_ody_rank15_augments(aug_entry)
				else
					stat_table = aug_entry
				end
			end
			if type(stat_table) == 'table' then
				for stat, val in pairs(stat_table) do
					local key = stat
					local handled = false
					if type(key) == 'string' then
						if key:find("/") or key:find("&") then
							key = key:gsub("&", "/")
							for token in key:gmatch("[^/]+") do
								token = ody_trim(token)
								if token ~= "" then
									local name = normalize_ody_stat_name(token)
									local add_val = val
									if name == "SIRD" then
										add_val = math.abs(add_val)
									end
									add_aug_value(edited_item, name, add_val)
									edited_item['Unity Ranking Bonus Applied'] = name .. ' + ' ..tostring(add_val)
								end
							end
							handled = true
						else
							key = normalize_ody_stat_name(key)
						end
					end
					if not handled then
						local add_val = val
						if key == "SIRD" then
							add_val = math.abs(add_val)
						end
						add_aug_value(edited_item, key, add_val)
						edited_item['Unity Ranking Bonus Applied'] = key .. ' + ' ..tostring(add_val)
					end
				end
			end
		else
			for k, v in pairs(Unity_rank) do
				if item.id == k then
					local value = math.floor(((v['rank']['max'] - v['rank']['min'])/ 11) * (11 - (settings.player.rank -1))) + v['rank']['min']
					if edited_item[v['Unity Ranking']] then
						-- edited_item[v['Unity Ranking']] = edited_item[v['Unity Ranking']] + v.rank[settings.rank]
						edited_item[v['Unity Ranking']] = edited_item[v['Unity Ranking']] + value
						edited_item['Unity Ranking Bonus Applied'] = v['Unity Ranking'] .. ' + ' ..tostring(value)
					else
						-- edited_item[v['Unity Ranking']] = v['rank'][settings.rank]
						edited_item[v['Unity Ranking']] = value
						edited_item['Unity Ranking Bonus Applied'] = v['Unity Ranking'] .. ' + ' ..tostring(value)
					end 
				end
			end
		end
		
		for k, v in pairs(Set_bonus_by_item_id) do
			if item.id == k then
				edited_item['Set Bonus'] = {["set id"] = v["set id"], ["bonus"] = v["bonus"] }
			end		
		end
		
		if item.category == 'Weapon' then
			for k,v in pairs(item) do
				-- if k == 'delay' then	
					-- edited_item[k] = tonumber(v)
				-- end
				if k == 'skill' then
					local skill = res.skills:with('id', v ).en
					edited_item[k] = skill
				end
			end
		end
		
		-- Static augments: apply only when extdata didn't yield actual stats (Path-only extdata should not block Aug_DB).
		if Aug_DB and item and item.id and Aug_DB[item.id] then
			if nyame_ids[item.id] then
				if not has_parsed_ext_aug then
					for stat, val in pairs(Aug_DB[item.id]) do
						add_aug_value(edited_item, stat, val)
					end
					edited_item['Aug_DB_Source'] = true
				end
			elseif not has_parsed_ext_aug then
				for stat, val in pairs(Aug_DB[item.id]) do
					add_aug_value(edited_item, stat, val)
				end
				edited_item['Aug_DB_Source'] = true
			end
			-- Nyame safeguard: enforce DA exactly from Aug_DB to avoid any double/zero issues
			if nyame_ids[item.id] and Aug_DB[item.id]["Double Attack"] then
				edited_item["Double Attack"] = Aug_DB[item.id]["Double Attack"]
				if edited_item._aug_only then
					edited_item._aug_only["Double Attack"] = Aug_DB[item.id]["Double Attack"]
				end
				if debug_mode then
					log('[GI DEBUG] Nyame: DA forced to '..tostring(edited_item["Double Attack"])..' for id='..tostring(item.id))
				end
			end
		end
		
		if not has_parsed_ext_aug and Aug_ody and Aug_ody.unity_rank15 and item and item.id and Aug_ody.unity_rank15[item.id]
			and not (Aug_un and Aug_un[item.id])
			and not (Aug_jse_necks and Aug_jse_necks[item.id]) then
			local ody_stats = parse_ody_rank15_augments(Aug_ody.unity_rank15[item.id])
			if ody_stats then
				for stat, val in pairs(ody_stats) do
					add_aug_value(edited_item, stat, val)
				end
			end
			edited_item['Odyssey Rank15 Augments'] = Aug_ody.unity_rank15[item.id]
		end

		return edited_item
	end
		
end

function check_for_augments(item)
	local augs = nil
	if item and item.extdata and item.id and ExtdataLib and ExtdataLib.decode then
		local ok, decoded = pcall(ExtdataLib.decode, item)
		if ok and decoded and type(decoded.augments) == 'table' then
			augs = decoded.augments
		end
	end

	local item_t = res.items:with('id', item.id)
	local temp = T{}
	if augs then
		for _, v in pairs(augs) do
			if v:contains('Wyvern:') or v:contains('Avatar:') then
				-- skip wyvern/avatar augments
			else
				for i, j in pairs(desypher_description(v, item_t)) do
					if temp[i] then
						temp[i] = temp[i] + j
					else
						temp[i] = j
					end
				end
			end
		end
	end

	return temp, augs
end

function desypher_description(discription_string, item_t)
	local lq = string.char(226,128,156)
	local rq = string.char(226,128,157)
	local lsq = string.char(226,128,152)
	local rsq = string.char(226,128,153)
	discription_string = string.gsub(discription_string, lq, '"')
	discription_string = string.gsub(discription_string, rq, '"')
	discription_string = string.gsub(discription_string, lsq, "'")
	discription_string = string.gsub(discription_string, rsq, "'")
	
	-- string that need modifying to stop clashing
	discription_string = string.gsub(discription_string, 'Ranged Accuracy%s?', 'Ranged_accuracy') 
	discription_string = string.gsub(discription_string, 'Rng.%s?Acc.%s?', 'Ranged_accuracy')  
	discription_string = string.gsub(discription_string, 'Ranged Attack%s?', 'Ranged_attack') 
	discription_string = string.gsub(discription_string, 'Rng.%s?Atk.%s?', 'Ranged_attack') 

	-- normalize pet prefix
	discription_string = string.gsub(discription_string, '[Pp]et:%s*', 'Pet: ')
	
	discription_string = string.gsub(discription_string, 'Magic Accuracy%s?', 'Magic_accuracy')
	discription_string = string.gsub(discription_string, 'Mag.%s?Acc.%s?', 'Magic_accuracy') 	
	discription_string = string.gsub(discription_string, 'Magic Acc.%s?', 'Magic_accuracy') 
	
	discription_string = string.gsub(discription_string, '\"Magic Atk. Bonus\"', 'Magic Atk. Bonus' )
	discription_string = string.gsub(discription_string, '\"Mag.%s?Atk.%s?Bns.\"', 'Magic Atk. Bonus' ) 
	discription_string = string.gsub(discription_string, '\"Enmity\"', 'Enmity' )
	discription_string = string.gsub(discription_string, '\"Regen\"', 'Regen' )
	discription_string = string.gsub(discription_string, '\"Regain\"', 'Regain' )
	discription_string = string.gsub(discription_string, '\"Refresh\"', 'Refresh' )
	discription_string = string.gsub(discription_string, '\"Subtle Blow II\"', 'Subtle Blow II' )
	discription_string = string.gsub(discription_string, '\"Subtle Blow\"', 'Subtle Blow' )
	discription_string = string.gsub(discription_string, '\"Conserve MP\"', 'Conserve MP' )
	discription_string = string.gsub(discription_string, '\"Counter\"', 'Counter' )
	discription_string = string.gsub(discription_string, '\"Treasure Hunter\"', 'Treasure Hunter' )
	discription_string = string.gsub(discription_string, '\"Fast Cast\"', 'Fast Cast' )
	discription_string = string.gsub(discription_string, 'fastcast', 'Fast Cast' )
	discription_string = string.gsub(discription_string, 'Fastcast', 'Fast Cast' )
	discription_string = string.gsub(discription_string, 'Cure potency II', 'Cure potency II' )
	discription_string = string.gsub(discription_string, 'Cure Potency II', 'Cure potency II' )
	discription_string = string.gsub(discription_string, 'Cure potency', 'Cure potency' )
	discription_string = string.gsub(discription_string, 'Cure Potency', 'Cure potency' )
	discription_string = string.gsub(discription_string, 'Enemy critical hit rate', 'Enemy critical hit rate' )
	discription_string = string.gsub(discription_string, 'Enemy crit%. hit rate', 'Enemy critical hit rate' )
	discription_string = string.gsub(discription_string, 'Enemy crit hit rate', 'Enemy critical hit rate' )
	discription_string = string.gsub(discription_string, 'Quick Cast', 'Quick Cast' )
	discription_string = string.gsub(discription_string, 'Occ. quickens spellcasting', 'Quick Cast' )
	discription_string = string.gsub(discription_string, 'Cure Spellcasting Time', 'Cure spellcasting time' )
	discription_string = string.gsub(discription_string, 'Healing Magic Casting Time', 'Healing magic casting time' )
	discription_string = string.gsub(discription_string, 'Snapshot', 'Snapshot' )
	discription_string = string.gsub(discription_string, 'Rapid Shot', 'Rapid Shot' )
	discription_string = string.gsub(discription_string, 'Elemental Magic Casting Time', 'Elemental magic casting time' )
	discription_string = string.gsub(discription_string, 'Inquartata', 'Inquartata' )
	discription_string = string.gsub(discription_string, 'Enhancing Magic Effect Duration', 'Enhancing magic effect duration' )
	discription_string = string.gsub(discription_string, 'Enh. Mag. Eff. Dur.', 'Enhancing magic effect duration' )
	discription_string = string.gsub(discription_string, 'Enh. Mag. Eff. Dur', 'Enhancing magic effect duration' )
	discription_string = string.gsub(discription_string, 'Steal', 'Steal' )
	discription_string = string.gsub(discription_string, 'Sneak Attack', 'Sneak Attack' )
	discription_string = string.gsub(discription_string, 'Trick Attack', 'Trick Attack' )
	discription_string = string.gsub(discription_string, 'All songs', 'All songs' )
	discription_string = string.gsub(discription_string, 'Song effect duration', 'Song effect duration' )
	discription_string = string.gsub(discription_string, 'Song spellcasting time', 'Song spellcasting time' )
	discription_string = string.gsub(discription_string, 'Pet: Regen', 'Pet: Regen' )
	discription_string = string.gsub(discription_string, 'Pet: Damage Taken', 'Pet: Damage Taken' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Physical Damage Taken', 'Pet: Physical Damage Taken' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Phys.%s?Dmg.%s?Taken', 'Pet: Physical Damage Taken' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Magic Damage Taken', 'Pet: Magic Damage Taken' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Mag.%s?Dmg.%s?Taken', 'Pet: Magic Damage Taken' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Haste', 'Pet: Haste' )
	discription_string = string.gsub(discription_string, 'Potency of cure effects received', 'Cure potency received' )
	discription_string = string.gsub(discription_string, 'Cure Potency Received', 'Cure potency received' )
	discription_string = string.gsub(discription_string, 'Indicolure effect duration', 'Indicolure effect duration' )
	discription_string = string.gsub(discription_string, 'Blood Pact delay II', 'Blood Pact Delay II' )
	discription_string = string.gsub(discription_string, 'Blood Pact delay', 'Blood Pact Delay' )
	discription_string = string.gsub(discription_string, 'Blood Pact Dmg', 'Blood Pact Damage' )
	discription_string = string.gsub(discription_string, 'Blood Pact dmg', 'Blood Pact Damage' )
	discription_string = string.gsub(discription_string, 'Avatar:%s*Perpetuation cost', 'Avatar Perpetuation Cost' )
	discription_string = string.gsub(discription_string, 'Avatar perpetuation cost', 'Avatar Perpetuation Cost' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Dbl%.%s?Atk%.?', 'Pet: Double Attack' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Atk%.?', 'Pet: Attack' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Acc%.?', 'Pet: Accuracy' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Blood Pact Dmg', 'Pet: Blood Pact Damage' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Blood Pact dmg', 'Pet: Blood Pact Damage' )
	discription_string = string.gsub(discription_string, 'Waltz potency', 'Waltz potency' )
	discription_string = string.gsub(discription_string, 'Block rate', 'Block rate' )
	discription_string = string.gsub(discription_string, 'Chance of successful block', 'Block rate' )
	discription_string = string.gsub(discription_string, 'Shield Block Rate', 'Block rate' )
	discription_string = string.gsub(discription_string, 'TP Bonus', 'TP Bonus' )
	discription_string = string.gsub(discription_string, 'Killer effects', 'Killer effects' )
	discription_string = string.gsub(discription_string, 'Samba duration', 'Samba' )
	discription_string = string.gsub(discription_string, 'Dbl%.%s?Atk%.?', 'Double Attack' )
	discription_string = string.gsub(discription_string, 'Dbl%.Atk%.?', 'Double Attack' )
	discription_string = string.gsub(discription_string, 'Weapon Skill Accuracy', 'WS Acc' )
	discription_string = string.gsub(discription_string, 'Weapon Skill Acc%.?', 'WS Acc' )
	discription_string = string.gsub(discription_string, 'Trip%. Atk%.?', 'Triple Attack' )
	discription_string = string.gsub(discription_string, 'Triple Atk%.?', 'Triple Attack' )
	discription_string = string.gsub(discription_string, 'Magic Attack Bonus', 'Magic Atk. Bonus' )
	discription_string = string.gsub(discription_string, 'Magic Attack', 'Magic Atk. Bonus' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Magic Attack Bonus', 'Pet: Magic Atk. Bonus' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Mag.%s?Atk.%s?Bns.%s?', 'Pet: Magic Atk. Bonus' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Magic Acc.%s?', 'Pet: Magic Accuracy' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Mag.%s?Acc.%s?', 'Pet: Magic Accuracy' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Accuracy', 'Pet: Accuracy' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Acc.%s?', 'Pet: Accuracy' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Attack', 'Pet: Attack' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Double Attack', 'Pet: Double Attack' )
	discription_string = string.gsub(discription_string, 'Pet:%s*Dbl.%s?Atk.%s?', 'Pet: Double Attack' )
	discription_string = string.gsub(discription_string, 'Summoning magic skill', 'Summoning Magic skill' )
	discription_string = string.gsub(discription_string, '\"Magic Burst Bonus\"', 'Magic Burst Bonus' )
	discription_string = string.gsub(discription_string, '\"Skillchain Bonus\"', 'Skillchain Bonus' )
	discription_string = string.gsub(discription_string, '\"Skillchain Damage\"', 'Skillchain Damage' )
	
	discription_string = string.gsub(discription_string, 'M%.Dmg%.?', 'Magic Damage' )
	discription_string = string.gsub(discription_string, 'M%.Def%.Bn%.?', 'Magic Def. Bonus' )
	discription_string = string.gsub(discription_string, 'M%.Eva%.?', 'Magic Evasion' )
	discription_string = string.gsub(discription_string, 'Magic Evasion', 'Magic_evasion' )
	discription_string = string.gsub(discription_string, '\"Magic Def. Bonus\"', 'Magic Def. Bonus' )

	discription_string = string.gsub(discription_string, 'Magic burst damage II', 'Magic Burst Damage II')
	discription_string = string.gsub(discription_string, 'Magic burst damage', 'Magic Burst Damage')
	discription_string = string.gsub(discription_string, 'Magic Burst DMG', 'Magic Burst Damage')
	discription_string = string.gsub(discription_string, 'Physical damage limit', 'PDL')
	discription_string = string.gsub(discription_string, 'Physical Damage Limit', 'PDL')
	discription_string = string.gsub(discription_string, 'Spell interruption rate down', 'SIRD')
	discription_string = string.gsub(discription_string, 'Spell interruption rate', 'SIRD')
	discription_string = string.gsub(discription_string, 'Phalanx received', 'Phalanx')
	
	discription_string = string.gsub(discription_string, 'Crit. hit damage', 'Critical hit damage' )
	discription_string = string.gsub(discription_string, 'Crit. hit rate', 'Critical hit rate' )

	discription_string = string.gsub(discription_string, 'Physical damage taken II', 'PDT_2' )
	discription_string = string.gsub(discription_string, 'Physical damage taken', 'PDT' )
	discription_string = string.gsub(discription_string, 'Breath damage taken', 'BDT' )
	discription_string = string.gsub(discription_string, 'Breath dmg. taken', 'BDT' )
	discription_string = string.gsub(discription_string, 'Magic damage taken II', 'MDT_2' )
	discription_string = string.gsub(discription_string, 'Magic damage taken', 'MDT' )
	discription_string = string.gsub(discription_string, 'Phys. dmg. taken', 'PDT' )
	discription_string = string.gsub(discription_string, 'Magic dmg. taken', 'MDT' )
	discription_string = string.gsub(discription_string, 'Magic dmg%. taken', 'MDT' )
	discription_string = string.gsub(discription_string, 'Damage taken', 'D_T' )

	-- remove remaining quotes after normalization (e.g., "Treasure Hunter")
	discription_string = string.gsub(discription_string, '"', '')
	
	discription_string = string.gsub(discription_string, 'Weapon skill DEX', 'WS_dex' )
	
	discription_string = string.gsub(discription_string,  "Great Axe skill",  "Great axe skill")
	discription_string = string.gsub(discription_string,  "Great Katana skill",  "Great katana skill")
	discription_string = string.gsub(discription_string,  "Great Sword skill",  "Great sword skill")
	
	local str_table = ''
	
	if discription_string:contains('Wyvern:') then
		str_table = discription_string:psplit("Wyvern:")
		discription_string = str_table[1]
	elseif discription_string:contains('Luopan:') then
		str_table = discription_string:psplit("Luopan:")
		discription_string = str_table[1]
	elseif discription_string:contains('Latent effect:') then
		str_table = discription_string:psplit("Latent effect:")
		discription_string = str_table[1]
	elseif discription_string:contains('Unity Ranking:') then
		str_table = discription_string:psplit("Unity Ranking:")
		discription_string = str_table[1]
	end

	local valid_strings = L{'Delay','DEF','HP','MP','STR','DEX','VIT','AGI','INT','MND','CHR',
								'Accuracy','Acc.','Attack','Atk.',
								'Ranged_accuracy', 'Ranged_attack',
								'Magic_accuracy', 'Magic Atk. Bonus', 'Magic Damage', 'Magic Def. Bonus', 'Magic_evasion',
								'Haste','\"Slow\"','Slow','\"Store TP\"','\"Dual Wield\"','\"Fast Cast\"','\"Martial Arts\"',
								'Store TP','Dual Wield','Fast Cast','Martial Arts',
								'"Treasure Hunter"','Treasure Hunter','Cure potency','Cure potency II','Enemy critical hit rate','Waltz','Waltz potency',
								'Quick Cast','Cure spellcasting time','Healing magic casting time',
								'Snapshot','Rapid Shot','Elemental magic casting time','Inquartata',
								'Enhancing magic effect duration','Steal','Sneak Attack','Trick Attack',
								'All songs','Song effect duration','Song spellcasting time',
								'Pet: Regen','Pet: Damage Taken','Pet: Physical Damage Taken','Pet: Magic Damage Taken','Indicolure effect duration',
								'Pet: Haste','Cursna','Cure potency received',
								'Blood Pact Delay','Blood Pact Delay II','Blood Pact Damage','Avatar Perpetuation Cost',
								'Pet: Magic Atk. Bonus','Pet: Attack','Pet: Double Attack','Pet: Accuracy','Pet: Magic Accuracy',
								'Pet: Blood Pact Damage','Pet: Magic Damage',
								'Block rate','Zanshin','TP Bonus','Killer','Killer effects','Samba',
								'DMG','PDT','MDT','BDT','D_T','MDT_2','PDT_2','PDL','SIRD','WS Acc',
								'Evasion',
								'Critical hit damage' ,'Critical hit rate', 
								'\"Double Attack\"','\"Triple Attack\"','\"Quadruple Attack\"',
								'Double Attack','Triple Attack','Quadruple Attack',
								'Counter','Subtle Blow','Subtle Blow II','Conserve MP',
								'Magic Burst Damage','Magic Burst Damage II','Magic Burst Bonus','Skillchain Bonus','Skillchain Damage',
								'Regen','Regain','Refresh','Enmity',
								"Hand%-to%-Hand skill", "Dagger skill", "Sword skill", "Great sword skill", "Axe skill", "Great axe skill",  "Scythe skill", "Polearm skill", 
								"Katana skill", "Great katana skill", "Club skill",  "Staff skill", "Archery skill", "Marksmanship skill" , "Throwing skill","Guarding skill","Evasion skill","Shield skill","Parrying skill",
								"Divine Magic skill","Healing Magic skill","Enhancing Magic skill","Enfeebling Magic skill","Elemental Magic skill","Dark Magic skill","Summoning Magic skill","Ninjutsu skill","Singing skill",
								"Stringed Instrument skill","Wind Instrument skill","Blue Magic skill","Geomancy skill","Handbell skill",
								"Phalanx",'All magic skills','All skills','Combat skills','Magic skills',
								}
	
	local temp_table = T{}
	local temp_key = { 
		['Delay'] = 'delay',
		["Acc."] = "Accuracy",
		["Atk."] = 'Attack',
		['\"Slow\"'] = 'Slow',
		['Slow'] = 'Slow',
		['\"Store TP\"'] = 'Store TP', 
		['\"Dual Wield\"'] = 'Dual Wield' ,
		['\"Fast Cast\"'] = 'Fast Cast' ,
		['Magic_accuracy'] = 'Magic Accuracy' , 
		['Ranged_accuracy'] =  'Ranged Accuracy' ,
		['Ranged_attack'] =  'Ranged Attack' ,
		['Magic_evasion'] = 'Magic Evasion',
		['Treasure Hunter'] = 'Treasure Hunter',
		['Quick Cast'] = 'Quick Cast',
		['Cure spellcasting time'] = 'Cure spellcasting time',
		['Healing magic casting time'] = 'Healing magic casting time',
		['Snapshot'] = 'Snapshot',
		['Rapid Shot'] = 'Rapid Shot',
		['Elemental magic casting time'] = 'Elemental magic casting time',
		['Inquartata'] = 'Inquartata',
		['Enhancing magic effect duration'] = 'Enhancing magic effect duration',
		['Steal'] = 'Steal',
		['Sneak Attack'] = 'Sneak Attack',
		['Trick Attack'] = 'Trick Attack',
		['All songs'] = 'All songs',
		['Song effect duration'] = 'Song effect duration',
		['Song spellcasting time'] = 'Song spellcasting time',
		['Pet: Regen'] = 'Pet: Regen',
		['Pet: Damage Taken'] = 'Pet: Damage Taken',
		['Pet: Physical Damage Taken'] = 'Pet: Physical Damage Taken',
		['Pet: Magic Damage Taken'] = 'Pet: Magic Damage Taken',
		['Pet: Haste'] = 'Pet: Haste',
		['Indicolure effect duration'] = 'Indicolure effect duration',
		['Cursna'] = 'Cursna',
		['Cure potency received'] = 'Cure potency received',
		['Cure potency'] = 'Cure potency',
		['Cure potency II'] = 'Cure potency II',
		['Enemy critical hit rate'] = 'Enemy critical hit rate',
		['Waltz potency'] = 'Waltz',
		['Waltz'] = 'Waltz',
		['Block rate'] = 'Block rate',
		['Zanshin'] = 'Zanshin',
		['TP Bonus'] = 'TP Bonus',
		['Killer effects'] = 'Killer',
		['Killer'] = 'Killer',
		['Samba'] = 'Samba',
		["Great axe skill"] = "Great Axe skill" ,
		["Great katana skill"] = "Great Katana skill",
		["Great sword skill"] = "Great Sword skill",
		['DMG'] = 'damage',
		['D_T'] = 'DT',
		['MDT_2'] = 'MDT2',
		['PDT_2'] = 'PDT2',
		['\"Martial Arts\"'] = 'Martial Arts',
		['WS_dex'] = 'Weapon skill DEX',
		['\"Quadruple Attack\"'] = 'Quadruple Attack',
		['\"Triple Attack\"'] = 'Triple Attack',
		['\"Double Attack\"'] = 'Double Attack',
		['WS Acc'] = 'Accuracy',
	}
	
	for k, v in pairs(valid_strings) do
		-- v = DEF etc
		pattern = "("..v.."):?%s?([+-]?%d+)"
		for key , val in discription_string:gmatch(pattern) do
			if key == 'SIRD' then
				val = math.abs(tonumber(val))
			end
			if temp_key[key] then
				temp_table[temp_key[key]] = tonumber(val)
			else
				temp_table[key] = tonumber(val)	
			end
			-- if item_t then
				-- if item_t.id == 20540 then
					-- notice('('..discription_string .. ') '..key .. ' ' ..val)
				-- end
			-- end
		end
	end
	return temp_table
end

function get_equip_stats(equipment_table)

	local stat_table = { ['Haste'] = 0, ['Slow'] = 0, ['Dual Wield'] = 0, ['Store TP'] = 0, ['Accuracy'] = 0, ['Attack'] = 0, ['Ranged Accuracy'] = 0, ['Ranged Attack'] = 0, ['Magic Accuracy'] = 0,
									['Magic Atk. Bonus'] = 0, ['Magic Burst Damage'] = 0, ['Magic Burst Damage II'] = 0, ['Magic Burst Bonus'] = 0,
									['Skillchain Bonus'] = 0, ['Skillchain Damage'] = 0, ['PDL'] = 0, ['SIRD'] = 0,
									['Regen'] = 0, ['Regain'] = 0, ['Refresh'] = 0, ['Enmity'] = 0,
									['Evasion'] = 0,
									['Magic Damage'] = 0, ['Magic Def. Bonus'] = 0, ['Magic Evasion'] = 0,
									['Counter'] = 0, ['Conserve MP'] = 0,
									['Subtle Blow'] = 0, ['Subtle Blow II'] = 0,
									['Critical hit rate'] = 0, ['Critical hit damage'] = 0,
									['Double Attack'] = 0, ['Triple Attack'] = 0, ['Quadruple Attack'] = 0,

									['DT'] = 0, ['PDT'] = 0, ['PDT2'] = 0, ['MDT'] = 0, ['MDT2'] = 0, ['BDT'] = 0,
									['DEF'] = 0,
							 
									["MND"]=0, ["AGI"]=0, ["DEX"]=0, ["VIT"]=0, ["STR"]=0, ["INT"]=0,  ["CHR"]=0, 
							 
									["Hand-to-Hand skill"]=0, ["Dagger skill"]=0, ["Sword skill"]=0, ["Great Sword skill"]=0, ["Axe skill"]=0, ["Great Axe skill"]=0, ["Scythe skill"]=0, ["Polearm skill"]=0, 
									["Katana skill"]=0, ["Great Katana skill"]=0,["Club skill"]=0,["Staff skill"]=0,["Archery skill"]=0,["Marksmanship skill"]=0,["Throwing skill"]=0,["Parrying skill"]=0,['Combat skills']=0,
									
									['Evasion skill'] = 0,
									
									['main'] = {['skill'] = '', value = 0}, ['sub'] = {['skill'] = '', value = 0}, ['range'] = {['skill'] = '', value = 0}, ['ammo'] = {['skill'] = '', value = 0},
								}
								
	local melee_skills = L{"Hand-to-Hand skill", "Dagger skill", "Sword skill", "Great Sword skill", "Axe skill", "Great Axe skill", "Scythe skill", "Polearm skill", "Katana skill", "Great Katana skill", "Club skill", "Staff skill"}
	local ranged_skills = L{"Archery skill", "Marksmanship skill", "Throwing skill"}
							
	local set_bonus = {}
	
	if type(equipment_table) ~= 'table' or equipment_table == nil then
		error('get_equip_stats() function went wrong')
		return stat_table
	else	
		for equip_slot, equipped_item in pairs(equipment_table) do
			--log(equip_slot)
			for key, value in pairs(equipped_item) do
				--if equip_slot == 'main' then log(key) end
				if stat_table[key] or (key == 'skill' and stat_table[value..' skill']) then
					if equipped_item["category"]=="Weapon" then
						if equipped_item['skill'] then
							stat_table[equip_slot]['skill'] =  equipped_item['skill']
							if 	equipped_item[equipped_item['skill'] ..' skill'] then
								stat_table[equip_slot].value =  equipped_item[equipped_item['skill'] ..' skill']
							end
						end
						if not melee_skills:contains(key) and not ranged_skills:contains(key) and not (key == 'skill' and stat_table[value..' skill']) then
							if key == 'Haste' then
								stat_table['Haste'] = stat_table['Haste'] + math.floor(value / 100 * 1024)
							elseif key == 'Slow' then
								stat_table['Haste'] = stat_table['Haste'] - math.floor(value / 100 * 1024)
							elseif key == 'Combat skills' then
								stat_table['main'].value = stat_table['main'].value + value
								stat_table['sub'].value = stat_table['sub'].value + value
								stat_table['range'].value = stat_table['range'].value + value
								stat_table['ammo'].value = stat_table['ammo'].value + value
							else
								stat_table[key] = stat_table[key] + value
							end
						end
					else
						if key == 'Haste' then
							stat_table['Haste'] = stat_table['Haste'] + math.floor(value / 100 * 1024)
						elseif key == 'Slow' then
							stat_table['Haste'] = stat_table['Haste'] - math.floor(value / 100 * 1024)
						elseif key == 'Combat skills' then
							stat_table['main'].value = stat_table['main'].value + value
							stat_table['sub'].value = stat_table['sub'].value + value
							stat_table['range'].value = stat_table['range'].value + value
							stat_table['ammo'].value = stat_table['ammo'].value + value
						else
							stat_table[key] = stat_table[key] + value
						end
					end
				elseif equip_slot == 'main' and equipped_item.en == '' then
					stat_table['main']['skill'] = 'Hand-to-Hand'
				end
				if key == "Set Bonus" then
					if type(value["set id"]) == 'table' then
						for i, j  in pairs(value["set id"]) do
							if set_bonus[j]  then
								set_bonus[j] = set_bonus[j] + 1
							else
								set_bonus[j]  = 1
							end
						end
					else
						if set_bonus[value["set id"]] then
							set_bonus[value["set id"]] = set_bonus[value["set id"]] + 1
						else
							set_bonus[value["set id"]]  = 1
						end
					end
				end
			end
		end

		for k, v in pairs(set_bonus) do
			if v > 1 then
				if v >= Set_bonus_by_Set_ID[k]["minimum peices"] then
					if Set_bonus_by_Set_ID[k]["bonus"][v] then
						for key, value in pairs(Set_bonus_by_Set_ID[k]["bonus"][v]) do
							if stat_table[key] then
								stat_table[key] = stat_table[key] + value
							end
						end
					end
				end
			end
		end
	end
	-- table.vprint(stat_table['main'])
	stat_table['Haste'] = stat_table['Haste'] + manual_ghaste
	stat_table['Dual Wield'] = stat_table['Dual Wield'] + manual_dw
	stat_table['Store TP'] = stat_table['Store TP'] + manual_stp
	
	return stat_table
	
end

function get_player_acc(stat_table)
	local function clone_stat_table(src)
		local out = {}
		if type(src) ~= 'table' then
			return out
		end
		for k, v in pairs(src) do
			if type(v) == 'table' then
				out[k] = {}
				for kk, vv in pairs(v) do
					out[k][kk] = vv
				end
			else
				out[k] = v
			end
		end
		return out
	end

	-- Never mutate the live Gear_info table while rendering. Mutating here causes
	-- Acc/Eva/etc to grow on every refresh tick.
	local st = clone_stat_table(stat_table)
	
	for skill_name, value in pairs(player_base_skills) do
		--log(st['range'].skill:lower())
		--notice(main_hand.skill)
		--log(skill_name  .. ' | ' .. string.gsub(st['main'].skill:lower(), ' ', '_'))
		if st['main'] and st['main'].skill and skill_name == string.gsub(st['main'].skill:lower(), ' ', '_') then
			--log(st['main'].value..'  ' ..value.. '  '..st[st['main'].skill .. ' skill'])
			local skill_bonus = tonumber(st[st['main'].skill .. ' skill']) or 0
			st['main'].value = (tonumber(st['main'].value) or 0) + value + skill_bonus
		end
		if st['sub'] and st['sub'].skill and skill_name == string.gsub(st['sub'].skill:lower(), ' ', '_') then
			local skill_bonus = tonumber(st[st['sub'].skill .. ' skill']) or 0
			st['sub'].value = (tonumber(st['sub'].value) or 0) + value + skill_bonus
		end
		if st['range'] and st['range'].skill and skill_name == string.gsub(st['range'].skill:lower(), ' ', '_') and player.equipment.range['damage'] then
			local skill_bonus = tonumber(st[st['range'].skill .. ' skill']) or 0
			st['range'].value = (tonumber(st['range'].value) or 0) + value + skill_bonus
		end
		if st['ammo'] and st['ammo'].skill and skill_name == string.gsub(st['ammo'].skill:lower(), ' ', '_') and player.equipment.ammo['damage'] then
			local skill_bonus = tonumber(st[st['ammo'].skill .. ' skill']) or 0
			st['ammo'].value = (tonumber(st['ammo'].value) or 0) + value + skill_bonus
		end
	end
	
	if player.stats then
		for stat, value in pairs(player.stats) do
			if st[stat] then 
				st[stat] = st[stat] + value 
			end	
		end
	end

	
	st = get_blue_mage_stats_from_equipped_spells(st)
	
	local Total_acc = {main = 0, sub = 0, range = 0, ammo = 0, dex = 0, agi = 0}
	local main_acc_skill = acc_from_skill((st['main'] and st['main'].value) or 0)
	local sub_acc_skill = acc_from_skill((st['sub'] and st['sub'].value) or 0)
	local ranged_acc_skill = racc_from_skill((st['range'] and st['range'].value) or 0)
	local ammo_acc_skill = racc_from_skill((st['ammo'] and st['ammo'].value) or 0)
	Total_acc.dex = math.floor((tonumber(st['DEX']) or 0) * 0.75)
	Total_acc.agi = math.floor((tonumber(st['AGI']) or 0) * 0.75)
	
	Total_acc.main = main_acc_skill + math.floor(((tonumber(st['DEX']) or 0) + Buffs_inform['DEX']) * 0.75) + (tonumber(st['Accuracy']) or 0) + get_player_acc_from_job() + Buffs_inform['Accuracy']

	if player.equipment.sub.id ~= 0 and player.equipment.sub.category == 'Weapon' and player.equipment.sub.damage then
		Total_acc.sub = sub_acc_skill + math.floor(((tonumber(st['DEX']) or 0) + Buffs_inform['DEX']) * 0.75) + (tonumber(st['Accuracy']) or 0) + get_player_acc_from_job() + Buffs_inform['Accuracy']
	else
		Total_acc.sub = 0
	end
	if player.equipment.range.id ~= 0 and player.equipment.range.category == 'Weapon' and player.equipment.range['damage'] then
		Total_acc.range = ranged_acc_skill + math.floor(((tonumber(st['AGI']) or 0) + Buffs_inform['AGI']) * 0.75) + (tonumber(st['Ranged Accuracy']) or 0) + get_player_acc_from_job() + Buffs_inform['Ranged Accuracy']
	else
		Total_acc.range = 0
	end
	if player.equipment.ammo.id ~= 0 and player.equipment.ammo.category == 'Weapon' and player.equipment.ammo['damage'] then
		Total_acc.ammo = ammo_acc_skill + math.floor(((tonumber(st['AGI']) or 0) + Buffs_inform['AGI']) * 0.75) + (tonumber(st['Ranged Accuracy']) or 0) + get_player_acc_from_job() + Buffs_inform['Ranged Accuracy']
	else
		Total_acc.ammo = 0
	end
	
	--notice('Main Acc = '.. Total_acc.main .. ' | Off hand Acc = '.. Total_acc.sub .. ' | Ranged Acc = '.. Total_acc.range .. ' | ammo Acc = '.. Total_acc.ammo)
	--log('Dex = '.. stat_table['DEX'] .. ' | Main skill  = '.. stat_table['main'].value .. ' | Sub skill = '.. stat_table['sub'].value .. ' | job acc = ' ..get_player_acc_from_job() .. ' | gear acc = ' .. stat_table['Accuracy'])
	--log('Agi = '.. stat_table['AGI'] .. ' | Range skill  = '.. stat_table['range'].value .. ' | Ammo skill = '.. stat_table['ammo'].value .. ' | job acc = ' ..get_player_acc_from_job().. ' | gear r.acc = ' .. stat_table['Ranged Accuracy'])
	
	--log(main_acc_skill.. ' ' .. item_acc .. ' ' .. get_player_acc_from_job() .. ' ' .. main_hand.value .. ' ' .. skill_from_gear_main .. ' ' ..item_dex .. ' ' .. player_dex )
	--log(ammo_acc_skill.. ' ' .. item_racc .. ' ' .. get_player_acc_from_job() .. ' ' .. ammo.value .. ' ' .. skill_from_gear_ammo .. ' ' ..item_agi .. ' ' .. player_agi )	
	return Total_acc
end

function get_player_att(stat_table)
	
	local stat_table = stat_table
	local use_real = (settings and settings.player and settings.player.use_real_att_def) and true or false
	
	local two_handers ={ ["Great Sword"]=0, ["Great Axe"]=0, ["Scythe"]=0, ["Polearm"]=0, ["Great Katana"]=0,["Staff"]=0}
								
	--stat_table = get_blue_mage_stats_from_equipped_spells(stat_table)
	
	local Total_att = {main = 0, sub = 0, range = 0, ammo = 0, str = 0}
	
	
	-- Attack (2H) 
	if table.containskey(two_handers, stat_table['main']['skill']) then
		local base_attack = 8 + stat_table['main'].value + stat_table['STR'] + Buffs_inform['STR'] + stat_table['Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + get_smite() + multi))
		Total_att.main = BA_multi
		--print(base_attack, get_smite(), multi, Buffs_inform['Attack perc'])
	-- Attack (H2H)
	elseif stat_table['main']['skill'] == 'Hand-to-Hand' then
		local base_attack = 8 + stat_table['main'].value + stat_table['STR'] + Buffs_inform['STR'] + stat_table['Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + get_smite() + multi))
		Total_att.main = BA_multi + Buffs_inform['Attack']
	-- Attack (1H main)
	else
		local base_attack = 8 + stat_table['main'].value + stat_table['STR'] + Buffs_inform['STR'] + stat_table['Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + multi))
		Total_att.main = BA_multi
	end
	
	-- Attack (1H sub)
	if player.equipment.sub.id ~= 0 and player.equipment.sub.category == 'Weapon' and player.equipment.sub.damage then
		local base_attack = 8 + stat_table['sub'].value + math.floor( (stat_table['STR'] + Buffs_inform['STR']) / 2) + stat_table['Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + multi))
		Total_att.sub = BA_multi
	end
	-- Ranged Attack
	if player.equipment.range.id ~= 0 and player.equipment.range.category == 'Weapon' and player.equipment.range['damage'] then
		local base_attack = 8 + stat_table['range'].value + stat_table['STR'] + stat_table['Ranged Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + multi))
		Total_att.range = BA_multi
	end
	
	if player.equipment.range.id == 0 and player.equipment.ammo.id ~= 0 and player.equipment.ammo.category == 'Weapon' and player.equipment.ammo['damage'] then
		local base_attack = 8 + stat_table['ammo'].value + stat_table['STR'] + stat_table['Ranged Attack'] + get_player_att_from_job() + Buffs_inform['Attack']
		local multi = Buffs_inform['Attack perc'] / 1024
		local BA_multi = math.floor(base_attack * (1 + multi))
		Total_att.ammo = BA_multi
	end
	
	if use_real then
		local direct_att = nil
		local cur_player = windower.ffxi.get_player()
		if cur_player then
			direct_att = _gi_pick_num(cur_player.stats, {'attack', 'Attack', 'atk', 'Atk'})
			if not direct_att then
				direct_att = _gi_pick_num(cur_player, {'attack', 'Attack', 'atk', 'Atk'})
			end
			if not direct_att then
				direct_att = _gi_pick_num(cur_player.vitals, {'attack', 'Attack', 'atk', 'Atk'})
			end
		end
		if not direct_att then
			direct_att = _gi_pick_num(player and player.stats, {'attack', 'Attack', 'atk', 'Atk'})
		end
		if not direct_att then
			local me = windower.ffxi.get_mob_by_target('me')
			direct_att = _gi_pick_num(me, {'attack', 'Attack', 'atk', 'Atk'})
		end

		if direct_att and direct_att > 0 then
			Total_att.main = direct_att
			-- Single in-game Attack value; avoid showing a duplicate sub value.
			Total_att.sub = 0
			_real_att_missing_notice = false
		elseif not _real_att_missing_notice then
			log('Real Attack mode: direct API value is unavailable, using calculated Attack.')
			_real_att_missing_notice = true
		end
	end

	return Total_att
end

function get_smite()
	
	local main_job_smite = 0
	local sub_job_smite = 0
	
	if player.sub_job then
		if player.sub_job:upper() == 'DRK' then
			if player.sub_job_level < 35 and  player.sub_job_level > 14 then sub_job_smite = 0.097
			elseif player.sub_job_level > 34 then sub_job_smite = 0.15
			end
		elseif player.sub_job:upper() == 'WAR' then
			if player.sub_job_level > 34 then sub_job_smite = 0.097
			end
		elseif player.sub_job:upper() == 'MNK' then
			if player.sub_job_level > 39 then sub_job_smite = 0.097
			end
		elseif player.sub_job:upper() == 'DRG' then
			if player.sub_job_level > 39 then sub_job_smite = 0.097
			end
		end
	end
	
	if player.main_job:upper() == 'DRK' then
		if player.main_job_level < 35 and  player.main_job_level > 14 then main_job_smite = 0.097
		elseif player.main_job_level < 55 and  player.main_job_level > 34 then main_job_smite = 0.15
		elseif player.main_job_level < 75 and  player.main_job_level > 54 then main_job_smite = 0.199
		elseif player.main_job_level < 95 and  player.main_job_level > 74 then main_job_smite = 0.25
		elseif player.main_job_level > 94 then main_job_smite = 0.296
		end
	elseif player.main_job:upper() == 'WAR' then
		if player.main_job_level < 65 and  player.main_job_level > 34 then main_job_smite = 0.097
		elseif player.main_job_level < 95 and  player.main_job_level > 64 then main_job_smite = 0.15
		elseif player.main_job_level > 94 then main_job_smite = 0.199
		end
	elseif player.main_job:upper() == 'MNK' then
		if player.main_job_level < 80 and  player.main_job_level > 39 then main_job_smite = 0.097
		elseif player.main_job_level > 79 then main_job_smite = 0.15
		end
	elseif player.main_job:upper() == 'DRG' then
		if player.main_job_level < 80 and  player.main_job_level > 39 then main_job_smite = 0.097
		elseif player.main_job_level > 79 then main_job_smite = 0.15
		end
	elseif player.main_job:upper() == 'PUP' then
		if player.main_job_level > 59 then main_job_smite = 0.097
		end
	end
	
	if sub_job_smite > main_job_smite then
		return sub_job_smite
	else
		return main_job_smite
	end

end

function get_player_evasion(stat_table)
	local agi = tonumber(stat_table and stat_table['AGI']) or 0
	local eva_skill = tonumber(stat_table and stat_table['Evasion skill']) or 0
	local eva_stat = tonumber(stat_table and stat_table['Evasion']) or 0
	if player_base_skills and player_base_skills['evasion'] then
		eva_skill = eva_skill + player_base_skills['evasion']
	end
	--notice(agi .. ' | ' .. eva_skill .. ' | ' .. eva_from_skill(eva_skill) .. ' | ' .. get_player_eva_from_job().. ' | ' .. eva_stat)
	local evasion = math.floor(agi / 2) + eva_from_skill(eva_skill) + get_player_eva_from_job() + eva_stat
	return evasion
end

function get_player_defence(stat_table)
	
	local stat_table = stat_table
	local defence = 0
	local use_real = (settings and settings.player and settings.player.use_real_att_def) and true or false
	if use_real then
		local direct_def = nil
		local cur_player = windower.ffxi.get_player()
		if cur_player then
			direct_def = _gi_pick_num(cur_player.stats, {'defense', 'Defense', 'def', 'Def'})
			if not direct_def then
				direct_def = _gi_pick_num(cur_player, {'defense', 'Defense', 'def', 'Def'})
			end
			if not direct_def then
				direct_def = _gi_pick_num(cur_player.vitals, {'defense', 'Defense', 'def', 'Def'})
			end
		end
		if not direct_def then
			direct_def = _gi_pick_num(player and player.stats, {'defense', 'Defense', 'def', 'Def'})
		end
		if not direct_def then
			local me = windower.ffxi.get_mob_by_target('me')
			direct_def = _gi_pick_num(me, {'defense', 'Defense', 'def', 'Def'})
		end

		if direct_def and direct_def > 0 then
			_real_def_missing_notice = false
			return direct_def
		elseif not _real_def_missing_notice then
			log('Real Defence mode: direct API value is unavailable, using calculated Defence.')
			_real_def_missing_notice = true
		end
	end
	--notice(stat_table['AGI'] .. ' | ' .. stat_table['Evasion skill'] .. ' | ' .. eva_from_skill(stat_table['Evasion skill'] ) .. ' | ' .. get_player_eva_from_job().. ' | ' .. stat_table['Evasion'])
	if player.main_job_level < 51 then
		defence = math.floor(3*(stat_table['VIT'] + Buffs_inform['VIT']) /2) + player.main_job_level + 8
	elseif player.main_job_level > 50 and player.main_job_level < 61 then
		defence = math.floor(3*(stat_table['VIT'] + Buffs_inform['VIT'])/2) + (2 * player.main_job_level ) - 42
	elseif player.main_job_level > 60 and player.main_job_level < 90 then
		defence = math.floor(3*(stat_table['VIT'] + Buffs_inform['VIT'])/2) + ( player.main_job_level ) + 18
	else
		defence = math.floor(3*(stat_table['VIT'] + Buffs_inform['VIT'])/2) + ( player.main_job_level ) + 18 + math.floor( (player.main_job_level - 89) / 2 )
	end
	defence = defence + stat_table['DEF'] + get_player_def_from_job() + Buffs_inform['DEF']
	local multi = Buffs_inform['Defence perc'] / 1024
	defence = math.floor(defence * (1 + multi))
	return defence
end

function get_blue_mage_stats_from_equipped_spells(stat_table)

	local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return id end)
	
	for key, spell_id in pairs(spells_set) do
		local spell_stats = Blu_spells[spell_id]
		if type(spell_stats) == 'table' then
			for stat, value in pairs(spell_stats) do
				if stat_table[stat] then
					stat_table[stat] = stat_table[stat] + value
				end
			end
		end
	end

	return stat_table
end

function get_equip_stats_aug_only(equipment_table)

	local stat_table = { ['Haste'] = 0, ['Slow'] = 0, ['Dual Wield'] = 0, ['Store TP'] = 0, ['Accuracy'] = 0, ['Attack'] = 0, ['Ranged Accuracy'] = 0, ['Ranged Attack'] = 0, ['Magic Accuracy'] = 0,
									['Magic Atk. Bonus'] = 0, ['Magic Burst Damage'] = 0, ['Magic Burst Damage II'] = 0, ['Magic Burst Bonus'] = 0,
									['Skillchain Bonus'] = 0, ['Skillchain Damage'] = 0, ['PDL'] = 0, ['SIRD'] = 0,
									['Regen'] = 0, ['Regain'] = 0, ['Refresh'] = 0, ['Enmity'] = 0,
									['Evasion'] = 0,
									['Magic Damage'] = 0, ['Magic Def. Bonus'] = 0, ['Magic Evasion'] = 0,
									['Pet: Regen'] = 0, ['Pet: Damage Taken'] = 0, ['Pet: Physical Damage Taken'] = 0, ['Pet: Magic Damage Taken'] = 0, ['Pet: Haste'] = 0,
									['Cursna'] = 0,
									['Counter'] = 0, ['Conserve MP'] = 0,
									['Quick Cast'] = 0, ['Cure spellcasting time'] = 0, ['Healing magic casting time'] = 0,
									['Elemental magic casting time'] = 0, ['Inquartata'] = 0,
									['Enhancing magic effect duration'] = 0, ['Steal'] = 0, ['Sneak Attack'] = 0, ['Trick Attack'] = 0,
									['All songs'] = 0, ['Song effect duration'] = 0, ['Song spellcasting time'] = 0,
									['Pet: Regen'] = 0, ['Pet: Damage Taken'] = 0, ['Pet: Physical Damage Taken'] = 0, ['Pet: Magic Damage Taken'] = 0, ['Indicolure effect duration'] = 0,
									['Pet: Haste'] = 0, ['Cursna'] = 0,
									['Cure potency received'] = 0,
									['Snapshot'] = 0, ['Rapid Shot'] = 0,
									['Blood Pact Delay'] = 0, ['Blood Pact Delay II'] = 0, ['Blood Pact Damage'] = 0,
									['Avatar Perpetuation Cost'] = 0, ['Pet: Magic Atk. Bonus'] = 0, ['Pet: Attack'] = 0,
									['Pet: Double Attack'] = 0, ['Pet: Accuracy'] = 0, ['Pet: Magic Accuracy'] = 0,
									['Summoning Magic skill'] = 0, ['Pet: Blood Pact Damage'] = 0, ['Pet: Magic Damage'] = 0,
									['Snapshot'] = 0, ['Rapid Shot'] = 0,
									['Elemental magic casting time'] = 0, ['Inquartata'] = 0,
									['Enhancing magic effect duration'] = 0, ['Steal'] = 0, ['Sneak Attack'] = 0, ['Trick Attack'] = 0,
									['All songs'] = 0, ['Song effect duration'] = 0, ['Song spellcasting time'] = 0,
									['Pet: Regen'] = 0, ['Pet: Damage Taken'] = 0, ['Pet: Physical Damage Taken'] = 0, ['Pet: Magic Damage Taken'] = 0, ['Indicolure effect duration'] = 0,
									['All songs'] = 0, ['Song effect duration'] = 0, ['Song spellcasting time'] = 0,
									['Pet: Regen'] = 0, ['Pet: Damage Taken'] = 0, ['Pet: Physical Damage Taken'] = 0, ['Pet: Magic Damage Taken'] = 0, ['Indicolure effect duration'] = 0,
									['Enhancing magic effect duration'] = 0, ['Steal'] = 0, ['Sneak Attack'] = 0, ['Trick Attack'] = 0,
									['Elemental magic casting time'] = 0, ['Inquartata'] = 0,
									['Snapshot'] = 0, ['Rapid Shot'] = 0,
									['Phalanx'] = 0,
									['Quick Cast'] = 0, ['Cure spellcasting time'] = 0, ['Healing magic casting time'] = 0,
									['Treasure Hunter'] = 0, ['Fast Cast'] = 0, ['Cure potency'] = 0, ['Cure potency II'] = 0,
									['Enemy critical hit rate'] = 0, ['Waltz'] = 0, ['Block rate'] = 0, ['Zanshin'] = 0,
									['TP Bonus'] = 0, ['Killer'] = 0, ['Samba'] = 0,
									['Treasure Hunter'] = 0, ['Fast Cast'] = 0, ['Cure potency'] = 0, ['Cure potency II'] = 0,
									['Enemy critical hit rate'] = 0, ['Waltz'] = 0, ['Block rate'] = 0, ['Zanshin'] = 0,
									['TP Bonus'] = 0, ['Killer'] = 0, ['Samba'] = 0,
									['Treasure Hunter'] = 0, ['Fast Cast'] = 0, ['Cure potency'] = 0, ['Cure potency II'] = 0,
									['Enemy critical hit rate'] = 0, ['Waltz'] = 0, ['Block rate'] = 0, ['Zanshin'] = 0,
									['TP Bonus'] = 0, ['Killer'] = 0, ['Samba'] = 0,
									['Subtle Blow'] = 0, ['Subtle Blow II'] = 0,
									['Critical hit rate'] = 0, ['Critical hit damage'] = 0,
									['Double Attack'] = 0, ['Triple Attack'] = 0, ['Quadruple Attack'] = 0,

									['DT'] = 0, ['PDT'] = 0, ['PDT2'] = 0, ['MDT'] = 0, ['MDT2'] = 0, ['BDT'] = 0,
									['DEF'] = 0,

									["MND"]=0, ["AGI"]=0, ["DEX"]=0, ["VIT"]=0, ["STR"]=0, ["INT"]=0,  ["CHR"]=0,

									["Hand-to-Hand skill"]=0, ["Dagger skill"]=0, ["Sword skill"]=0, ["Great Sword skill"]=0, ["Axe skill"]=0, ["Great Axe skill"]=0, ["Scythe skill"]=0, ["Polearm skill"]=0,
									["Katana skill"]=0, ["Great Katana skill"]=0,["Club skill"]=0,["Staff skill"]=0,["Archery skill"]=0,["Marksmanship skill"]=0,["Throwing skill"]=0,["Parrying skill"]=0, ['Combat skills']=0,
									['Evasion skill'] = 0,

									['main'] = {['skill'] = '', value = 0}, ['sub'] = {['skill'] = '', value = 0}, ['range'] = {['skill'] = '', value = 0}, ['ammo'] = {['skill'] = '', value = 0},
								}

	if type(equipment_table) ~= 'table' or equipment_table == nil then
		error('get_equip_stats_aug_only() function went wrong')
		return stat_table
	end

	for _, equipped_item in pairs(equipment_table) do
		local aug_stats = equipped_item and equipped_item._aug_only
		if type(aug_stats) == 'table' then
			for key, value in pairs(aug_stats) do
				if stat_table[key] ~= nil then
					if key == 'Haste' then
						stat_table['Haste'] = stat_table['Haste'] + math.floor(value / 100 * 1024)
					elseif key == 'Slow' then
						stat_table['Haste'] = stat_table['Haste'] - math.floor(value / 100 * 1024)
					else
						stat_table[key] = stat_table[key] + value
					end
				end
			end
		end
	end

	return stat_table
end

function get_player_skill_in_gear(equip)
	
	-- Always start from a fresh copy of current skills.
	-- Do not mutate player.skills directly, otherwise values drift over time.
	player_base_skills = {}
	if player and type(player.skills) == 'table' then
		for skill_name, skill_value in pairs(player.skills) do
			player_base_skills[skill_name] = skill_value
		end
	end
	
	-- string.gsub(sub_hand.skill, ' ', '_')
	local combat_skills = L{"hand_to_hand", "dagger", "sword", "great_sword", "axe", "great_axe",  "scythe", "polearm", 
										"katana", "great_katana", "club",  "staff", "archery", "marksmanship" , "throwing","guard","evasion","shield","parrying",}
	local magic_skills = L{"divine_magic","healing_magic","enhancing_magic","enfeebling_magic","elemental_magic","dark_magic","summoning_magic",
									"ninjutsu","singing","stringed Instrument","wind Instrument","blue_magic","geomancy","handbell"}
	local skills = L{"Hand-to-Hand skill", "Dagger skill", "Sword skill", "Great sword skill", "Axe skill", "Great axe skill",  "Scythe skill", "Polearm skill", 
							"Katana skill", "Great katana skill", "Club skill",  "Staff skill", "Archery skill", "Marksmanship skill" , "Throwing skill","Guard skill","Evasion skill","Shield skill","Parrying skill",
							"Divine Magic skill","Healing Magic skill","Enhancing Magic skill","Enfeebling Magic skill","Elemental Magic skill","Dark Magic skill","Summoning Magic skill","Ninjutsu skill","Singing skill",
							"Stringed Instrument skill","Wind Instrument skill","Blue Magic skill","Geomancy skill","Handbell skill",'All magic skills','Combat skills','Magic skills',
							}
	
	if equip then
		for slot ,item in pairs(equip) do
			if slot == 'main' or slot == 'sub' or slot == 'range' or slot == 'ammo' then
				if item.category == 'Weapon' then
					if item.damage == nil then
						if item.item_level == nil then
							for stat_key, value in pairs(item) do
								if skills:contains(stat_key) then
									str = string.gsub(stat_key, ' skill', '')
									if player_base_skills[string.gsub(str, ' ', '_'):lower()] then
										player_base_skills[string.gsub(str, ' ', '_'):lower()] = player_base_skills[string.gsub(str, ' ', '_'):lower()] - value
										-- notice('value 1 = ' .. value)
										-- break
									elseif player_base_skills['hand_to_hand'] and stat_key == "Hand-to-Hand skill" then
										player_base_skills['hand_to_hand'] = player_base_skills['hand_to_hand'] - value
									elseif stat_key == "Combat skills" then
										for k, player_skill in pairs(player_base_skills) do
											if combat_skills:contains(player_skill) then
												player_base_skills.player_skill = player_base_skills.player_skill - value
											end
										end
									elseif stat_key == 'All magic skills' or stat_key == 'Magic skills' then
										for k, player_skill in pairs(player_base_skills) do
											if magic_skills:contains(player_skill) then
												player_base_skills.player_skill = player_base_skills.player_skill - value
											end
										end
									end
								end
							end
						end
					end
				end
			else
				for stat_key, value in pairs(item) do
					if skills:contains(stat_key) then
						str = string.gsub(stat_key, ' skill', '')
						if player_base_skills[string.gsub(str, ' ', '_'):lower()] then
							player_base_skills[string.gsub(str, ' ', '_'):lower()] = player_base_skills[string.gsub(str, ' ', '_'):lower()] - value
							-- notice('value 2 = ' .. value .. ' for item: ' .. item.en)
							-- break
						elseif player_base_skills['hand_to_hand'] and stat_key == "Hand-to-Hand skill" then
							player_base_skills['hand_to_hand'] = player_base_skills['hand_to_hand'] - value
						elseif stat_key == "Combat skills" then
							for k, player_skill in pairs(player_base_skills) do
								if combat_skills:contains(player_skill) then
									player_base_skills.player_skill = player_base_skills.player_skill - value
								end
							end
						elseif stat_key == 'All magic skills' or stat_key == 'Magic skills' then
							for k, player_skill in pairs(player_base_skills) do
								if magic_skills:contains(player_skill) then
									player_base_skills.player_skill = player_base_skills.player_skill - value
								end
							end
						end
					end
				end
			end
		end
	end
	-- notice(player_base_skills.sword)
end
	
function acc_from_skill(skill)
	
	if skill < 200 then return skill end
	if skill < 400 and skill > 199 then return (math.floor((skill -200) * 0.9) + 200) end
	if skill < 600 and skill > 399 then return (math.floor((skill -400) * 0.8) + 380) end
	if skill > 599 then return (math.floor((skill -600) * 0.9) + 540) end

end

function racc_from_skill(skill)
	
	if skill < 200 then return skill end
	if skill < 400 and skill > 199 then return (math.floor((skill -200) * 0.9) + 200) end
	if skill < 600 and skill > 399 then return (math.floor((skill -400) * 0.8) + 380) end
	if skill > 599 then return (math.floor((skill -600) * 0.9) + 540) end

end

function eva_from_skill(skill)
	
	if skill < 200 then return skill end
	if skill < 400 and skill > 199 then return (math.floor((skill -200) * 0.9) + 200) end
	if skill < 600 and skill > 399 then return (math.floor((skill -400) * 0.8) + 380) end
	if skill > 599 then return (math.floor((skill -600) * 0.9) + 540) end

end

function get_player_acc_from_job()
	
	local sub_job_acc = 0
	local main_job_acc = 0
	local player_has_sj = false
	
	if player.sub_job then
		if player.sub_job:upper() == 'RNG' then
			if player.sub_job_level < 10  then sub_job_acc = 0
			elseif player.sub_job_level < 30 and  player.sub_job_level > 9 then sub_job_acc = 10
			elseif player.sub_job_level > 29 then sub_job_acc = 22
			end
		elseif player.sub_job:upper() == 'DRG' then
			if player.sub_job_level < 30  then sub_job_acc = 0
			elseif player.sub_job_level > 29 then sub_job_acc = 10
			end
		elseif player.sub_job:upper() == 'DNC' then
			if player.sub_job_level < 30  then sub_job_acc = 0
			elseif player.sub_job_level > 29 then sub_job_acc = 10
			end
		end
	end

	local jp = gear_processing_jp_spent()
		
	local jp_acc = 0
	for k, v in pairs(gear_processing_job_gifts()) do
		if k <= jp then
			for i, j in pairs(v) do
				if i == 'Physical Accuracy Bonus' then
					jp_acc = jp_acc + j
				end
			end
		end
	end
	
	if player.main_job == 'BLU' then
		-- here we look up job points spent on blue for the DW bonus
		local jp_boost = 0
		if jp < 100 then
			jp_boost = 0
		elseif jp >= 100 and jp < 1200 then
			jp_boost = 1
		elseif jp >= 1200 then
			jp_boost = 2
		end
		
		local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return id end)
		local spell_value = 0
		for key, spell_id in pairs(spells_set) do
			if Blu_spells[spell_id].trait == 'Accuracy' then
				spell_value = spell_value + Blu_spells[spell_id]['points']
			end
		end
		
		if math.floor(spell_value / 8) > 0 then
			spell_value  = math.floor(spell_value / 8) + jp_boost
		else
			spell_value = 0
		end

		if spell_value == 0 then main_job_acc = 0
		elseif spell_value == 1 then main_job_acc = 10
		elseif spell_value == 2 then main_job_acc = 22
		elseif spell_value == 3 then main_job_acc = 35
		elseif spell_value == 4 then main_job_acc = 48
		elseif spell_value == 5 then main_job_acc = 60
		elseif spell_value == 6 then main_job_acc = 73
		end
		
	elseif player.main_job == 'RNG' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 30 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level < 50 and  player.main_job_level > 29 then main_job_acc = 22
		elseif player.main_job_level < 70 and  player.main_job_level > 49 then main_job_acc = 35
		elseif player.main_job_level < 86 and  player.main_job_level > 69 then main_job_acc = 48
		elseif player.main_job_level < 96 and  player.main_job_level > 85 then main_job_acc = 60
		elseif player.main_job_level < 100 and  player.main_job_level > 95 then main_job_acc = 73
		end
	
	elseif player.main_job == 'DRG' then
		if player.main_job_level < 30  then main_job_acc = 0
		elseif player.main_job_level > 29 and player.main_job_level < 60 then main_job_acc = 10
		elseif player.main_job_level > 59 and player.main_job_level < 76 then main_job_acc = 22
		elseif player.main_job_level > 75  then main_job_acc = 35
		end
		
	elseif player.main_job == 'DNC' then
		if player.main_job_level < 30  then main_job_acc = 0
		elseif player.main_job_level > 29 and player.main_job_level < 60 then main_job_acc = 10
		elseif player.main_job_level > 59 and player.main_job_level < 76 then main_job_acc = 22
		elseif player.main_job_level > 75  then main_job_acc = 35
		end
		
	elseif player.main_job == 'RUN' then
		if player.main_job_level < 50  then main_job_acc = 0
		elseif player.main_job_level > 49 and player.main_job_level < 70 then main_job_acc = 10
		elseif player.main_job_level > 69 and player.main_job_level < 90 then main_job_acc = 22
		elseif player.main_job_level > 89  then main_job_acc = 35
		end
	end
	
	if sub_job_acc > main_job_acc then
		return sub_job_acc + jp_acc
	else
		return main_job_acc + jp_acc
	end
end

function get_player_eva_from_job()
	
	local sub_job_acc = 0
	local main_job_acc = 0
	local player_has_sj = false
	
	if player.sub_job then
		if player.sub_job:upper() == 'THF' then
			if player.sub_job_level < 10  then sub_job_acc = 0
			elseif player.sub_job_level < 30 and  player.sub_job_level > 9 then sub_job_acc = 10
			elseif player.sub_job_level > 29 then sub_job_acc = 22
			end
		elseif player.sub_job:upper() == 'DNC' then
			if player.sub_job_level < 15  then sub_job_acc = 0
			elseif player.sub_job_level < 45 and  player.sub_job_level > 14 then sub_job_acc = 10
			elseif player.sub_job_level > 44 then sub_job_acc = 22
			end
		elseif player.sub_job:upper() == 'PUP' then
			if player.sub_job_level < 20  then sub_job_acc = 0
			elseif player.sub_job_level < 40 and  player.sub_job_level > 19 then sub_job_acc = 10
			elseif player.sub_job_level >39  then sub_job_acc = 22
			end
		end
	end

	local jp = gear_processing_jp_spent()
		
	local jp_eva = 0
	for k, v in pairs(gear_processing_job_gifts()) do
		if k <= jp then
			for i, j in pairs(v) do
				if i == 'Physical Evasion Bonus' then
					jp_eva = jp_eva + j
				end
			end
		end
	end
	
	if player.main_job == 'BLU' then
		-- here we look up job points spent on blue for the DW bonus
		local jp_boost = 0
		if jp < 100 then
			jp_boost = 0
		elseif jp >= 100 and jp < 1200 then
			jp_boost = 1
		elseif jp >= 1200 then
			jp_boost = 2
		end
		
		local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return id end)
		local spell_value = 0
		for key, spell_id in pairs(spells_set) do
			if Blu_spells[spell_id].trait == 'Evasion' then
				spell_value = spell_value + Blu_spells[spell_id]['points']
			end
		end
		
		if math.floor(spell_value / 8) > 0 then
			spell_value  = math.floor(spell_value / 8) + jp_boost
		else
			spell_value = 0
		end

		if spell_value == 0 then main_job_acc = 0
		elseif spell_value == 1 then main_job_acc = 10
		elseif spell_value == 2 then main_job_acc = 22
		elseif spell_value == 3 then main_job_acc = 35
		elseif spell_value == 4 then main_job_acc = 48
		elseif spell_value == 5 then main_job_acc = 60
		end
		
	elseif player.main_job == 'THF' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 30 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level < 50 and  player.main_job_level > 29 then main_job_acc = 22
		elseif player.main_job_level < 70 and  player.main_job_level > 49 then main_job_acc = 35
		elseif player.main_job_level < 76 and  player.main_job_level > 69 then main_job_acc = 48
		elseif player.main_job_level < 88 and  player.main_job_level > 75 then main_job_acc = 60
		elseif player.main_job_level > 87  then main_job_acc = 72
		end
	
	elseif player.main_job == 'DNC' then
		if player.main_job_level < 15  then main_job_acc = 0
		elseif player.main_job_level < 45 and  player.main_job_level > 14 then main_job_acc = 10
		elseif player.main_job_level < 75 and  player.main_job_level > 44 then main_job_acc = 22
		elseif player.main_job_level < 86 and  player.main_job_level > 74 then main_job_acc = 35
		elseif player.main_job_level > 85  then main_job_acc = 48
		end
		
	elseif player.main_job == 'PUP' then
		if player.main_job_level < 20  then main_job_acc = 0
		elseif player.main_job_level < 40 and  player.main_job_level > 19 then main_job_acc = 10
		elseif player.main_job_level < 60 and  player.main_job_level > 39 then main_job_acc = 22
		elseif player.main_job_level > 76  then main_job_acc = 35
		end
	end
	
	if sub_job_acc > main_job_acc then
		return sub_job_acc + jp_eva
	else
		return main_job_acc + jp_eva
	end
end

-- copy pasta from get_player_acc_from_job but returns Attack
function get_player_att_from_job()
	
	local sub_job_acc = 0
	local main_job_acc = 0
	local player_has_sj = false
	
	if player.sub_job then
		if player.sub_job:upper() == 'DRK' then
			if player.sub_job_level < 30 and  player.sub_job_level > 9 then sub_job_acc = 10
			elseif player.sub_job_level > 29 then sub_job_acc = 22
			end
		elseif player.sub_job:upper() == 'DRG' then
			if player.sub_job_level > 9 then sub_job_acc = 10
			end
		elseif player.sub_job:upper() == 'WAR' then
			if player.sub_job_level > 29 then sub_job_acc = 10
			end
		end
	end

	local jp = gear_processing_jp_spent()
		
	local jp_eva = 0
	for k, v in pairs(gear_processing_job_gifts()) do
		if k <= jp then
			for i, j in pairs(v) do
				if i == 'Physical Attack Bonus' then
					jp_eva = jp_eva + j
				end
			end
		end
	end
	
	if player.main_job == 'BLU' then
		-- here we look up job points spent on blue for the DW bonus
		local jp_boost = 0
		if jp < 100 then
			jp_boost = 0
		elseif jp >= 100 and jp < 1200 then
			jp_boost = 1
		elseif jp >= 1200 then
			jp_boost = 2
		end
		
		local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return id end)
		local spell_value = 0
		for key, spell_id in pairs(spells_set) do
			if Blu_spells[spell_id].trait == 'Attack' then
				spell_value = spell_value + Blu_spells[spell_id]['points']
			end
		end
		
		if math.floor(spell_value / 8) > 0 then
			spell_value  = math.floor(spell_value / 8) + jp_boost
		else
			spell_value = 0
		end

		if spell_value == 0 then main_job_acc = 0
		elseif spell_value == 1 then main_job_acc = 10
		elseif spell_value == 2 then main_job_acc = 22
		elseif spell_value == 3 then main_job_acc = 35
		elseif spell_value == 4 then main_job_acc = 48
		elseif spell_value == 5 then main_job_acc = 60
		elseif spell_value == 6 then main_job_acc = 72
		end
		
	elseif player.main_job == 'DRK' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 30 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level < 50 and  player.main_job_level > 29 then main_job_acc = 22
		elseif player.main_job_level < 70 and  player.main_job_level > 49 then main_job_acc = 35
		elseif player.main_job_level < 76 and  player.main_job_level > 69 then main_job_acc = 48
		elseif player.main_job_level < 83 and  player.main_job_level > 75 then main_job_acc = 60
		elseif player.main_job_level < 91 and  player.main_job_level > 82 then main_job_acc = 72
		elseif player.main_job_level < 99 and  player.main_job_level > 90 then main_job_acc = 84
		elseif player.main_job_level > 98  then main_job_acc = 96
		end
	
	elseif player.main_job == 'DRG' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 91 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level > 90  then main_job_acc = 22
		end
		
	elseif player.main_job == 'WAR' then
		if player.main_job_level < 30  then main_job_acc = 0
		elseif player.main_job_level < 65 and  player.main_job_level > 29 then main_job_acc = 10
		elseif player.main_job_level < 90 and  player.main_job_level > 64 then main_job_acc = 22
		elseif player.main_job_level > 89  then main_job_acc = 35
		end
	end
	
	if sub_job_acc > main_job_acc then
		return sub_job_acc + jp_eva
	else
		return main_job_acc + jp_eva
	end
end

function get_player_def_from_job()
	
	local sub_job_acc = 0
	local main_job_acc = 0
	local player_has_sj = false
	
	if player.sub_job then
		if player.sub_job:upper() == 'PLD' then
			if player.sub_job_level < 10  then sub_job_acc = 0
			elseif player.sub_job_level < 30 and  player.sub_job_level > 9 then sub_job_acc = 10
			elseif player.sub_job_level > 29 then sub_job_acc = 22
			end
		elseif player.sub_job:upper() == 'WAR' then
			if player.sub_job_level < 10  then sub_job_acc = 0
			elseif player.sub_job_level < 45 and  player.sub_job_level > 9 then sub_job_acc = 10
			elseif player.sub_job_level > 44  then sub_job_acc = 22
			end
		end
	end

	local jp = gear_processing_jp_spent()
		
	local jp_eva = 0
	for k, v in pairs(gear_processing_job_gifts()) do
		if k <= jp then
			for i, j in pairs(v) do
				if i == 'Physical Defense Bonus' then
					jp_eva = jp_eva + j
				end
			end
		end
	end
	
	if player.main_job == 'BLU' then
		-- here we look up job points spent on blue for the DW bonus
		local jp_boost = 0
		if jp < 100 then
			jp_boost = 0
		elseif jp >= 100 and jp < 1200 then
			jp_boost = 1
		elseif jp >= 1200 then
			jp_boost = 2
		end
		
		local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return id end)
		local spell_value = 0
		for key, spell_id in pairs(spells_set) do
			if Blu_spells[spell_id].trait == 'Defense Bonus' then
				spell_value = spell_value + Blu_spells[spell_id]['points']
			end
		end
		
		if math.floor(spell_value / 8) > 0 then
			spell_value  = math.floor(spell_value / 8) + jp_boost
		else
			spell_value = 0
		end

		if spell_value == 0 then main_job_acc = 0
		elseif spell_value == 1 then main_job_acc = 10
		elseif spell_value == 2 then main_job_acc = 22
		elseif spell_value == 3 then main_job_acc = 35
		elseif spell_value == 4 then main_job_acc = 48
		elseif spell_value == 5 then main_job_acc = 60
		elseif spell_value == 6 then main_job_acc = 72
		end
		
	elseif player.main_job == 'PLD' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 30 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level < 50 and  player.main_job_level > 29 then main_job_acc = 22
		elseif player.main_job_level < 70 and  player.main_job_level > 49 then main_job_acc = 35
		elseif player.main_job_level < 76 and  player.main_job_level > 69 then main_job_acc = 48
		elseif player.main_job_level < 91 and  player.main_job_level > 75 then main_job_acc = 60
		elseif player.main_job_level > 90  then main_job_acc = 72
		end
		
	elseif player.main_job == 'WAR' then
		if player.main_job_level < 10  then main_job_acc = 0
		elseif player.main_job_level < 45 and  player.main_job_level > 9 then main_job_acc = 10
		elseif player.main_job_level < 86 and  player.main_job_level > 44 then main_job_acc = 22
		elseif player.main_job_level > 85  then main_job_acc = 35
		end
	end

	main_job_acc = main_job_acc
	
	if sub_job_acc > main_job_acc then
		return sub_job_acc + jp_eva
	else
		return main_job_acc + jp_eva
	end
end


	
			


