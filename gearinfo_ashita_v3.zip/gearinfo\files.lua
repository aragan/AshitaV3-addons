local files = {};

local function normalize(path)
    path = tostring(path or ''):gsub('/', '\\');
    if (path:match('^%a:[\\/]')) then return path; end
    return addon.path .. path;
end

local function ensure_parent(path)
    local parent = path:match('^(.*)[\\/][^\\/]+$');
    if (parent == nil or parent == '') then return; end
    os.execute(('if not exist "%s" mkdir "%s" >nul 2>nul'):format(parent, parent));
end

function files.exists(path)
    local handle = io.open(normalize(path), 'rb');
    if (handle == nil) then return false; end
    handle:close();
    return true;
end

function files.create_path(path)
    local full = normalize(path):gsub('[\\/]+$', '');
    if (full ~= '') then
        os.execute(('if not exist "%s" mkdir "%s" >nul 2>nul'):format(full, full));
    end
    return true;
end

function files.new(path, create)
    local full = normalize(path);
    if (create) then
        ensure_parent(full);
        local handle = io.open(full, 'ab');
        if (handle ~= nil) then handle:close(); end
    end
    return { path = full };
end

function files.txt(path)
    local full = normalize(path);
    local handle = io.open(full, 'rb');
    if (handle == nil) then return nil; end
    local value = handle:read('*a');
    handle:close();
    return value;
end

return files;
