return {
    code = 'RDM',
    extra2 = true,
    dd_melee = false,
    extra5 = false,
    extra_preset = {
        'show_phalanx',
        'show_macc',
        'show_emed',
        'show_fc',
        'show_qc',
        'show_conserve_mp',
    },
}
