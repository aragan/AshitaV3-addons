-- Minimal 'chat' module for the Ashita v3 port: GearInfo_core only uses
-- chat.controls and chat.chars (colour/control byte tables bundled here).
local chat = {};
chat.controls = require('chat.controls');
chat.chars = require('chat.chars');
pcall(function () chat.colors = require('chat.colors'); end);
pcall(function () chat.icons = require('chat.icons'); end);
return chat;
