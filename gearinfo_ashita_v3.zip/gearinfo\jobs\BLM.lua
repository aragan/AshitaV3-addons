return {
    code = 'BLM',
    extra2 = true,
    dd_melee = false,
    extra5 = false,
}
