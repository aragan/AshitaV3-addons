return {
    code = 'COR',
    extra2 = false,
    dd_melee = false,
    extra5 = false,
    extra_preset = {
        'show_snapshot',
        'show_rapid_shot',
        'show_tpb',
        'show_crit_rate',
        'show_subtle_blow',
        'show_mab',
        'show_magic_damage',
        'show_int',
        'show_macc',
        'show_acc_Stuff',
    },
}
