return {
    code = 'THF',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
    extra_preset = {
        'show_sa',
        'show_ta',
        'show_steal',
        'show_th',
    },
}
