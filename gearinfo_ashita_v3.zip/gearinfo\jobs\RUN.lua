return {
    code = 'RUN',
    extra2 = false,
    dd_melee = false,
    extra5 = true,
    extra_preset = {
        'show_echr',
        'show_phalanx',
        'show_inq',
        'show_emed',
        'show_fc',
    },
}
