return {
    -- Sinister Reign augments (default = left option in BG Wiki table)
    -- Adjust per item if your augments use the right-column option.

    -- Wave 1: Arciela and Ygnas
    [21026] = { ["STR"] = 10, ["Accuracy"] = 10, ["Attack"] = 10, ["Quadruple Attack"] = 3 }, -- Himetsuruichimonji
    [21697] = { ["DMG"] = 15, ["STR"] = 10, ["Accuracy"] = 10, ["Attack"] = 10 }, -- Humility
    [27321] = { ["INT"] = 10, ["Magic Accuracy"] = 15, ["Magic Atk. Bonus"] = 15, ["Refresh"] = 1 }, -- Lengo Pants
    [27135] = { ["Accuracy"] = 15, ["Magic Accuracy"] = 15, ["Magic Atk. Bonus"] = 15, ["Fast Cast"] = 3 }, -- Leyline Gloves

    -- Wave 1: Darrcuiln
    [27491] = { ["VIT"] = 10, ["HP"] = 50, ["Accuracy"] = 15, ["DT"] = -2 }, -- Amm Greaves
    [20517] = { ["DMG"] = 10, ["STR"] = 10, ["DEX"] = 10, ["Store TP"] = 5 }, -- Fleshcarvers
    [20936] = { ["DMG"] = 15, ["Store TP"] = 6, ["STR"] = 10, ["Accuracy"] = 10 }, -- Koresuke
    [27322] = { ["Critical hit rate"] = 3, ["Accuracy"] = 15, ["Magic Evasion"] = 15, ["Enmity"] = -7 }, -- Ta'lab Trousers

    -- Wave 1: Ingrid
    [25630] = { ["DEX"] = 10, ["Accuracy"] = 15, ["Magic Accuracy"] = 15, ["Quadruple Attack"] = 3 }, -- Dampening Tam
    [27136] = { ["MP"] = 50, ["Healing Magic skill"] = 10, ["Fast Cast"] = 7, ["Conserve MP"] = 7 }, -- Fanatic Gloves
    [20595] = { ["Magic Accuracy"] = 10, ["Magic Atk. Bonus"] = 10, ["Fast Cast"] = 5, ["INT"] = 10 }, -- Malevolence
    [20796] = { ["DMG"] = 15, ["Attack"] = 10, ["Store TP"] = 6, ["Weapon Skill Damage"] = 4 }, -- Purgation

    -- Wave 2: Teodor
    [21089] = { ["Magic Accuracy"] = 10, ["Magic Atk. Bonus"] = 10, ["Conserve MP"] = 7, ["Dark Magic skill"] = 10 }, -- Rubicundity
    [26973] = { ["Magic Atk. Bonus"] = 15, ["Magic Accuracy"] = 15, ["Fast Cast"] = 5, ["Dual Wield"] = 5 }, -- Samnuha Coat
    [27295] = { ["STR"] = 10, ["DEX"] = 10, ["Double Attack"] = 3, ["Triple Attack"] = 3 }, -- Samnuha Tights
    [20706] = { ["DMG"] = 15, ["STR"] = 10, ["INT"] = 10, ["Occult Acumen"] = 10 }, -- Vampirism

    -- Wave 2: Morimar
    [20891] = { ["DMG"] = 15, ["STR"] = 10, ["INT"] = 10, ["Double Attack"] = 3 }, -- Brutality
    [20844] = { ["DMG"] = 15, ["STR"] = 10, ["VIT"] = 10, ["Double Attack"] = 3 }, -- Ferocity
    [25631] = { ["STR"] = 10, ["DEX"] = 10, ["Attack"] = 15, ["Weapon Skill Damage"] = 3 }, -- Lilitu Headpiece
    [27492] = { ["STR"] = 10, ["Attack"] = 15, ["PDT"] = -3, ["Haste"] = 3 }, -- Loyalist Sabatons

    -- Wave 2: Rosulatia
    [27137] = { ["Accuracy"] = 15, ["Ranged Accuracy"] = 15, ["Triple Attack"] = 3, ["MDT"] = -4 }, -- Floral Gauntlets
    [27493] = { ["Cure potency"] = 5, ["MP"] = 50, ["Conserve MP"] = 7, ["MND"] = 10 }, -- Medium's Sabots
    [21214] = { ["DMG"] = 15, ["AGI"] = 10, ["Store TP"] = 8, ["Critical hit rate"] = 4 }, -- Nobility
    [21148] = { ["MP"] = 50, ["Cure Spellcasting Time"] = -10, ["Enhancing Magic skill"] = 10, ["Cure potency"] = 5 }, -- Serenity

    -- Wave 3: Arciela
    [27323] = { ["MP"] = 50 }, -- Enticer's Pants
    [20978] = { ["DMG"] = 15, ["STR"] = 10, ["DEX"] = 10, ["Ninjutsu skill"] = 10 }, -- Ochu
    [20596] = { ["DMG"] = 15, ["STR"] = 10, ["DEX"] = 10, ["Treasure Hunter"] = 1 }, -- Taming Sari
    [25705] = { ["MP"] = 50, ["Magic Accuracy"] = 15, ["Magic Atk. Bonus"] = 15, ["Refresh"] = 1 }, -- Witching Robe

    -- Wave 3: Sajj'aka
    [20705] = { ["DMG"] = 15, ["Shield skill"] = 10, ["Divine Magic skill"] = 15, ["Enmity"] = 7 }, -- Brilliance
    [21088] = { ["DMG"] = 15, ["Accuracy"] = 10, ["Attack"] = 10, ["PDT"] = -3 }, -- Divinity
    [25603] = { ["MND"] = 10, ["Magic Atk. Bonus"] = 15, ["Magic Burst Damage"] = 10, ["Refresh"] = 1 }, -- Jumalik Helm
    [26972] = { ["HP"] = 50, ["Attack"] = 15, ["Refresh"] = 2, ["Enmity"] = 9 }, -- Jumalik Mail

    -- Wave 3: August
    [27764] = { ["DEX"] = 10, ["Accuracy"] = 15, ["MDT"] = -5, ["Magic Accuracy"] = 15 }, -- Founder's Corona
    [27910] = { ["Attack"] = 15, ["Accuracy"] = 15, ["Magic Atk. Bonus"] = 15, ["Magic Accuracy"] = 15 }, -- Founder's Breastplate
    [28049] = { ["STR"] = 10, ["Attack"] = 15, ["Magic Atk. Bonus"] = 15, ["PDT"] = -5 }, -- Founder's Gauntlets
    [28191] = { ["MND"] = 10, ["Attack"] = 15, ["Magic Accuracy"] = 15, ["BDT"] = -5 }, -- Founder's Hose
    [28330] = { ["VIT"] = 10, ["Magic Atk. Bonus"] = 15, ["Accuracy"] = 15, ["Magic Evasion"] = 15 }, -- Founder's Greaves
}
