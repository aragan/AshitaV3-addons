_addon.name     = 'gearinfo';
_addon.author   = 'Sebyg666; Converted by Aragan';
_addon.version  = '3.0.0 - version gate of transformers coming';
_addon.desc     = 'Ashita v3 port of GearInfo.';
_addon.link     = 'https://github.com/aragan/AshitaV4-addons';

require('common');
require('d3d8');

-- The v4-style 'addon' table is what the bundled libraries expect.
addon = addon or {};
addon.name = _addon.name;
addon.author = _addon.author;
addon.version = _addon.version;
addon.path = _addon.path;

package.path = addon.path .. '?.lua;' .. addon.path .. '?\init.lua;' .. package.path;

local compat = require('ashita_compat');
compat.initialize();

local ok, err = xpcall(function ()
    dofile(addon.path .. 'GearInfo_core.lua');
end, debug.traceback);

if (not ok) then
    compat.shutdown();
    print('[GearInfo] Failed to load GearInfo core: ' .. tostring(err));
    error(err);
end

compat.start();
