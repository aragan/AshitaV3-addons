return {
    code = 'WAR',
    extra2 = false,
    dd_melee = true,
    extra5 = false,
    extra_preset = {
        'show_tpb',
        'show_br',
    },
}
