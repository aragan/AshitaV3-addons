local ordered_codes = {
    'WAR',
    'MNK',
    'WHM',
    'BLM',
    'RDM',
    'THF',
    'PLD',
    'DRK',
    'BST',
    'BRD',
    'RNG',
    'SAM',
    'NIN',
    'DRG',
    'SMN',
    'BLU',
    'COR',
    'PUP',
    'DNC',
    'SCH',
    'GEO',
    'RUN',
}

local profiles = {}
for _, code in ipairs(ordered_codes) do
    local profile = require('jobs/' .. code)
    profile.code = (profile.code or code):upper()
    profiles[#profiles + 1] = profile
end

return profiles
