local logger = {};

-- One colour for every GearInfo line (see ashita_compat.lua); the level no longer changes it.
local GI_CHAT_MODE  = 6;
local GI_CHAT_COLOR = string.char(30, 71);   -- RoyalBlue
local function emit(_, value)
    local text = tostring(value or '');
    if (text:sub(1, 10) ~= '[GearInfo]') then text = '[GearInfo] ' .. text; end
    local ok = pcall(function () AshitaCore:GetChatManager():AddChatMessage(GI_CHAT_MODE, GI_CHAT_COLOR .. text); end);
    if (not ok) then print(text); end
end

function logger.log(value) emit('message', value); end
function logger.notice(value) emit('notice', value); end
function logger.warning(value) emit('warning', value); end
function logger.error(value) emit('error', value); end
function logger.debug(value) emit('message', value); end

_G.log = logger.log;
_G.notice = logger.notice;
_G.warning = logger.warning;
_G.debug = logger.debug;

return logger;
