local logger = {};

-- Colours follow the core's own convention (windower.add_to_chat modes): 6 = normal, 207 = notice, 167 = error.
local modes = { message = 6, notice = 207, warning = 207, error = 167 };
local function emit(kind, value)
    local text = tostring(value or '');
    if (text:sub(1, 10) ~= '[GearInfo]') then text = '[GearInfo] ' .. text; end
    local mode = modes[kind] or 6;
    local ok = pcall(function () AshitaCore:GetChatManager():AddChatMessage(mode, text); end);
    if (not ok) then print(text); end
end

function logger.log(value) emit('message', value); end
function logger.notice(value) emit('notice', value); end
function logger.warning(value) emit('warning', value); end
function logger.error(value) emit('error', value); end
function logger.debug(value) emit('message', value); end

_G.log = logger.log;
_G.notice = logger.notice;
_G.warning = logger.warning;
_G.debug = logger.debug;

return logger;
