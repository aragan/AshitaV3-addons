-- ===== V3COMPAT (porter edition: Ashita v3 compatibility layer; no-op on Ashita v4) =====
-- Thorny's Porter 1.12 (Ashita v4) runs unchanged below this block. Every v3 difference is bridged here,
-- each one checked against ashitav3\plugins\ADK\Ashita.h or a working v3 addon on this machine:
--   * GetMemoryManager -> GetDataManager ; GetContainerItem -> GetItem ; GetContainerCountMax -> GetContainerMax
--   * GetRawEntity has no v3 twin: "entity exists" = GetServerId(i) ~= 0 (the tradenpc/valkyrie scan rule)
--   * item resource (IItem): v3 field is ItemId (v4: Id) ; Name[] slot is not fixed on v3 -> ASCII pick
--   * Keyboard/Mouse SetBlockInput -> SetBlocked ; GetInstallPath -> GetAshitaInstallPath (no trailing slash)
--   * ashita.fs.* -> ashita.file.* ; ashita.memory.find -> findpattern (+ null-pointer read guard)
--   * events: ashita.events.register(name, id, fn(e)) -> ashita.register_event(v3name, fn(args...)) through a
--     multiplexer (v3 REPLACES a second registration of the same event name - npchelper MUX census)
--   * no ffi (chunk de-dup / LuAshitacast plugin_event) and a different ImGui on v3: stubbed; settings and
--     help are chat commands on v3 (/po settings, /po help)
--   * T{} on v3 has no contains/append/delete ; string.fmt missing
-- Diagnostics go to Ashita-v4\addons\NpcHelper\diag.log, tagged PORTER3.
-- =======================================================================================================
PORTER_V3 = false
do
    local isAshita = rawget(_G, 'AshitaCore') ~= nil
    local isV4 = isAshita and rawget(_G, 'ashita') ~= nil and ashita.events ~= nil and ashita.events.register ~= nil
    if isAshita and not isV4 then
        PORTER_V3 = true
        local DIAG = 'C:\\Program Files (x86)\\Ashita-v4\\addons\\NpcHelper\\diag.log'
        -- Diagnostics: the owner's central sink when it exists, otherwise <Ashita>\config\addons\Porter\porter_diag.log
        local DIAG_LOCAL = nil
        local function v3log(tag, msg)
            pcall(function()
                local line = os.date('%m/%d %H:%M:%S  ') .. 'PORTER3 [' .. tostring(tag) .. '] ' .. tostring(msg) .. '\n'
                local f = io.open(DIAG, 'a')
                if f == nil then
                    if DIAG_LOCAL == nil then
                        local ok, base = pcall(function() return tostring(AshitaCore:GetAshitaInstallPath()) end)
                        if ok and base ~= '' and base ~= 'nil' then
                            base = base:gsub('[\\/]+$', '')
                            pcall(function() ashita.file.create_dir(base .. '\\config\\addons\\Porter') end)
                            DIAG_LOCAL = base .. '\\config\\addons\\Porter\\porter_diag.log'
                        else
                            DIAG_LOCAL = ''
                        end
                    end
                    if DIAG_LOCAL ~= '' then f = io.open(DIAG_LOCAL, 'a') end
                end
                if f then f:write(line); f:close() end
            end)
        end
        PORTER_V3_LOG = v3log
        local onceSeen = {}
        function PORTER_V3_LOG_ONCE(key, msg)
            if onceSeen[key] then return end
            onceSeen[key] = true
            v3log(key, msg)
        end
        local function sget(u, k)
            local ok, v = pcall(function() return u[k] end)
            if ok then return v end
            return nil
        end

        -- bit library (the v3 libs imguidef/mathex use it, so it is normally already there)
        if rawget(_G, 'bit') == nil then
            local ok, b = pcall(require, 'bit')
            if ok and type(b) == 'table' then bit = b end
        end
        -- string.fmt (v4 alias of string.format)
        if string.fmt == nil then string.fmt = string.format end
        -- T{} helpers the v3 tableex lacks (v3: T(t) = setmetatable(t, { __index = table }))
        if table.contains == nil then
            function table.contains(t, v)
                for _, x in pairs(t) do if x == v then return true end end
                return false
            end
        end
        if table.append == nil then
            function table.append(t, v) t[#t + 1] = v; return t end
        end
        if table.delete == nil then
            function table.delete(t, v)
                for i = #t, 1, -1 do if t[i] == v then table.remove(t, i) end end
                return t
            end
        end

        if package ~= nil and package.preload ~= nil and package.loaded ~= nil then
            -- v4 'chat' lib stub (chat.header(x) .. chat.error(y) chains; tostring gives plain text)
            if package.preload['chat'] == nil and package.loaded['chat'] == nil then
                package.preload['chat'] = function()
                    local function piece(s)
                        local o = { __s = tostring(s or '') }
                        o.append = function(self, x) self.__s = self.__s .. tostring(x or '') return self end
                        return setmetatable(o, {
                            __tostring = function(self) return self.__s end,
                            __concat = function(a, b) return tostring(a) .. tostring(b) end,
                        })
                    end
                    local M = {}
                    M.header  = function(s) return piece('[' .. tostring(s or '') .. '] ') end
                    local same = function(s) return piece(tostring(s or '')) end
                    M.message = same M.success = same M.error = same M.warning = same
                    M.color1 = function(_, s) return piece(tostring(s or '')) end
                    M.color2 = M.color1
                    return M
                end
            end
            -- ffi stub: porter only uses ffi to de-duplicate outgoing chunks (memcmp) and for the
            -- LuAshitacast plugin_event bridge; neither exists on v3. memcmp == 0 -> "new chunk".
            package.loaded['ffi'] = nil
            package.preload['ffi'] = function()
                local M = { C = { memcmp = function() return 0 end } }
                function M.cdef() end
                function M.cast(_, v) return v end
                function M.string(v) return tostring(v or '') end
                function M.new() return {} end
                return M
            end
            -- imgui stub: v3's ImGui binding has a different API; every call is a no-op returning false,
            -- so gui.lua/itemlist.lua/containerlist.lua load but never draw. Settings/help = chat commands.
            package.loaded['imgui'] = nil
            package.preload['imgui'] = function()
                return setmetatable({}, { __index = function() return function() return false end end })
            end
        end

        rawset(_G, 'ashita', rawget(_G, 'ashita') or {})

        -- ashita.fs (v4) -> ashita.file (v3: file_exists / dir_exists / create_dir)
        ashita.fs = ashita.fs or {}
        local afile = sget(ashita, 'file')
        if ashita.fs.exists == nil then
            ashita.fs.exists = function(p)
                p = tostring(p or '')
                if afile ~= nil then
                    local ok, r = pcall(function() return (afile.file_exists(p) == true) or (afile.dir_exists(p) == true) end)
                    if ok and r then return true end
                end
                local f = io.open(p, 'r')
                if f then f:close(); return true end
                return false
            end
        end
        if ashita.fs.create_directory == nil then
            ashita.fs.create_directory = function(p)
                p = tostring(p or '')
                if afile ~= nil then
                    local ok, r = pcall(function() return afile.dir_exists(p) == true end)
                    if ok and r then return true end
                    pcall(function() afile.create_dir(p) end)
                end
                return true   -- never abort a save here; io.open reports the real failure
            end
        end

        -- ashita.memory: v4 find() = v3 findpattern(); reads on a null pointer (failed signature scan) return 0
        do
            local mem = sget(ashita, 'memory') or {}
            local M = setmetatable({}, { __index = mem })
            M.find = sget(mem, 'find') or sget(mem, 'findpattern') or function() return 0 end
            for _, fn in ipairs({ 'read_uint8', 'read_uint16', 'read_uint32', 'read_int8', 'read_int32', 'read_float' }) do
                local orig = sget(mem, fn)
                M[fn] = function(addr, ...)
                    if type(addr) ~= 'number' or addr < 0x10000 or type(orig) ~= 'function' then return 0 end
                    return orig(addr, ...)
                end
            end
            ashita.memory = M
        end

        -- ashita.bits.unpack_be: v4 passes byte tables, v3 packets are strings - accept both forms
        do
            local bits = sget(ashita, 'bits')
            local orig = bits and sget(bits, 'unpack_be')
            if type(orig) == 'function' then
                local function tostr(t)
                    local parts = {}
                    for i = 1, #t do parts[i] = string.char((tonumber(t[i]) or 0) % 256) end
                    return table.concat(parts)
                end
                local function totbl(s)
                    local t = {}
                    for i = 1, #s do t[i] = s:byte(i) end
                    return t
                end
                local wrapped = function(data, ...)
                    local ok, r = pcall(orig, data, ...)
                    if ok and r ~= nil then return r end
                    if type(data) == 'table' then ok, r = pcall(orig, tostr(data), ...)
                    elseif type(data) == 'string' then ok, r = pcall(orig, totbl(data), ...) end
                    if ok and r ~= nil then return r end
                    return 0
                end
                ashita.bits = setmetatable({ unpack_be = wrapped }, { __index = bits })
            end
        end

        -- AshitaCore proxy: v4 method/field names over the v3 objects
        local ALIAS = {
            GetLocalPositionX = 'GetLocalX', GetLocalPositionY = 'GetLocalY', GetLocalPositionZ = 'GetLocalZ',
            GetHPPercent = 'GetHealthPercent', GetClaimStatus = 'GetClaimServerId',
            GetMemberHPPercent = 'GetMemberCurrentHPP', GetMemberMPPercent = 'GetMemberCurrentMPP',
            GetMemberHP = 'GetMemberCurrentHP', GetMemberMP = 'GetMemberCurrentMP', GetMemberTP = 'GetMemberCurrentTP',
            GetContainerCountMax = 'GetContainerMax', GetContainerItem = 'GetItem',
            SetBlockInput = 'SetBlocked',
        }
        local FIELD_ALIAS = { Id = 'ItemId' }
        local NIL_ITEM = { Id = 0, Index = 0, Count = 0, Flags = 0, Price = 0, Extra = string.rep('\0', 28) }
        local function isascii(s)
            if type(s) ~= 'string' or #s == 0 then return false end
            for i = 1, #s do
                local b = s:byte(i)
                if b < 0x20 or b > 0x7E then return false end
            end
            return true
        end
        local function nameTable(n)
            if type(n) == 'string' then return { [0] = n, [1] = n, [2] = n, [3] = n } end
            local pick
            for i = 0, 3 do
                local v = sget(n, i)
                if isascii(v) then pick = v break end
            end
            if pick == nil then pick = sget(n, 1) or sget(n, 0) or '' end
            pick = tostring(pick)
            return { [0] = pick, [1] = pick, [2] = pick, [3] = pick }
        end
        local function bytesToString(t)
            local parts = {}
            for i = 1, #t do parts[i] = string.char((tonumber(t[i]) or 0) % 256) end
            return table.concat(parts)
        end
        -- Item extdata (Extra) on v3 arrives one byte late: local byte 1 == real byte 1, real byte 0 is
        -- missing (field-proven 2026-08-30 against the porter moogle's own 0x034 bitmaps). Repairs, best first:
        --   1) exact extdata cached from incoming 0x020 item updates (bag:slot, and by id for storage slips)
        --      and from 0x034 porter menus (by slip id);
        --   2) real byte 0 sits in the top byte of the (equally shifted) Price field: Price>>24 .. Extra[1..27].
        PORTER_V3_EXTRA_BY_ID = {}
        PORTER_V3_EXTRA_BY_SLOT = {}
        local function fixExtra(u, raw, ctx)
            if type(raw) ~= 'string' then return raw end
            local id = tonumber(sget(u, 'Id')) or 0
            if id > 0 and PORTER_V3_EXTRA_BY_ID[id] ~= nil then return PORTER_V3_EXTRA_BY_ID[id] end
            if ctx ~= nil and ctx.bag ~= nil and ctx.slot ~= nil then
                local c = PORTER_V3_EXTRA_BY_SLOT[ctx.bag * 256 + ctx.slot]
                if c ~= nil and c.id == id then return c.extra end
            end
            local price = tonumber(sget(u, 'Price')) or 0
            local b0 = math.floor(price / 16777216) % 256
            return string.char(b0) .. raw:sub(1, 27)
        end
        PORTER_V3_FIX_EXTRA = fixExtra
        local wrap
        local function wrapv(v) if type(v) == 'userdata' then return wrap(v) end return v end
        wrap = function(u, ctx)
            return setmetatable({}, { __index = function(_, k)
                local f = sget(u, k)
                if f == nil and FIELD_ALIAS[k] ~= nil then f = sget(u, FIELD_ALIAS[k]) end
                if type(f) ~= 'function' and ALIAS[k] ~= nil then f = sget(u, ALIAS[k]) end
                if type(f) ~= 'function' then
                    if k == 'GetRawEntity' then
                        return function(_, i)
                            local ok, sid = pcall(function() return u:GetServerId(i) end)
                            if ok and tonumber(sid) ~= nil and tonumber(sid) ~= 0 then return true end
                            return nil
                        end
                    end
                    if k == 'Name' and f ~= nil then return nameTable(f) end
                    if k == 'Extra' then
                        if type(f) == 'table' then f = bytesToString(f) end
                        return fixExtra(u, f, ctx)
                    end
                    return f
                end
                return function(_, ...)
                    local ok, r = pcall(f, u, ...)
                    if not ok then
                        local ok2, r2 = pcall(f, u)      -- v3 signatures often take no args
                        if ok2 then ok, r = true, r2 end
                    end
                    if not ok then return nil end
                    if (k == 'GetContainerItem' or k == 'GetItem') then
                        if r == nil then return NIL_ITEM end
                        local bag, slot = ...
                        if type(r) == 'userdata' then return wrap(r, { bag = tonumber(bag), slot = tonumber(slot) }) end
                        return r
                    end
                    return wrapv(r)
                end
            end })
        end
        local real = AshitaCore
        local function tobytes(d)
            if type(d) == 'table' then return d end
            local t = {}
            for i = 1, #d do t[i] = d:byte(i) end
            return t
        end
        -- client-lock bookkeeping (see the v3 block at the end of this file)
        PORTER_V3_LOCK_UNTIL = 0
        PORTER_V3_TRADE_AT = -100
        local function inject(id, d)
            local g = AddOutgoingPacket   -- plain global lookup (NOT rawget): Addons.dll provides it via the _G metatable
            if type(g) ~= 'function' then v3log('inject', 'AddOutgoingPacket global missing'); return end
            local bytes = tobytes(d)
            if id == 0x36 then PORTER_V3_TRADE_AT = os.clock() end
            if id == 0x36 or id == 0x5B then PORTER_V3_LOCK_UNTIL = os.clock() + 8 end
            local ok, err = pcall(g, id, bytes)
            v3log('inject', string.format('0x%03X len=%d ok=%s%s', id, #bytes, tostring(ok), ok and '' or (' err=' .. tostring(err))))
        end
        AshitaCore = setmetatable({
            GetMemoryManager = function(_) return wrap(real:GetDataManager()) end,
            GetInstallPath = function(_)
                local p = ''
                pcall(function() p = tostring(real:GetAshitaInstallPath() or '') end)
                if p == '' then pcall(function() p = tostring(real:GetAshitaInstallPathA() or '') end) end
                p = p:gsub('[\\/]+$', '')
                return p .. '\\'
            end,
            GetChatManager = function(_)
                local cm = real:GetChatManager()
                return setmetatable({
                    QueueCommand = function(_, a, b)
                        if type(a) == 'number' then cm:QueueCommand(tostring(b), 1)
                        else cm:QueueCommand(tostring(a), tonumber(b) or 1) end
                    end,
                }, { __index = wrap(cm) })
            end,
            GetPacketManager = function(_)
                return {
                    AddIncomingPacket = function(_, id, d)
                        local g = AddIncomingPacket
                        if type(g) == 'function' then pcall(g, id, tobytes(d)) end
                    end,
                    AddOutgoingPacket = function(_, id, d) inject(id, d) end,
                }
            end,
        }, { __index = function(_, k)
            local v = real[k]
            if type(v) == 'function' then return function(_, ...) return wrapv(v(real, ...)) end end
            return v
        end })

        -- events: one real v3 registration per event name, dispatching to every handler in registration
        -- order. v4-style handlers all receive the SAME event table per firing (as on v4), so an earlier
        -- handler may rewrite e.command / set e.blocked for the ones after it. Raw v3-signature handlers
        -- (PORTER_V3_ON) get the original arguments.
        ashita.events = ashita.events or {}
        local lists = {}
        local RETURNS_BOOL = { incoming_packet = true, outgoing_packet = true, command = true, newchat = true }
        local function packetEvent(id, size, data, modified, blocked)
            return { id = id, size = size, data = data, data_raw = data,
                     data_modified = modified or data, data_modified_raw = modified or data,
                     injected = false, blocked = false }
        end
        local BUILD = {
            command = function(cmd, nType) return { command = cmd, mode = nType, blocked = false } end,
            incoming_packet = packetEvent,
            outgoing_packet = packetEvent,
            prerender = function() return {} end,
            newchat = function(mode, text) return { mode = mode, message = text, blocked = false } end,
            outgoing_text = function(mode, message) return { mode = mode, message = message, message_modified = nil, blocked = false } end,
            load = function() return {} end,
            unload = function() return {} end,
        }
        local function ensure(name3)
            if lists[name3] ~= nil then return end
            lists[name3] = {}
            local list = lists[name3]
            ashita.register_event(name3, function(...)
                local build = BUILD[name3]
                local e = build and build(...) or {}
                local anyTrue = false
                for i = 1, #list do
                    local h = list[i]
                    local ok, rv
                    if h.raw then ok, rv = pcall(h.fn, ...) else ok, rv = pcall(h.fn, e) end
                    if not ok then v3log('event:' .. name3, rv)
                    elseif rv == true then anyTrue = true end
                end
                if name3 == 'outgoing_text' then
                    if e.blocked == true or anyTrue then return true end
                    local original = (select(2, ...))
                    if e.message_modified ~= nil and e.message_modified ~= original then return tostring(e.message_modified) end
                    return false
                end
                if RETURNS_BOOL[name3] then return (e.blocked == true) or anyTrue end
            end)
        end
        local function mux(name3, id, fn, raw)
            ensure(name3)
            local list = lists[name3]
            for i = 1, #list do
                if list[i].id == id then list[i].fn = fn; list[i].raw = raw; return end
            end
            list[#list + 1] = { id = id, fn = fn, raw = raw }
        end
        PORTER_V3_ON = function(name3, id, fn3) mux(name3, id, fn3, true) end
        local EVMAP = { d3d_present = 'prerender', packet_in = 'incoming_packet',
                        packet_out = 'outgoing_packet', text_in = 'newchat',
                        text_out = 'outgoing_text' }
        ashita.events.register = function(name, id, fn)
            if type(ashita.register_event) ~= 'function' then return end
            if name == 'plugin_event' then return end   -- v4-only (Ashitacast/LuAshitacast bridge); nothing emits it on v3
            mux(EVMAP[name] or name, tostring(id or fn), fn, false)
        end
        ashita.events.unregister = function(name, id)
            local list = lists[EVMAP[name] or name]
            if list == nil then return end
            for i = #list, 1, -1 do
                if list[i].id == id then table.remove(list, i) end
            end
        end
        if rawget(_G, 'addon') == nil then
            addon = rawget(_G, '_addon') or {}
            if addon.path == nil then addon.path = '' end
        end

        -- addon folder: v3 has no addon.path. Put it first on package.path so the addon's own modules win
        -- whenever require() consults the path. (Never dofile() a module here: on v3 that runs it outside
        -- the addon sandbox, where T/chat/... do not exist - the 'attempt to call global T' load error.)
        local dir = ''
        pcall(function()
            local src = debug.getinfo(1, 'S').source
            if type(src) == 'string' then
                src = src:gsub('^@', '')
                dir = src:match('^(.*[\\/])') or ''
            end
        end)
        if dir == '' then dir = AshitaCore:GetInstallPath() .. 'addons\\porter\\' end
        PORTER_V3_DIR = dir
        if type(package) == 'table' and type(package.path) == 'string' then
            package.path = dir .. '?.lua;' .. package.path
        end
    end
end
-- ===== /V3COMPAT =====

addon.name      = 'Porter';
addon.author    = 'Aragan - version gate of transformers coming';
addon.version   = '1.12 - version gate of transformers coming';
addon.desc      = 'Simplifies usage of porter moogles.';
addon.link      = 'https://github.com/Aragan/';

require('common');
chat = require('chat');
gData = require('data');
if PORTER_V3 then
    -- v3: Addons.dll ships built-in Lua modules under the names 'pack' and 'unpack' (lpack), and common.lua
    -- already owns 'settings' (libs\settings.lua): require() of those names returns the built-in, not the
    -- addon file ("attempt to call method 'Initialize' (a nil value)"). dofile() is no alternative - on v3 it
    -- runs the file outside the addon sandbox (T/chat invisible). Same files, loaded through require under
    -- names of their own: porterpack.lua / portersettings.lua / porterunpack.lua.
    gPack = require('porterpack');
    gPrep = require('prep');
    gSettings = require('portersettings');
    gUnpack = require('porterunpack');
else
    gPack = require('pack');
    gPrep = require('prep');
    gSettings = require('settings');
    gUnpack = require('unpack');
end
gEvent = nil;

-- ===== Ashita v3 only: PorterPacker-style conveniences, registered BEFORE commands.lua so they can rewrite
-- the command it will see (the v3 event multiplexer hands every handler the same event table).
--   /po unpack            -> /po unpack <Name>_<JOB>   (or <JOB>) when that list file exists
--   /po prepunpack        -> same rule
--   /po unpack all        -> retrieve everything stored on the slips in your inventory
--   /po export [name] [all] -> write the storable items you carry (inventory; 'all' = every accessible
--                              container) to lists\<name>.lua, default name <Name>_<JOB>
if PORTER_V3 then
    local JOBS = { [1] = 'WAR', [2] = 'MNK', [3] = 'WHM', [4] = 'BLM', [5] = 'RDM', [6] = 'THF', [7] = 'PLD', [8] = 'DRK',
                   [9] = 'BST', [10] = 'BRD', [11] = 'RNG', [12] = 'SAM', [13] = 'NIN', [14] = 'DRG', [15] = 'SMN',
                   [16] = 'BLU', [17] = 'COR', [18] = 'PUP', [19] = 'DNC', [20] = 'SCH', [21] = 'GEO', [22] = 'RUN' };
    local function say(msg) print(chat.header(addon.name) .. chat.message(msg)); end
    local function listsDir() return AshitaCore:GetInstallPath() .. 'config\\addons\\' .. addon.name .. '\\lists\\'; end
    local function jobCode()
        local ok, j = pcall(function() return AshitaCore:GetMemoryManager():GetPlayer():GetMainJob(); end);
        if ok then return JOBS[tonumber(j) or 0]; end
        return nil;
    end
    local function playerName()
        local ok, n = pcall(function() return AshitaCore:GetMemoryManager():GetParty():GetMemberName(0); end);
        if ok and (type(n) == 'string') and (n ~= '') then return n; end
        return nil;
    end
    -- returns: existing list name for this character/job (or nil), default name to create
    function PORTER_V3_JobListName()
        local job, name = jobCode(), playerName();
        local candidates = {};
        if job and name then candidates[#candidates + 1] = name .. '_' .. job; end
        if job then candidates[#candidates + 1] = job; end
        for _, c in ipairs(candidates) do
            if ashita.fs.exists(listsDir() .. c .. '.lua') then return c, candidates[1]; end
        end
        return nil, candidates[1];
    end
    function PORTER_V3_AllStored()
        local list = T{};
        for _, slip in pairs(gData:GetPlayerSlips()) do
            if (slip.Container == 0) then
                for _, id in ipairs(gData:GetSlipItems(slip)) do
                    if not list:contains(id) then list:append(id); end
                end
            end
        end
        return list;
    end
    function PORTER_V3_Export(a1, a2)
        local all, name = false, nil;
        for _, a in ipairs({ a1, a2 }) do
            if (type(a) == 'string') then
                local l = string.lower(a);
                if (l == 'all') or (l == 'a') then all = true; else name = a; end
            end
        end
        if (name == nil) then local _, def = PORTER_V3_JobListName(); name = def; end
        if (name == nil) then say('Cannot work out a list name (no job/name yet). Give one: /po export <name>'); return; end
        local inventory = AshitaCore:GetMemoryManager():GetInventory();
        local containers = { 0 };
        if all then
            containers = {};
            for c = 0, 16 do if gData:GetContainerAvailable(c) then containers[#containers + 1] = c; end end
        end
        local ids, seen = {}, {};
        for _, c in ipairs(containers) do
            for index = 1, 81 do
                local item = inventory:GetContainerItem(c, index);
                if item and (item.Id > 0) and (item.Count > 0) and (not seen[item.Id]) and gData:GetSlip(item.Id) then
                    seen[item.Id] = true;
                    ids[#ids + 1] = item.Id;
                end
            end
        end
        local path = listsDir() .. name .. '.lua';
        local f = io.open(path, 'w');
        if not f then say('Could not write ' .. path); return; end
        f:write('-- Exported by Porter (Ashita v3) ' .. os.date('%Y-%m-%d %H:%M') .. '\nreturn {\n');
        for _, id in ipairs(ids) do
            local r = AshitaCore:GetResourceManager():GetItemById(id);
            f:write(string.format('    %u, -- %s\n', id, (r and r.Name[1]) or '?'));
        end
        f:write('};\n');
        f:close();
        say(string.format('Exported %u storable items to lists\\%s.lua', #ids, name));
    end
    ashita.events.register('command', 'porter_v3_precmd', function (e)
        local args = e.command:args();
        if (#args < 2) then return; end
        local cmd = string.lower(args[1]);
        if (cmd ~= '/po') and (cmd ~= '/porter') then return; end
        local sub = string.lower(args[2]);
        if ((sub == 'pack') or (sub == 'preppack')) and (#args >= 3) and (string.lower(args[3]) == 'all') then
            e.command = '/po ' .. sub;   -- "all" is already the default: no list = everything storable
            return;
        end
        if ((sub == 'unpack') or (sub == 'prepunpack')) and (#args < 3) then
            local name, def = PORTER_V3_JobListName();
            if name then
                say(string.format('Using list %s', name));
                e.command = string.format('/po %s %s', sub, name);
            else
                say(string.format('No list given and no %s.lua / <JOB>.lua in lists. Create one with /po export, or name a list.', tostring(def)));
                e.command = '/po v3-handled';
                e.blocked = true;
            end
            return;
        end
        if (sub == 'unpack') and (#args >= 3) and (string.lower(args[3]) == 'all') then
            e.command = '/po v3-handled';
            e.blocked = true;
            if gEvent then say('An event is already running.'); return; end
            gEvent = gUnpack:InitializeAll();
            if (#gEvent.SlipQueue == 0) then say('No storage slips in your inventory.'); gEvent = nil; return; end
            say(string.format('Retrieving everything stored on %u slip(s) in your inventory (what each moogle menu lists).', #gEvent.SlipQueue));
            return;
        end
        if (sub == 'export') then
            e.command = '/po v3-handled';
            e.blocked = true;
            PORTER_V3_Export(args[3], args[4]);
            return;
        end
    end);
end

require('commands');
require('integration');

ashita.events.register('packet_in', 'packet_in_cb', function (e)
    if (type(gEvent) == 'table') then
        if (type(gEvent.HandleIncomingPacket) == 'function') then
            gEvent:HandleIncomingPacket(e);
        end
        if (gEvent.State == 0) then
            gEvent = nil;
            if (gSettings.BlockInput) then
                AshitaCore:GetInputManager():GetKeyboard():SetBlockInput(false);
                AshitaCore:GetInputManager():GetMouse():SetBlockInput(false);
            end
        end
    end
end);

ashita.events.register('packet_out', 'packet_out_cb', function (e)
    if (type(gEvent) == 'table') then
        if (type(gEvent.HandleOutgoingPacket) == 'function') then
            gEvent:HandleOutgoingPacket(e);
        end
        if (gEvent.State == 0) then
            gEvent = nil;
            if (gSettings.BlockInput) then
                AshitaCore:GetInputManager():GetKeyboard():SetBlockInput(false);
                AshitaCore:GetInputManager():GetMouse():SetBlockInput(false);
            end
        end
    end
end);

-- ===== Ashita v3 only (skipped on v4) =====================================================================
if PORTER_V3 then
    local function unblockInput()
        pcall(function()
            AshitaCore:GetInputManager():GetKeyboard():SetBlockInput(false);
            AshitaCore:GetInputManager():GetMouse():SetBlockInput(false);
        end);
    end
    local function finishIfDone()
        if (type(gEvent) == 'table') and (gEvent.State == 0) then
            gEvent = nil;
            PORTER_V3_LOCK_UNTIL = 0;
            if (gSettings.BlockInput) then unblockInput(); end
        end
    end
    local function abortEvent(reason)
        if (type(gEvent) == 'table') then
            gEvent.State = 0;
            print(chat.header(addon.name) .. chat.error('Stopped: ' .. tostring(reason)));
        end
        gEvent = nil;
        PORTER_V3_LOCK_UNTIL = 0;
        unblockInput();
    end

    -- (1) Steady pulse. v4 drives the state machine from every new outgoing chunk (ffi memcmp); v3 has no
    -- chunk pointer, so a 0.25s render tick drives it as well. The state machine's own delays make the
    -- extra calls harmless. Repeated handler errors abort the run instead of leaving input blocked.
    local nextTick, tickErrors = 0, 0;
    ashita.events.register('d3d_present', 'porter_v3_tick', function ()
        if (type(gEvent) ~= 'table') then tickErrors = 0; return; end
        local now = os.clock();
        if (now < nextTick) then return; end
        nextTick = now + 0.25;
        -- unpack.lua exposes HandleOutgoingLogic; pack.lua keeps its logic inside HandleOutgoingPacket
        -- (the ffi stub makes its chunk de-dup a no-op, so an empty event runs it once).
        local step = gEvent.HandleOutgoingLogic;
        local arg = nil;
        if (type(step) ~= 'function') then
            step = gEvent.HandleOutgoingPacket;
            arg = { data_raw = '', chunk_data_raw = '', size = 0 };
        end
        if (type(step) == 'function') then
            local ok, err = pcall(step, gEvent, arg);
            if not ok then
                tickErrors = tickErrors + 1;
                PORTER_V3_LOG('tick', err);
                if (tickErrors >= 5) then abortEvent('repeated errors, see diag.log'); return; end
            else
                tickErrors = 0;
            end
        end
        finishIfDone();
    end);

    -- (2) Client-lock stamp (npchelper pattern): while a pack/unpack runs, set the "locked" bit 0x20 on byte
    -- 0x2D of incoming 0x037 player updates. Field result 2026-08-30: Ashita v3 hands incoming packets to Lua
    -- as strings (both the data and the "modified" argument), so nothing can be stamped here - and the full
    -- pack flow (0x036 trade -> 0x034 menu -> 0x05B answer) succeeded without it. Kept as a guarded no-op
    -- that logs once; only stamps if a future v3 build ever passes a mutable byte table, and then only while
    -- the server reports the event status (0x30 == 4) or within 2s of our trade - never on an idle update.
    PORTER_V3_ON('incoming_packet', 'porter_v3_lock', function (id, size, packet, modified, blocked)
        if (id ~= 0x037) then return false; end
        if (type(gEvent) ~= 'table') or (os.clock() >= PORTER_V3_LOCK_UNTIL) then return false; end
        local buf = (type(modified) == 'table' and modified) or (type(packet) == 'table' and packet) or nil;
        if (buf == nil) then
            PORTER_V3_LOG_ONCE('lock', 'incoming 0x037 arrives as ' .. type(packet) .. '/' .. type(modified) .. ' - not mutable, client-lock stamp unavailable');
            return false;
        end
        local status = tonumber(buf[0x30 + 1]) or 0;
        local recentTrade = (os.clock() - PORTER_V3_TRADE_AT) < 2.0;
        if (status ~= 4) and (not recentTrade) then return false; end
        local b = tonumber(buf[0x2D + 1]) or 0;
        if ((b % 64) < 32) then
            buf[0x2D + 1] = b + 32;
            PORTER_V3_LOG_ONCE('lock-stamp', 'stamped 0x20 on 0x037 byte 0x2D (status=' .. status .. ')');
        end
        return false;
    end);

    -- (2b) Extra caches: exact extdata from 0x020 item updates and 0x034 porter menus (see fixExtra in the
    -- shim). The first porter menu of each slip also self-checks the Price>>24 repair against the server bitmap.
    local extraChecked = {};
    local function hex16(s)
        local t = {};
        for b = 1, math.min(16, #s) do t[#t + 1] = string.format('%02X', s:byte(b)); end
        return table.concat(t, ' ');
    end
    PORTER_V3_ON('incoming_packet', 'porter_v3_extra', function (id, size, data, modified, blocked)
        if (type(data) ~= 'string') then return false; end
        if (id == 0x020) and (#data >= 0x29) then
            local itemId = struct.unpack('H', data, 0x0C + 1);
            local bag = struct.unpack('B', data, 0x0E + 1);
            local slot = struct.unpack('B', data, 0x0F + 1);
            local extra = data:sub(0x11 + 1, 0x11 + 24) .. string.rep(string.char(0), 4);
            PORTER_V3_EXTRA_BY_SLOT[bag * 256 + slot] = { id = itemId, extra = extra };
            if gData:GetSlipTable()[itemId] ~= nil then PORTER_V3_EXTRA_BY_ID[itemId] = extra; end
        elseif (id == 0x01F) and (#data >= 0x0D) then
            local bag = struct.unpack('B', data, 0x0A + 1);
            local slot = struct.unpack('B', data, 0x0B + 1);
            PORTER_V3_EXTRA_BY_SLOT[bag * 256 + slot] = nil;
        elseif (id == 0x034) and (#data >= 0x30) then
            local entityIndex = struct.unpack('H', data, 0x28 + 1);
            if (AshitaCore:GetMemoryManager():GetEntity():GetName(entityIndex) == 'Porter Moogle') then
                local slipId = gData:GetSlipIDs()[struct.unpack('B', data, 0x24 + 1) + 1];
                if slipId ~= nil then
                    local server = data:sub(8 + 1, 8 + 28);
                    if (#server < 28) then server = server .. string.rep(string.char(0), 28 - #server); end
                    if not extraChecked[slipId] then
                        extraChecked[slipId] = true;
                        -- compare the Price>>24 repair of the slip's raw fields with the server bitmap
                        pcall(function()
                            local inv = AshitaCore:GetMemoryManager():GetInventory();
                            for index = 1, 81 do
                                local it = inv:GetContainerItem(0, index);
                                if it and (it.Id == slipId) then
                                    local repaired = it.Extra;   -- no cache yet for this slip: this is the price repair
                                    PORTER_V3_LOG('extra-check', string.format('slip %u price=%s repaired=%s server=%s -> %s', slipId, tostring(it.Price), hex16(repaired), hex16(server), (repaired:sub(1, 16) == server:sub(1, 16)) and 'MATCH' or 'MISMATCH'));
                                    break;
                                end
                            end
                        end);
                    end
                    PORTER_V3_EXTRA_BY_ID[slipId] = server;
                end
            end
        end
        return false;
    end);

    -- (3) Chat replacements for the v4 ImGui windows: /po settings, /po help, plus /po stop (safety).
    local function say(msg) print(chat.header(addon.name) .. chat.message(msg)); end
    local function tobool(v)
        v = string.lower(tostring(v));
        return (v == 'on') or (v == 'true') or (v == '1') or (v == 'yes');
    end
    local BOOL_KEYS = { blockinput = 'BlockInput', reversepack = 'ReversePack' };
    local NUM_KEYS = { retrydelay = { 'RetryDelay', 1, 10, false }, maxpackets = { 'MaxPackets', 1, 8, true } };
    local LIST_KEYS = { excludepack = 'ExcludePack', excludeunpack = 'ExcludeUnpack',
                        forceenablecontainers = 'ForceEnableContainers', forcedisablecontainers = 'ForceDisableContainers' };
    local function listText(t)
        if (type(t) ~= 'table') or (#t == 0) then return '(none)'; end
        local parts = {};
        for i = 1, #t do parts[i] = tostring(t[i]); end
        return table.concat(parts, ', ');
    end
    local function showSettings()
        say(string.format('Settings (%s file): BlockInput=%s ReversePack=%s RetryDelay=%s MaxPackets=%s',
            gSettings.CharacterSpecific and 'character' or 'default', tostring(gSettings.BlockInput),
            tostring(gSettings.ReversePack), tostring(gSettings.RetryDelay), tostring(gSettings.MaxPackets)));
        for _, key in ipairs({ 'ExcludePack', 'ExcludeUnpack', 'ForceEnableContainers', 'ForceDisableContainers' }) do
            say(key .. ': ' .. listText(gSettings[key]));
        end
    end
    local function showHelp()
        say('/po pack [list] - store every storable item in your inventory on the porter moogle (slips must be in inventory). With a list, items in that list are KEPT (ReversePack flips this).');
        say('/po unpack [list|all] - retrieve the items in the list. No list = <Name>_<JOB>.lua or <JOB>.lua for your current job. "all" = everything stored on the slips you carry.');
        say('/po export [name] [all] - write the storable items you carry to lists\\<name>.lua (default <Name>_<JOB>); "all" also scans your other accessible containers.');
        say('/po preppack [list] - pull storable items and their slips from your other containers into inventory (mog house / nomad moogle).');
        say('/po prepunpack [list] - pull the slips holding the listed items into inventory (no list = current job list).');
        say('/po stop - abort the running pack/unpack and restore input.');
        say('/po settings [key] [value] - show or change: BlockInput|ReversePack on|off, RetryDelay 1-10, MaxPackets 1-8, ExcludePack|ExcludeUnpack add|remove <itemId>, ForceEnableContainers|ForceDisableContainers add|remove <containerId>, CharacterSpecific toggle.');
        say('Lists live in config\\addons\\Porter\\lists\\<name>.lua and return a table of item ids or names.');
    end
    ashita.events.register('command', 'porter_v3_cmd', function (e)
        local args = e.command:args();
        if (#args == 0) then return; end
        local cmd = string.lower(args[1]);
        if (cmd ~= '/po') and (cmd ~= '/porter') then return; end
        e.blocked = true;
        gSettings.GUI.IsOpen[1] = false;
        gSettings.GUI.DisplayHelp[1] = false;
        local sub = args[2] and string.lower(args[2]) or nil;
        if (sub == nil) then say('Commands: pack, unpack [list|all], export, preppack, prepunpack, stop, settings, help.'); return; end
        if (sub == 'help') then showHelp(); return; end
        if (sub == 'stop') then abortEvent('by command'); return; end
        if (sub ~= 'settings') then return; end   -- pack/unpack/preppack/prepunpack: commands.lua handles them
        if (#args < 3) then showSettings(); return; end
        local key = string.lower(args[3]);
        if (key == 'characterspecific') then
            gSettings:ToggleCharacterSpecific();
            say('CharacterSpecific=' .. tostring(gSettings.CharacterSpecific));
            return;
        end
        if BOOL_KEYS[key] then
            local name = BOOL_KEYS[key];
            if (#args < 4) then say('Usage: /po settings ' .. name .. ' on|off'); return; end
            gSettings[name] = tobool(args[4]);
            gSettings:Save(gSettings.CharacterSpecific);
            say(name .. '=' .. tostring(gSettings[name]));
            return;
        end
        if NUM_KEYS[key] then
            local spec = NUM_KEYS[key];
            local v = tonumber(args[4]);
            if (v == nil) then say('Usage: /po settings ' .. spec[1] .. ' <' .. spec[2] .. '-' .. spec[3] .. '>'); return; end
            if (v < spec[2]) then v = spec[2]; elseif (v > spec[3]) then v = spec[3]; end
            if spec[4] then v = math.floor(v); end
            gSettings[spec[1]] = v;
            gSettings:Save(gSettings.CharacterSpecific);
            say(spec[1] .. '=' .. tostring(v));
            return;
        end
        if LIST_KEYS[key] then
            local name = LIST_KEYS[key];
            local op = args[4] and string.lower(args[4]) or '';
            local v = tonumber(args[5]);
            if ((op ~= 'add') and (op ~= 'remove')) or (v == nil) then say('Usage: /po settings ' .. name .. ' add|remove <id>'); return; end
            local list = gSettings[name];
            if (op == 'add') then
                if not list:contains(v) then list:append(v); end
            else
                list:delete(v);
            end
            gSettings:Save(gSettings.CharacterSpecific);
            say(name .. ': ' .. listText(list));
            return;
        end
        say('Unknown setting: ' .. tostring(args[3]) .. '. Keys: BlockInput, ReversePack, RetryDelay, MaxPackets, ExcludePack, ExcludeUnpack, ForceEnableContainers, ForceDisableContainers, CharacterSpecific.');
    end);

    ashita.events.register('unload', 'porter_v3_unload', function ()
        PORTER_V3_LOCK_UNTIL = 0;
        unblockInput();
    end);

    -- (3b) Relic slips 13/17/18/26/27 (29324/29328/29329/29337/29338): Thorny's CheckAugment stores a relic piece
    -- ONLY when it carries augment extdata (retail reforged relic does). On this server Relic +2/+3 pieces carry
    -- no augment data (augType 0), so they were never even offered to the moogle. PorterPacker's rule applies
    -- to that case (an unaugmented storable item is stored); augmented relic pieces keep Thorny's check.
    local relicSlips = T{ 29324, 29328, 29329, 29337, 29338 };
    local origCheckAugment = gData.CheckAugment;
    gData.CheckAugment = function (self, slipNumber, extdata)
        if relicSlips:contains(slipNumber) and (type(extdata) == 'string') and (#extdata >= 2) then
            local augType = struct.unpack('B', extdata, 1);
            if (augType ~= 2) and (augType ~= 3) then return true; end
        end
        local ok = origCheckAugment(self, slipNumber, extdata);
        if (not ok) and (type(extdata) == 'string') and (#extdata >= 2) then
            PORTER_V3_LOG_ONCE('augment-reject:' .. tostring(slipNumber) .. ':' .. extdata:sub(1, 12),
                string.format('slip %s rejects item: augType=%u augFlag=%u', tostring(slipNumber), extdata:byte(1), extdata:byte(2)));
        end
        return ok;
    end

    -- (4) Load-time sanity: every module must be OUR file, not a same-named built-in (the 'pack' lesson).
    -- A wrong module is reported in chat immediately instead of failing later inside a command.
    local expect = {
        { 'data', gData, 'GetSlip' }, { 'porterpack', gPack, 'Initialize' }, { 'prep', gPrep, 'PreparePack' },
        { 'portersettings', gSettings, 'Save' }, { 'porterunpack', gUnpack, 'Initialize' },
    };
    for _, m in ipairs(expect) do
        if (type(m[2]) ~= 'table') or (type(m[2][m[3]]) ~= 'function') then
            print(chat.header(addon.name) .. chat.error(string.format('Module "%s" did not load from the addon folder (missing %s). Another module owns that name on this Ashita.', m[1], m[3])));
            PORTER_V3_LOG('modules', string.format('%s -> %s (missing %s)', m[1], type(m[2]), m[3]));
        end
    end
    pcall(function()
        local keys = {};
        for k, _ in pairs(package.loaded) do keys[#keys + 1] = tostring(k); end
        table.sort(keys);
        PORTER_V3_LOG('modules', 'package.loaded: ' .. table.concat(keys, ' '));
    end);

    PORTER_V3_LOG('load', 'porter v3 layer active (Porter ' .. tostring(addon.version) .. ')');
end
