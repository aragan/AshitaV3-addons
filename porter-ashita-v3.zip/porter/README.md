# Porter (Ashita v3 edition)

Stores and retrieves gear through the **Porter Moogle** using **Storage Slips**, from the chat line.
This is Aragan with a compatibility layer for **Ashita v3**, plus the
PorterPacker-style conveniences (job lists, export, unpack all).

---

## 1. Requirements

- Ashita **v3**.
- The **Storage Slips** of the gear you want to move must be in your **main inventory** (not Wardrobe/Safe).
- Stand next to a **Porter Moogle** (within ~6 yalms). Porter Moogles are in: Lower Jeuno, Northern San d'Oria,
  Bastok Markets, Port Windurst, Aht Urhgan Whitegate, Nashmau, Tavnazian Safehold, Rabao, Selbina, Mhaura,
  Kazham, Norg, Western Adoulin, Mog Garden, Walk of Echoes, and the three past cities.
- Free inventory space when retrieving (each retrieved piece needs one slot).

## 2. Install

1. Copy the `porter` folder into `<Ashita v3>\addons\` so that you have `<Ashita v3>\addons\porter\porter.lua`.
2. In game: `/addon load porter`
3. `/po help` prints the command list. If you see it, the addon is loaded.
4. Optional: add `/addon load porter` to `<Ashita v3>\scripts\default.txt` to load it at start.

The first load creates `<Ashita v3>\config\addons\Porter\default.lua` (settings) and
`<Ashita v3>\config\addons\Porter\lists\` (your item lists).

## 3. Commands

All commands start with `/po` (or `/porter`).

| Command | What it does |
|---|---|
| `/po pack` | Stores **every** storable item in your inventory on the moogle, slip by slip. Equipped and bazaar items are left alone. |
| `/po pack <list>` | Same, but items named in the list are **kept** (not stored). |
| `/po unpack <list>` | Retrieves the items named in the list from the moogle (their slips must be in your inventory). |
| `/po unpack` | Same, using the list of your **current job**: `<Name>_<JOB>.lua`, or `<JOB>.lua`. |
| `/po unpack all` | Retrieves **everything** stored on the slips you carry. |
| `/po export [name] [all]` | Writes the storable items you carry to `lists\<name>.lua` (default name `<Name>_<JOB>`). `all` also scans your other accessible containers. |
| `/po preppack [list]` | In your Mog House (or next to a Nomad Moogle): pulls storable items and their slips from your other containers into the inventory, ready for `/po pack`. |
| `/po prepunpack [list]` | Same, pulling the slips that hold the listed items (no list = current job list). |
| `/po stop` | Aborts the running pack/unpack and restores keyboard/mouse. |
| `/po settings` | Shows the settings. `/po settings <key> <value>` changes one (see below). |
| `/po help` | Command summary. |

Lists live in `<Ashita v3>\config\addons\Porter\lists\<name>.lua` and return a table of item ids and/or names:

```lua
return {
    23410,                 -- item id
    "Mochi. Chainmail +3", -- or the item name as shown in game
};
```

`/po export` writes such a file for you from what you are carrying, so you rarely type one by hand.

## 4. Typical use

**Store everything before a job change**

1. Stand at the Porter Moogle with your slips in the inventory.
2. `/po pack`
3. The addon trades each slip with up to 7 pieces, confirms the moogle's menu, and repeats until nothing storable is left. `Packing complete.` ends it.

**Set up a job once, then swap with two commands**

1. Wear/carry the full set of the job (for example NIN) and run `/po export` → `lists\<Name>_NIN.lua` is written.
2. Later, on any job, at the moogle: `/po pack` stores what you carry.
3. Change job to NIN and run `/po unpack` → the NIN list is used automatically and the set comes back.

**Take everything out**

`/po unpack all` — every slip in your inventory is traded once and everything its menu lists is retrieved,
until the inventory is full.

**Slips or gear in the Mog Safe / Storage / Wardrobes**

`pack` and `unpack` only work with the main inventory. In the Mog House run `/po preppack` (or
`/po prepunpack <list>`) first to pull the items and slips into the inventory, then go to the moogle.

## 5. Settings

`/po settings <key> <value>` — saved to `default.lua` (or a character file when `CharacterSpecific` is on).

| Key | Values | Meaning |
|---|---|---|
| `BlockInput` | `on` / `off` | Block keyboard and mouse while the addon talks to the moogle. Default **off** on v3. |
| `ReversePack` | `on` / `off` | With a list, `pack` stores **only** the listed items instead of keeping them. |
| `RetryDelay` | `1` – `10` | Seconds to wait for the moogle before retrying a step (default 6). |
| `MaxPackets` | `1` – `8` | Retrieve requests sent at once (1 is what a normal client does). |
| `ExcludePack` | `add` / `remove <itemId>` | Never store this item. |
| `ExcludeUnpack` | `add` / `remove <itemId>` | Never retrieve this item. |
| `ForceEnableContainers` | `add` / `remove <n>` | Treat container `n` as accessible even if the client check says otherwise. |
| `ForceDisableContainers` | `add` / `remove <n>` | The opposite. |
| `CharacterSpecific` | — | Toggle between the shared settings file and one per character. |

Container numbers: 0 Inventory, 1 Safe, 2 Storage, 4 Locker, 5 Satchel, 6 Sack, 7 Case, 8 Wardrobe,
9 Safe 2, 10–16 Wardrobe 2–8.

## 6. Rules to know

- Only the **main inventory** is traded. Equipped (and bazaar) items are never offered.
- `unpack` skips items you already own **anywhere** (inventory, wardrobes, safe...). It never pulls a duplicate.
- Retrieval stops when the inventory is full (`Ran out of inventory space`).
- A piece the server refuses is reported and skipped, the run continues; the end report lists what could not
  be moved (`Could not retrieve N item(s): ...`). Exclude such items with `/po settings ExcludePack add <id>`.
- If the moogle does not answer the same trade three times, the run stops and names the items
  (`Packing stopped: ...`). Usually one of them is not accepted by the server.

## 7. Ashitacast / LuAshitacast

ArAGAN's original integrates with Ashitacast on Ashita **v4** (`/ac porter pack` uses the loaded profile as the
list). That bridge (a v4 plugin event) does not exist on Ashita v3, so it is **not available** here. The job
lists replace it: `/po export` once per job, then `/po unpack` picks the list of the current job.

## 8. Troubleshooting

| Message | Meaning / what to do |
|---|---|
| `List does not exist: ...` | No such file in `lists\`. Check the name, or create it with `/po export <name>`. |
| `No list given and no <Name>_<JOB>.lua ...` | `/po unpack` without a list needs the job file. Run `/po export` first or name a list. |
| `Could not locate porter moogle` | Move closer to the Porter Moogle (about 6 yalms). |
| `Menu ID does not match table` | The server uses a different menu id for this moogle; report the two numbers shown. |
| `Packing stopped: the porter moogle did not answer ...` | The server refused that trade; unequip or exclude the named items. |
| `Not received from the porter moogle, skipping: ...` | The server did not hand the item over; it is skipped and listed at the end. |
| Nothing happens at all | `/po stop`, then `/addon unload porter` and `/addon load porter`, then look at the log below. |

Log file: `<Ashita v3>\config\addons\Porter\porter_diag.log` (every trade, menu, request and error, tagged `PORTER3`).

## 9. Files

`porter.lua` (loader + v3 compatibility layer), `porterpack.lua`, `porterunpack.lua`, `portersettings.lua`,
`prep.lua`, `data.lua`, `slips.lua` (slip tables), `commands.lua`, `settingsmanager.lua`, `gui.lua`,
`itemlist.lua`, `containerlist.lua`, `integration.lua`.
The ImGui windows of the v4 original are replaced by the `/po settings` and `/po help` commands on v3.
